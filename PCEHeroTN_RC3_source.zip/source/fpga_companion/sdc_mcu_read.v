// sdc_mcu_read.v -- PCEHeroTN
//
// Companion SPI target 3 (SDC), the commands the MCU uses to read the card
// through the FPGA. Byte protocol after NanoMig's src/misc/sd_card.v and
// FPGA-Companion's src/sdc.c.
//
//   CMD 1 STATUS    reply: card ready/type byte, then (when the core has a
//                   sector request pending) a request bitmask and the
//                   logical sector, MSB first.
//   CMD 2 CORE_RW   the MCU answers that request with the physical sector
//                   (4 bytes, MSB first), then keeps polling a busy bit
//                   until the core's read of that sector is done. This is
//                   what loads files that are not contiguous on the card.
//   CMD 3 MCU_READ  sector number in (4 bytes, MSB first); the MCU polls
//                   until it reads 0x00 instead of 0x01 (busy), then reads
//                   512 bytes. Used by the companion's file browser.
//
// Runs on clk_pixel with the rest of the companion. The sector read itself is
// done on clk_sys by rom_sdc_loader; requests and replies cross as toggles.
//
// mcu_spi is full duplex: a byte computed while byte N arrives is shifted out
// during byte N+1. Every reply below is written one byte early for that
// reason, and the status byte is written on the command byte itself.

module sdc_mcu_read (
    input        clk,  // clk_pixel
    input        reset,

    input        data_in_strobe,
    input        data_in_start,
    input  [7:0] data_in,
    output reg [7:0] data_out,

    // To rom_sdc_loader (clk_sys): a toggle per request.
    output reg        mcu_read_req_toggle,
    output reg [31:0] mcu_read_sector,

    // From rom_sdc_loader (clk_sys): toggles when the sector is in the buffer.
// NOT synchronised: it is compared with one delayed copy below.
    input        mcu_read_ready_toggle,

    // sdc_mcu_buffer's clk_pixel read port, one cycle of latency
    output reg [8:0] buf_addr,
    input      [7:0] buf_dout,

    // Synchronised levels. The companion will not browse until the status byte
    // reads (s & 0xF0) == 0x80.
    input        card_ready,
    input  [1:0] card_type,

    // CORE_RW request from rom_sdc_loader (synchronised): want is held for the
    // whole round trip, lsector is stable under it.
    input        core_rw_want,
    input  [31:0] core_rw_lsector,

    // Toggles when the 4th physical-sector byte lands.
    output reg        core_rw_reply_toggle,
    output reg [31:0] core_rw_reply_psector,

    // Synchronised: rom_sdc_loader's read of that sector is in flight.
    input        core_rw_local_busy
);

localparam [7:0] CMD_STATUS   = 8'd1;
localparam [7:0] CMD_CORE_RW  = 8'd2;
localparam [7:0] CMD_MCU_READ = 8'd3;

reg [7:0] command;
reg [3:0] byte_cnt;  // saturates at 15

reg [31:0] pending_sector;

// Polls are a full SPI byte apart, far longer than the buffer's 1-cycle read
// latency, so an address set on one poll is safely read on the next.
//
// data_ready is driven from this one always block only. When a ready edge
// and a new request land in the same cycle, the clear (later in program
// order) wins, so a stale ready can never answer a new request.
reg mcu_read_ready_toggle_d;
reg data_ready;
reg mcu_streaming;  // the ready byte (0x00) has been sent

reg [31:0] pending_psector;

always @(posedge clk) begin
    mcu_read_ready_toggle_d <= mcu_read_ready_toggle;

    if (reset) begin
        command        <= 8'd0;
        byte_cnt       <= 4'd0;
        data_out       <= 8'h00;
        buf_addr       <= 9'd0;
        mcu_streaming  <= 1'b0;
        data_ready     <= 1'b0;
        mcu_read_req_toggle  <= 1'b0;
        core_rw_reply_toggle <= 1'b0;
    end else begin
        if (mcu_read_ready_toggle != mcu_read_ready_toggle_d)
            data_ready <= 1'b1;

        if (data_in_strobe) begin
        if (data_in_start) begin
            command  <= data_in;
            byte_cnt <= 4'd0;

            // Status byte goes out on the command byte (one byte early, see header).
            if (data_in == CMD_STATUS)
                data_out <= { card_ready, 3'b000, card_type, 2'b00 };
        end else begin
            if (byte_cnt != 4'd15) byte_cnt <= byte_cnt + 4'd1;

            // STATUS: request bitmask (one drive), then the logical sector.
            if (command == CMD_STATUS) begin
                case (byte_cnt)
                    4'd0: data_out <= { 7'b0, core_rw_want };
                    4'd1: data_out <= core_rw_lsector[31:24];
                    4'd2: data_out <= core_rw_lsector[23:16];
                    4'd3: data_out <= core_rw_lsector[15:8];
                    4'd4: data_out <= core_rw_lsector[7:0];
                    default: ;
                endcase
            end

            // CORE_RW: take the physical sector, signal the core, then report busy
            // on every further poll.
            if (command == CMD_CORE_RW) begin
                case (byte_cnt)
                    4'd0: pending_psector[31:24] <= data_in;
                    4'd1: pending_psector[23:16] <= data_in;
                    4'd2: pending_psector[15:8]  <= data_in;
                    4'd3: begin
                        pending_psector[7:0]  <= data_in;
                        core_rw_reply_psector <= { pending_psector[31:8], data_in };
                        core_rw_reply_toggle  <= ~core_rw_reply_toggle;
                    end
                    default: ;
                endcase

                if (byte_cnt <= 4'd3) data_out <= 8'hff;
                else                  data_out <= { 7'b0, core_rw_local_busy };
            end

            // MCU_READ
            if (command == CMD_MCU_READ) begin
                case (byte_cnt)
                    4'd0: pending_sector[31:24] <= data_in;
                    4'd1: pending_sector[23:16] <= data_in;
                    4'd2: pending_sector[15:8]  <= data_in;
                    4'd3: begin
                        pending_sector[7:0] <= data_in;
                        mcu_read_sector      <= { pending_sector[31:8], data_in };
                        mcu_read_req_toggle  <= ~mcu_read_req_toggle;
                        data_ready           <= 1'b0;  // forget any ready from an earlier request
                        mcu_streaming        <= 1'b0;
                    end
                    default: ;
                endcase

                if (byte_cnt <= 4'd3) begin
                    data_out <= 8'hff;
                end else if (!data_ready) begin
                    data_out <= 8'h01;  // busy: not read yet
                end else if (!mcu_streaming) begin
                    data_out      <= 8'h00;  // ready, sent once
                    buf_addr      <= 9'd0;
                    mcu_streaming <= 1'b1;
                end else begin
                    data_out <= buf_dout;  // address set on an earlier poll
                    if (buf_addr != 9'd511) buf_addr <= buf_addr + 9'd1;
                end
            end
        end
        end
    end
end

endmodule
