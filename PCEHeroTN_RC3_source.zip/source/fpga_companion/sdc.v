// sdc.v -- PCEHeroTN
//
// Companion SPI target 3 (SDC), the two commands the MCU sends when a file is
// picked in the OSD:
//   SPI_SDC_INSERTED (4): the file's size in bytes (0 = no game)
//   SPI_SDC_DIRECT   (6): the first physical sector, sent only when the file
//                         is one contiguous run on the card
//
// Wire format (FPGA-Companion src/sdc.c): command byte, drive number, then a
// 32-bit value MSB first, framed by mcu_spi like the other targets.
//
// The rest of the SDC protocol (STATUS, CORE_RW, MCU_READ) is in
// sdc_mcu_read.v.

module sdc (
    input        clk,
    input        reset,

    input        data_in_strobe,
    input        data_in_start,
    input  [7:0] data_in,

    // One clk pulse when the last value byte lands; drive and value then hold
    // until the next command of the same kind.
    output reg        inserted_strobe,
    output reg [7:0]  inserted_drive,
    output reg [31:0] inserted_size,

    output reg        direct_strobe,
    output reg [7:0]  direct_drive,
    output reg [31:0] direct_start_sector
);

localparam [7:0] CMD_INSERTED = 8'd4;
localparam [7:0] CMD_DIRECT   = 8'd6;

reg [7:0] command;
reg [2:0] state;

always @(posedge clk) begin
    inserted_strobe <= 1'b0;
    direct_strobe   <= 1'b0;

    if (reset) begin
        state   <= 3'd0;
        command <= 8'd0;
    end else if (data_in_strobe) begin
        if (data_in_start) begin
            state   <= 3'd0;
            command <= data_in;
        end else begin
            if (state != 3'd7) state <= state + 3'd1;

            if (command == CMD_INSERTED) begin
                case (state)
                    3'd0: inserted_drive        <= data_in;
                    3'd1: inserted_size[31:24]   <= data_in;
                    3'd2: inserted_size[23:16]   <= data_in;
                    3'd3: inserted_size[15:8]    <= data_in;
                    3'd4: begin
                        inserted_size[7:0] <= data_in;
                        inserted_strobe    <= 1'b1;
                    end
                    default: ;
                endcase
            end

            if (command == CMD_DIRECT) begin
                case (state)
                    3'd0: direct_drive               <= data_in;
                    3'd1: direct_start_sector[31:24]  <= data_in;
                    3'd2: direct_start_sector[23:16]  <= data_in;
                    3'd3: direct_start_sector[15:8]   <= data_in;
                    3'd4: begin
                        direct_start_sector[7:0] <= data_in;
                        direct_strobe            <= 1'b1;
                    end
                    default: ;
                endcase
            end
        end
    end
end

endmodule
