// From MSXnano-MiSTle (fpga/src/usb/fpga_companion.v). Changes for
// PCEHeroTN:
//   - the SD card target (SPI target 3) is decoded: sdc_inst for the
//     INSERTED / DIRECT commands, sdc_mcu_read_inst for STATUS, CORE_RW and
//     MCU_READ (upstream left it unconnected);
//   - an SD interrupt (int_in bit 3) for CORE_RW requests;
//   - a second pad's console byte (joystick1_console);
//   - a `buttons` input to sysctrl (upstream tied it to 0), as NanoMig
//     drives it with the board's buttons.
module fpga_companion (
    input        clk,
    input        reset,
    input  [1:0] buttons,   // {OSD button, MCU reset button} to sysctrl

    // interface to external FPGA companion
    inout [4:0]	m0s,
    // and internal
    input	spi_sclk,
    input	spi_csn,
    output	spi_dir,
    input	spi_dat,
    output	spi_irqn,

    //USB keyboard data
    output [127:0] keyboard,
    output [7:0] joystick0,
    output [7:0] joystick0_console,
    output [7:0] joystick1,
    output [7:0] joystick1_console,
    output [23:0] ws2812_color,

    // OSD channel (SPI target 2) forwarded to the video path, where
    // osd_u8g2 keeps the framebuffer and composites it onto the picture
    output       osd_strobe,
    output       osd_start,
    output [7:0] osd_data,

    // values set by the user in the OSD (sysctrl CMD 4). Ids and meanings
    // are documented in msxnano.xml -- keep the two in step.
    output [1:0] system_reset,
    output       system_turbo,
    output       system_turbo_boot,
    output       system_scanlines,
    output       system_wide_screen,
    output       system_stereo,
    output       system_second_scc,
    output [2:0] system_volume,
    output       system_pal,
    output [1:0] system_keyboard,
    output       system_db9_port,
    output [1:0] system_autofire,
    output       system_save,

    // SD card target: file selected (sdc.v).
    output        sdc_inserted_strobe,
    output [7:0]  sdc_inserted_drive,
    output [31:0] sdc_inserted_size,
    output        sdc_direct_strobe,
    output [7:0]  sdc_direct_drive,
    output [31:0] sdc_direct_start_sector,

    // SD card target: MCU sector reads (sdc_mcu_read.v). The read itself is
    // done by rom_sdc_loader on clk_sys.
    output        sdc_mcu_read_req_toggle,
    output [31:0] sdc_mcu_read_sector,
    input         sdc_mcu_read_ready_toggle,
    output [8:0]  sdc_mcu_buf_addr,
    input  [7:0]  sdc_mcu_buf_dout,

    // Card status, synchronised to clk by the caller.
    input         sdc_card_ready,
    input  [1:0]  sdc_card_type,

    // CORE_RW (see sdc_mcu_read.v). Inputs synchronised to clk by the caller;
    // the reply goes back to clk_sys through the caller.
    input         sdc_core_rw_want,
    input  [31:0] sdc_core_rw_lsector,
    output        sdc_core_rw_reply_toggle,
    output [31:0] sdc_core_rw_reply_psector,
    input         sdc_core_rw_local_busy,

    // A delayed copy of sdc_core_rw_want that raises the SD interrupt; see
    // sdc_irq_flag.
    input         sdc_core_rw_irq
);

wire mcu_hid_strobe;
wire mcu_sys_strobe;
wire mcu_osd_strobe;
wire mcu_sdc_strobe;

wire mcu_start;
wire spi_intn;
wire [7:0] mcu_data_out;

// hand the OSD byte stream out to the video path. mcu_osd_din stays 0:
// the OSD is write-only from the MCU, nothing is ever read back from it.
assign osd_strobe = mcu_osd_strobe;
assign osd_start  = mcu_start;
assign osd_data   = mcu_data_out;
wire [7:0] sys_data_out;
wire [7:0] hid_data_out;

//assign m0s[4] = spi_intn;

// -------------------------- M0S MCU interface -----------------------
// intn and dout are outputs driven by the FPGA to the MCU
// din, ss and clk are inputs coming from the MCU
// onboard connection to on-board BL616

assign spi_dir = spi_io_dout;
assign m0s[4:0] = { spi_intn, 3'bzzz, spi_io_dout };
assign spi_irqn = spi_intn;

// by default the internal SPI is being used. Once there is
// a select from the external spi, then the connection is
// being switched
reg spi_ext;
always @(posedge clk) begin
    if(reset)
        spi_ext = 1'b0;
    else begin
        // spi_ext is activated once the m0s pins 2 (ss or csn) is
        // driven low by the m0s dock. This means that a m0s dock
        // is connected and the FPGA switches its inputs to the
        // m0s. Until then the inputs of the internal BL616 are
        // being used.
        if(m0s[2] == 1'b0)
            spi_ext = 1'b1;
    end
end

// switch between internal SPI connected to the on-board bl616
// or to the external one possibly connected to a M0S Dock
wire spi_io_din = spi_ext?m0s[1]:spi_dat;
wire spi_io_ss = spi_ext?m0s[2]:spi_csn;
wire spi_io_clk = spi_ext?m0s[3]:spi_sclk;

mcu_spi mcu (
        .clk(clk),
        .reset(reset),

        .spi_io_ss(spi_io_ss),
        .spi_io_clk(spi_io_clk),
        .spi_io_din(spi_io_din),
        .spi_io_dout(spi_io_dout),

        .mcu_sys_strobe(mcu_sys_strobe),
        .mcu_hid_strobe(mcu_hid_strobe),
        .mcu_osd_strobe(mcu_osd_strobe),
        .mcu_sdc_strobe(mcu_sdc_strobe),
        .mcu_start(mcu_start),
        .mcu_dout(mcu_data_out),
        .mcu_sys_din(sys_data_out),
        .mcu_hid_din(hid_data_out),
        .mcu_osd_din(8'b00000000),
        .mcu_sdc_din(mcu_sdc_din)
        );

wire [7:0] mcu_sdc_din;

sdc sdc_inst (
        .clk(clk),
        .reset(reset),

        .data_in_strobe(mcu_sdc_strobe),
        .data_in_start(mcu_start),
        .data_in(mcu_data_out),

        .inserted_strobe(sdc_inserted_strobe),
        .inserted_drive(sdc_inserted_drive),
        .inserted_size(sdc_inserted_size),
        .direct_strobe(sdc_direct_strobe),
        .direct_drive(sdc_direct_drive),
        .direct_start_sector(sdc_direct_start_sector)
        );

sdc_mcu_read sdc_mcu_read_inst (
        .clk(clk),
        .reset(reset),

        .data_in_strobe(mcu_sdc_strobe),
        .data_in_start(mcu_start),
        .data_in(mcu_data_out),
        .data_out(mcu_sdc_din),

        .mcu_read_req_toggle  (sdc_mcu_read_req_toggle),
        .mcu_read_sector      (sdc_mcu_read_sector),
        .mcu_read_ready_toggle(sdc_mcu_read_ready_toggle),
        .buf_addr             (sdc_mcu_buf_addr),
        .buf_dout             (sdc_mcu_buf_dout),

        .card_ready(sdc_card_ready),
        .card_type (sdc_card_type),

        .core_rw_want      (sdc_core_rw_want),
        .core_rw_lsector   (sdc_core_rw_lsector),
        .core_rw_reply_toggle (sdc_core_rw_reply_toggle),
        .core_rw_reply_psector(sdc_core_rw_reply_psector),
        .core_rw_local_busy(sdc_core_rw_local_busy)
        );

wire [7:0] int_ack;
wire hid_int;
wire hid_iack = int_ack[1];

hid hid_inst (
        .clk(clk),
        .reset(reset),

         // interface to receive user data from MCU (mouse, kbd, ...)
        .data_in_strobe(mcu_hid_strobe),
        .data_in_start(mcu_start),
        .data_in(mcu_data_out),
        .data_out(hid_data_out),

        // input local db9 port events to be sent to MCU. Changes also trigger
        // an interrupt, so the MCU doesn't have to poll for joystick events
        //.db9_port( db9_joy ),
        .irq( hid_int ),
        .iack( hid_iack ),

        //.mouse(hid_mouse),
        .keyboard(keyboard),
        .joystick0(joystick0),
        .joystick0_console(joystick0_console),
        .joystick1(joystick1),
        .joystick1_console(joystick1_console)
         );

// 1 = never raise the SD interrupt (debug).
localparam DISABLE_SDC_IRQ = 0;

// SD interrupt flag, shaped like hid.v's: set on a rising edge of
// sdc_core_rw_irq, cleared as soon as the firmware acks it (int_ack[3]).
// Holding it until the request completed kept the shared IRQ line low after
// the MCU re-armed its GPIO interrupt, and the MCU handled the same request
// twice. It cannot be set again until a new request arrives.
reg sdc_irq_flag              = 1'b0;
reg sdc_core_rw_irq_d         = 1'b0;
wire sdc_iack = int_ack[3];
always @(posedge clk) begin
    if (reset) begin
        sdc_irq_flag               <= 1'b0;
        sdc_core_rw_irq_d          <= 1'b0;
    end else begin
        sdc_core_rw_irq_d          <= sdc_core_rw_irq;

        if (sdc_core_rw_irq && !sdc_core_rw_irq_d)
            sdc_irq_flag <= 1'b1;
        else if (sdc_iack)
            sdc_irq_flag <= 1'b0;
    end
end

sysctrl sysctrl (
        .clk(clk),
        .reset(reset),

         // interface to send and receive generic system control
        .data_in_strobe(mcu_sys_strobe),
        .data_in_start(mcu_start),
        .data_in(mcu_data_out),
        .data_out(sys_data_out),

        
        // Bit 3 is the SD interrupt: the MCU only answers a CORE_RW request after
        // it sees it. The STATUS reply carries the request bit undelayed; only the
        // interrupt is delayed (in the top level), because raising it while the
        // firmware was still sending the INSERTED command crashed the companion.
        .int_out_n(spi_intn),
        .int_in( { 4'b0000, (DISABLE_SDC_IRQ ? 1'b0 : sdc_irq_flag), 1'b0, hid_int, 1'b0 }),
        .int_ack( int_ack ),

        .buttons( buttons ),
        .leds(system_leds),
        .color(ws2812_color),

        .system_reset(system_reset),
        .system_turbo(system_turbo),
        .system_turbo_boot(system_turbo_boot),
        .system_scanlines(system_scanlines),
        .system_wide_screen(system_wide_screen),
        .system_stereo(system_stereo),
        .system_second_scc(system_second_scc),
        .system_volume(system_volume),
        .system_pal(system_pal),
        .system_keyboard(system_keyboard),
        .system_db9_port(system_db9_port),
        .system_autofire(system_autofire),
        .system_save(system_save)
         );   

endmodule