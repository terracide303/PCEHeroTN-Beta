/*
    sysctrl.v
 
    generic system control interface from/via the MCU

    TODO: This is currently very core specific. This needs to be
    generic for all cores.
*/

module sysctrl (
  input		    clk,
  input		    reset,

  input		    data_in_strobe,
  input		    data_in_start,
  input [7:0]	    data_in,
  output reg [7:0]  data_out,

  // interrupt interface
  output	    int_out_n,
  input [7:0]	    int_in,
  output reg [7:0]  int_ack,

  input [1:0]	    buttons, // S0 and S1 buttons on Tang Nano 20k

  output reg [1:0]  leds, // two leds can be controlled from the MCU
  output reg [23:0] color, // a 24bit color to e.g. be used to drive the ws2812

  // IO port interface
  input	[31:0]	    port_status,         // status bits to report additional info about the port
  input	[7:0]	    port_out_available,  // number of bytes available for transmission to MCU
  output reg	    port_out_strobe,
  input [7:0]	    port_out_data,
  input	[7:0]	    port_in_available,   // number of unused bytes in the input buffer
  output reg	    port_in_strobe,
  output reg [7:0]  port_in_data,
		
  // values that can be configured by the user via the OSD.
  // ids match fpga/src/usb/msxnano.xml -- keep the two in step.
  output reg [1:0]  system_reset,        // "R" run(0), reset(1), coldboot(3)
  output reg	    system_turbo,        // "T" 3.58MHz(0) or 5.37MHz(1)
  output reg	    system_turbo_boot,   // "B" start cold boots in turbo
  output reg	    system_scanlines,    // "S" scanlines off(0) or on(1)
  output reg	    system_wide_screen,  // "A" 4:3(0) or 16:9(1)
  output reg	    system_stereo,       // "E" mono(0) or stereo(1)
  output reg	    system_second_scc,   // "C" second SCC+ in the free slot
  output reg [2:0]  system_volume,       // "V" mute(0), 25/50/75/100%(1..4)
  output reg	    system_pal,          // "P" 60Hz NTSC(0) or 50Hz PAL(1)
  output reg [1:0]  system_keyboard,     // "K" int(0), japanese(1), spanish(2)
  output reg	    system_db9_port,     // "J" DB9 on MSX port 1(0) or 2(1)
  output reg [1:0]  system_autofire,     // "F" off(0), 3Hz(1), 6Hz(2), 13Hz(3)
  output reg	    system_save          // "W" 1 = write the settings to flash
);

reg [3:0] state;
reg [7:0] command;
reg [7:0] id;

// menu rom: the gzipped PCEHeroTN menu, streamed to the MCU on CMD 8 so the
// OSD menu travels with the bitstream and needs no file on the SD card.
//
// PCEHeroTN: the one change to this file is the $readmemh path below. The
// original path does not exist here, and Gowin only warns and leaves the
// array empty, which leaves the OSD blank. pcehero_menu.hex is the menu XML,
// minified, gzipped (gzip -9 -n) and dumped one byte per line, as
// MSXnano-MiSTle's make_menu_rom.sh does. The array keeps its
// original name, msxnano_xml.
reg [9:0] menu_rom_addr;
reg [7:0] menu_rom_data;

// Same shape as NanoMig's: a byte array initialised by $readmemh, which Gowin
// infers as BSRAM. A generated case statement was tried instead and cost LUTs
// on a design already at 88% CLS, so it is not worth it.
reg [7:0] msxnano_xml[1024];
initial $readmemh("source/fpga_companion/pcehero_menu.hex", msxnano_xml);

always @(posedge clk)
  menu_rom_data <= msxnano_xml[menu_rom_addr];
   
// reverse data byte for rgb   
wire [7:0] data_in_rev = { data_in[0], data_in[1], data_in[2], data_in[3], 
                           data_in[4], data_in[5], data_in[6], data_in[7] };

// coldboot flash and system interrupt   
reg coldboot = 1'b1;   
reg sys_int = 1'b1;

// registers to report button interrupts
reg [1:0] buttonsD, buttonsD2;
reg	  buttons_irq_enable;
   
// the system cobtrol interrupt or any other interrupt (e,g sdc, hid, ...)
// activates the interrupt line to the MCU by pulling it low
assign int_out_n = (int_in != 8'h00 || sys_int)?1'b0:1'b1;
   
reg       port_out_availableD;
reg [7:0] port_cmd;   
reg [7:0] port_index;

   
// process mouse events
always @(posedge clk) begin
   if(reset) begin
      state <= 4'd0;      
      leds <= 2'b00;        // after reset leds are off
      color <= 24'h000000;  // color black -> rgb led off

      buttons_irq_enable <= 1'b1;  // allow buttons irq
      int_ack <= 8'h00;
      coldboot = 1'b1;      // reset is actually the power-on-reset
      sys_int = 1'b1;       // coldboot interrupt

      port_out_strobe <= 1'b0;
      port_in_strobe <= 1'b0;
      
      // OSD value defaults. These should be sane defaults, but the MCU
      // will very likely override these early
      // 00 = run. MiSTeryNano leaves this undriven at reset; make it explicit
      // here so the machine boots even if no companion ever talks to us.
      system_reset <= 2'b00;
      system_turbo <= 1'b0;         // 3.58 MHz
      system_turbo_boot <= 1'b0;    // do not cold boot in turbo
      system_scanlines <= 1'b0;     // no scanlines
      system_wide_screen <= 1'b0;   // 4:3
      system_stereo <= 1'b0;        // mono
      system_second_scc <= 1'b0;    // no second SCC+
      system_volume <= 3'd4;        // full volume
      system_pal <= 1'b0;           // 60 Hz
      system_keyboard <= 2'd0;      // international
      system_db9_port <= 1'b0;      // DB9 on port 1
      system_autofire <= 2'd1;      // 5 Hz, matching the XML default
      system_save <= 1'b0;          // not saving
   end else begin // if (reset)
      //  bring button state into local clock domain
      buttonsD <= buttons;
      buttonsD2 <= buttonsD;
      
      int_ack <= 8'h00;
      port_out_strobe <= 1'b0;
      port_in_strobe <= 1'b0;

      // iack bit 0 acknowledges the system control interrupt
      if(int_ack[0]) sys_int <= 1'b0;      
            
      // (further) data has just become available, so raise interrupt
      port_out_availableD <= (port_out_available != 8'd0);
      if(port_out_available && !port_out_availableD)
	sys_int <= 1'b1;
      
      // monitor buttons for changes and raise interrupt
      if(buttons_irq_enable) begin
        if(buttonsD2 != buttonsD) begin
            // irq_enable prevents further interrupts until
            // the button state has actually been read by the MCU
            sys_int <= 1'b1;
            buttons_irq_enable <= 1'b0;
        end
      end

      if(data_in_strobe) begin
        if(data_in_start) begin
           state <= 4'd0;
           command <= data_in;
           menu_rom_addr <= 10'd0;
	   data_out <= 8'h00;
        end else begin
            if(state != 4'd15) state <= state + 4'd1;
	    
            // CMD 0: status data
            if(command == 8'd0) begin
                // return some pattern that would not appear randomly
	        // on e.g. an unprogrammed device
                // FPGA-Companion's sys_status_is_valid() tests for exactly
                // 0x5c,0x42 and refuses to talk to the core otherwise --
                // sys_wait4fpga() then never succeeds and osd_init() never runs.
                if(state == 4'd0) data_out <= 8'h5c;   // \ magic marker identifying
                if(state == 4'd1) data_out <= 8'h42;   // / a valid FPGA core
                if(state == 4'd2) data_out <= 8'h00;   // core id 0 = generic core
            end
	   
            // CMD 1: there are two MCU controlled LEDs
            if(command == 8'd1) begin
                if(state == 4'd0) leds <= data_in[1:0];
            end

            // CMD 2: a 24 color value to be mapped e.g. onto the ws2812
            if(command == 8'd2) begin
                if(state == 4'd0) color[15: 8] <= data_in_rev;
                if(state == 4'd1) color[ 7: 0] <= data_in_rev;
                if(state == 4'd2) color[23:16] <= data_in_rev;
            end

            // CMD 3: return button state
            if(command == 8'd3) begin
               data_out <= { 6'b000000, buttons };
	       // re-enable interrupt once state has been read
               buttons_irq_enable <= 1'b1;
            end

            // CMD 4: config values (e.g. set by user via OSD)
            if(command == 8'd4) begin
                // second byte can be any character which identifies the variable to set 
                if(state == 4'd0) id <= data_in;

                if(state == 4'd1) begin
                    // Value "R": coldboot(3), reset(1) or run(0)
                    if(id == "R") system_reset <= data_in[1:0];
                    // Value "T": turbo 3.58MHz(0) or 5.37MHz(1)
                    if(id == "T") system_turbo <= data_in[0];
                    // Value "B": start cold boots in turbo (persisted by the core)
                    if(id == "B") system_turbo_boot <= data_in[0];
                    // Value "S": scanlines off(0) or on(1)
                    if(id == "S") system_scanlines <= data_in[0];
                    // Value "A": aspect 4:3(0) or 16:9(1)
                    if(id == "A") system_wide_screen <= data_in[0];
                    // Value "E": sound mono(0) or stereo(1)
                    if(id == "E") system_stereo <= data_in[0];
                    // Value "C": second SCC+ disabled(0) or enabled(1)
                    if(id == "C") system_second_scc <= data_in[0];
                    // Value "V": volume mute(0), 25/50/75/100%(1..4)
                    if(id == "V") system_volume <= data_in[2:0];
                    // Value "P": 60Hz NTSC(0) or 50Hz PAL(1)
                    if(id == "P") system_pal <= data_in[0];
                    // Value "K": keyboard international(0), japanese(1), spanish(2)
                    if(id == "K") system_keyboard <= data_in[1:0];
                    // Value "J": DB9 answers on MSX joystick port 1(0) or 2(1)
                    if(id == "J") system_db9_port <= data_in[0];
                    // Value "F": autofire off(0), 3Hz(1), 6Hz(2), 13Hz(3)
                    if(id == "F") system_autofire <= data_in[1:0];
                    // Value "W": 1 asks the core to write the settings to
                    // flash. The XML raises it and drops it again like "R";
                    // top.v triggers on the rising edge, so a level that
                    // stayed high would still save exactly once.
                    if(id == "W") system_save <= data_in[0];
                end
            end

            // CMD 5: interrupt control
            if(command == 8'd5) begin
                // second byte acknowleges the interrupts
                if(state == 4'd0) int_ack <= data_in;

	        // interrupt[0] notifies the MCU of a FPGA cold boot e.g. if
                // the FPGA has been loaded via USB
                data_out <= { int_in[7:1], sys_int };
            end
	   
            // CMD 6: read system interrupt source
            if(command == 8'd6) begin
	        // bit[0]: coldboot flag
	        // bit[1]: port data is available
	        // bit[2]: buttons state change has been detected
                data_out <= { 5'b00000, !buttons_irq_enable, (port_out_available != 8'd0), coldboot };
	        // reading the interrupt source acknowledges the coldboot notification
	        if(state == 4'd0) coldboot <= 1'b0;            
	    end

            // CMD 7: port command (e.g. rs232)
            if(command == 8'd7) begin

	       // the first two bytes of a port command always have the same meaning ...
               if(state == 4'd0) begin
		  // first byte is the subcommand
		  port_cmd <= data_in;
		  // return the number of ports implemented in this core
		  data_out <= 8'd1;
	       end else if(state == 4'd1) begin
		  // second byte is the port index (if several ports are supported)
		  port_index <= data_in;
		  // return port type (currently supports only 0=serial)
		  data_out <= 8'd0;
	       end else begin
		  // ... further bytes are subcommand specific

		  // port subcommand 0: get status
		  if(port_cmd == 8'd0 && port_index == 8'd0) begin
		     if(state == 4'd2)       data_out <= port_out_available;
		     else if(state == 4'd3)  data_out <= port_in_available;
		     // port status for type 0 (serial) is still close to the format
		     // that was introduced with the first MiST
		     else if(state == 4'd4)  data_out <= port_status[31:24];  // bitrate[7:0]
		     else if(state == 4'd5)  data_out <= port_status[23:16];  // bitrate[15:8]
		     else if(state == 4'd6)  data_out <= port_status[15:8];   // bitrate[23:16]
		     else if(state == 4'd7)  data_out <= port_status[7:0];    // databits, parity and stopbits
		     else                    data_out <= 8'h00;
		  end
		  
		  // port subcommand 1: read port data
		  else if(port_cmd == 8'd1 && port_index == 8'd0) begin
		     data_out <= port_out_data;

		     // reading the byte ack's the mfp's fifo. Since the
		     // data arrives with one byte delay at the MCU we need
		     // to make sure that the last read will not trigger
		     // another fifo read. The MCU will thus not set bit[0] for
		     // the last read to suppress the fifo read
		     port_out_strobe <= data_in[0];
		  end
		  
		  // port subcommand 2: write port data
		  else if(port_cmd == 8'd2 && port_index == 8'd0) begin
		     port_in_data <= data_in;
		     port_in_strobe <= 1'b1;
		  end
		  
	       end
            end // if (command == 8'd7)
	   
            // CMD 8: read (menu) config -- stream the gzipped menu XML to
            // the MCU, one byte per read, from the address reset at command start
            if(command == 8'd8) begin
               data_out <= menu_rom_data;
               menu_rom_addr <= menu_rom_addr + 10'd1;
            end
	   
	end
      end // if (data_in_strobe)
   end
end
    
endmodule