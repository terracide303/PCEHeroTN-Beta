# PCEHeroTN -- Gowin build script for the Tang Nano 20K.
#
#   gw_sh build_nano.tcl
#
# Output: impl/pnr/pcehero_nano_tangnano20k.fs
#
# The PC Engine core is VHDL from MiST and MiSTer (CPU and PSG from MiSTer,
# VDC and the core top from MiST, the latter with external-RAM support),
# ported to Gowin. rtl/ and source/ each hold our own, adapted and borrowed
# files; each file's header says where it comes from.
#
# The SDRAM is in the GW2AR package, so it needs no pin constraints: Gowin
# connects it by the O_sdram_* / IO_sdram_dq port names.
#
# Some files below are analysed but not used by this configuration. They
# stay in the list so the build is identical to the released bitstream.

set_device GW2AR-LV18QN88C8/I7 -device_version C

# --- ours, and adapted ------------------------------------------------------
add_file rtl/pcehero_nano_top.v
add_file rtl/joypad.v
# FPGA-Companion interface (OSD, USB HID, settings, SD card access)
add_file source/fpga_companion/fpga_companion.v
add_file source/fpga_companion/hid.v
add_file source/fpga_companion/mcu_spi_new.v
add_file source/fpga_companion/sys_ctrl.v
add_file source/fpga_companion/sdc.v
add_file source/fpga_companion/sdc_mcu_read.v
# SD card reader, from WonderTANG (BSD-2-Clause; crc16.v is LGPL)
add_file source/fpga_companion/wondertang/sd_reader.sv
add_file source/fpga_companion/wondertang/sdcmd_ctrl.sv
add_file source/fpga_companion/wondertang/crc16.v
add_file rtl/sdc_mcu_buffer.v
add_file rtl/rom_sdc_loader.v
add_file source/fpga_companion/osd_u8g2.v
add_file rtl/pce_reset_seq.v
add_file rtl/rom_loader.v
add_file rtl/sdc_write_bridge.v
add_file rtl/wram_sdram.v
add_file rtl/flash_reader.v
add_file rtl/pce_scandoubler.v
add_file rtl/crt_lite_px.v
add_file rtl/pce_colour_pal.v
add_file rtl/pce_hdmi_di.v
add_file rtl/pce_video.v
add_file rtl/pce_sdram_ctrl.v
add_file rtl/pce_sdram_bank2.v
add_file rtl/pce_sdram_bank2_client.v
add_file rtl/sdram_ungated.sv
add_file rtl/clocks_slow.v
add_file rtl/init_pkg.vhd
add_file rtl/dpram.vhd
add_file rtl/vram_bram.vhd
add_file rtl/wram_bram.vhd
add_file rtl/dprom.vhd
add_file rtl/pce_top_extram.vhd
add_file rtl/huc6270.vhd
add_file rtl/psg.vhd
add_file rtl/cd_stub_mist.vhd

# --- the PC Engine core, from MiST and MiSTer -------------------------------
add_file source/mist/huc6260.vhd
add_file source/mist/huc6202.vhd
add_file source/mister/CEGen.vhd
add_file source/mister/HUC6280/HUC6280.vhd
add_file source/mister/HUC6280/HUC6280_PKG.vhd
add_file source/mister/HUC6280/HUC6280_CPU.vhd
add_file source/mister/HUC6280/HUC6280_ALU.vhd
add_file source/mister/HUC6280/HUC6280_AG.vhd
add_file source/mister/HUC6280/AddSubBCD.vhd
add_file source/mister/HUC6280/HUC6280_MC.vhd

add_file pcehero_nano.cst
add_file pcehero.sdc

# --- HDMI, from hdl-util/hdmi (needs -verilog_std sysv2017 below) -----------
add_file source/hdmi/hdmi.sv
add_file source/hdmi/serializer.sv
add_file source/hdmi/tmds_channel.sv
add_file source/hdmi/packet_assembler.sv
add_file source/hdmi/packet_picker.sv
add_file source/hdmi/audio_clock_regeneration_packet.sv
add_file source/hdmi/audio_info_frame.sv
add_file source/hdmi/audio_sample_packet.sv
add_file source/hdmi/auxiliary_video_information_info_frame.sv
add_file source/hdmi/source_product_description_info_frame.sv

# --- jcapture2 (robinsonb5, GPL-3.0), a JTAG logic analyser, off here --------
# Must stay last: these files set `default_nettype none and never reset it,
# and Gowin carries that setting into the files added after them (the HDMI
# files failed with EX3094 when these came first). pce_reset_seq.v and
# pce_sdram_bank2_client.v also leave it set; the files after them build.
add_file rtl/jcapture.v
add_file rtl/vjtag_gw2a.v
add_file rtl/vjtag_sync_fifo.v

set_option -verilog_std sysv2017
set_option -synthesis_tool gowinsynthesis
set_option -output_base_name pcehero_nano_tangnano20k
set_option -top_module pcehero_nano_top
set_option -use_mspi_as_gpio 1
set_option -use_sspi_as_gpio 1
set_option -use_ready_as_gpio 1
set_option -use_done_as_gpio 1
set_option -rw_check_on_ram 1
# Highest place and route effort this toolchain accepts for this device
# (place_option 3 and 4 are rejected).
set_option -timing_driven 1
set_option -place_option 2
set_option -route_option 2

run all
