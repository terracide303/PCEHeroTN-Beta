# Licences

The parts of PCEHeroTN that come with a stated licence, and where they come
from. Each file keeps its original header.

| Part | Files | From | Licence |
|---|---|---|---|
| SDRAM controller | `rtl/sdram_ungated.sv` | [NanoMig](https://github.com/MiSTle-Dev/NanoMig) `src/misc/sdram.sv` | GPL-3.0-or-later |
| SDRAM bank scheduling | `rtl/pce_sdram_bank2.v` | ported from Alastair M. Robinson's `sdram_amr.sv` ([MiST TurboGrafx16](https://github.com/mist-devel/TurboGrafx16_FPGA)) | GPL-3.0-or-later |
| Debug capture (off in this build) | `rtl/jcapture.v`, `rtl/vjtag_gw2a.v`, `rtl/vjtag_sync_fifo.v` | [jcapture2](https://github.com/robinsonb5/jcapture2) | GPL-3.0-or-later |
| SD card reader | `source/fpga_companion/wondertang/sd_reader.sv`, `sdcmd_ctrl.sv` | [WangXuan95/FPGA-SDcard-Reader](https://github.com/WangXuan95/FPGA-SDcard-Reader) (same headers), extended by [WonderTANG](https://github.com/lfantoniosi/WonderTANG), via MSXnano-MiSTle | GPL-3.0 (FPGA-SDcard-Reader); WonderTANG ships them as BSD-2-Clause (`wondertang/LICENSE`) |
| SD card CRC | `source/fpga_companion/wondertang/crc16.v` | Kay Gorontzi (header) | LGPL |
| HDMI | `source/hdmi/*.sv` | [hdl-util/hdmi](https://github.com/hdl-util/hdmi) | MIT or Apache-2.0 (`source/hdmi/LICENSE-MIT`, `LICENSE-APACHE`) |
| FPGA-Companion interface | `source/fpga_companion/fpga_companion.v`, `hid.v`, `sys_ctrl.v`, `osd_u8g2.v`, `mcu_spi_new.v` | [MSXnano-MiSTle](https://github.com/terracide303/MSXnano-MiSTle) `fpga/src/usb/` (from MiSTeryNano) | GPL-3.0 (MSXnano-MiSTle's LICENSE) |
| HuC6202 (not used in this build) | `source/mist/huc6202.vhd` | MiST TurboGrafx16 (Sorgelig, header) | GPL-2.0-or-later |
