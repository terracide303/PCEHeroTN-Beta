-- dprom.vhd -- PCEHeroTN
--
-- A single-port synchronous ROM, for the PSG tables. The volume table is
-- 24 bits wide, wider than a Gowin true-dual-port block RAM port (18), and it
-- is never written, so it does not need dpram at all. A single-port ROM
-- allows the wider word.
--
-- Initial contents come from init_pkg.vhd, as for dpram.

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library work;
use work.pce_init_pkg.all;

entity dprom is
    generic (
        addr_width    : integer := 12;
        data_width    : integer := 24;
        mem_init_file : string  := " "
    );
    port (
        clock   : in  std_logic;
        address : in  std_logic_vector(addr_width-1 downto 0);
        enable  : in  std_logic := '1';
        q       : out std_logic_vector(data_width-1 downto 0)
    );
end entity;

architecture rtl of dprom is

    type rom_t is array (0 to 2**addr_width - 1)
        of std_logic_vector(data_width-1 downto 0);

    function init_rom return rom_t is
        variable r : rom_t := (others => (others => '0'));
    begin
        if mem_init_file = "HUC6280/voltab.mif" then
            for i in INIT_VOLTAB'range loop
                if i <= r'high then
                    r(i) := INIT_VOLTAB(i)(data_width-1 downto 0);
                end if;
            end loop;
        -- The PSG attenuation table: row g=16 of the volume table, where
        -- 2*16-31 = 1. psg.vhd multiplies it by (2*sample-31). About 128 words
        -- instead of the full 4096-word product table.
        elsif mem_init_file = "HUC6280/scale" then
            for i in 0 to r'high loop
                if (2048 + i) <= INIT_VOLTAB'high then
                    r(i) := INIT_VOLTAB(2048 + i)(data_width-1 downto 0);
                end if;
            end loop;
        elsif mem_init_file = "huc6260_palette_init.mif" then
            for i in INIT_PALETTE'range loop
                if i <= r'high then
                    r(i) := INIT_PALETTE(i)(data_width-1 downto 0);
                end if;
            end loop;
        end if;
        return r;
    end function;

    -- A constant: nothing writes it.
    constant rom : rom_t := init_rom;

    -- Force block ROM rather than LUTs.
    attribute syn_romstyle : string;
    attribute syn_romstyle of rom : constant is "block_rom";

begin

    process (clock)
    begin
        if rising_edge(clock) then
            if enable = '1' then
                q <= rom(to_integer(unsigned(address)));
            end if;
        end if;
    end process;

end architecture;
