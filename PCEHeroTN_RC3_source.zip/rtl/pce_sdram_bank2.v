// pce_sdram_bank2.v -- PCEHeroTN
//
// Bank-interleaved SDRAM controller for the Tang Nano 20K's 32-bit SDRAM,
// on clk_ram (86.4 MHz). Each client owns an SDRAM bank, so one client's
// RAS/CAS stages can overlap another's instead of queueing:
//
//   bank 0  ROM reads, and SD card writes of a newly loaded ROM (sdcw)
//   bank 1  work RAM. In the shipping build work RAM is in block RAM, but
//           wram_sdram still sends every access here (results unused).
//   bank 2, 3  unused and not refreshed (nothing is stored there)
//
// The scheduling (bank ownership, the RAS / CAS / MASK / LATCH pipeline,
// per-bank refresh, write-after-read spacing, the acknowledge timing) is
// ported from Alastair Robinson's sdram_amr.sv in mist-devel's
// TurboGrafx16_FPGA, which is GPL-3.0-or-later. That controller is 16 bits
// wide; the command encoding, mode register and CAS latency 2 timing here
// come from NanoMig's sdram.sv, which runs on this chip.
//
// Unlike NanoMig's sdram.sv there is no video sync input: no client here is
// video-timed, so the controller free-runs.
//
// Client ports:
//   addr        19 bits, {row[10:0], col[7:0]} inside the client's own bank
//   din / dout  32 bits
//   dqm         active low (0 = write this byte); ignored on reads
//   req / ack   toggles. The client flips req with addr/din/dqm/we stable,
//               holds them until ack flips to match.
// ROM reads are 2-word bursts: rom_dout2 is the next word (addr+1).

`default_nettype none

module pce_sdram_bank2 #(
    // clk_ram cycles a bank stays busy after ACTIVE: the post-RAS budget of
    // NanoMig's sdram.sv on this chip (CL2, auto-precharge).
    parameter BANK_DELAY = 10,
    // Busy time after a write: BANK_DELAY + 2 as a margin for write recovery.
    // Not separately measured.
    parameter BANK_WRITE_DELAY = 12,
    // The real clk_ram frequency; used only for the refresh interval. Pass it
    // from the top.
    parameter RAM_CLOCK_SPEED = 78_000_000
) (
    input  wire        clk,  // clk_ram
    input  wire        reset_n,
    output wire        ready,

    // ROM client: bank 0.
    input  wire [18:0] rom_addr,
    input  wire [31:0] rom_din,
    output wire [31:0] rom_dout,
    output wire [31:0] rom_dout2,  // second word of the burst
    input  wire [3:0]  rom_dqm,
    input  wire        rom_req,
    input  wire        rom_we,
    output reg          rom_ack,

    // SD write client: also bank 0, always a write. Arbitrated here inside the
    // controller, not muxed in front of it: a ROM read wins, then this, then
    // refresh.
    input  wire [18:0] sdcw_addr,
    input  wire [31:0] sdcw_din,
    input  wire [3:0]  sdcw_dqm,
    input  wire        sdcw_req,
    output reg          sdcw_ack,

    // Work RAM client: bank 1.
    input  wire [18:0] wram_addr,
    input  wire [31:0] wram_din,
    output wire [31:0] wram_dout,
    input  wire [3:0]  wram_dqm,
    input  wire        wram_req,
    input  wire        wram_we,
    output reg          wram_ack,

    // SDRAM pins
    inout  wire [31:0] sd_data,
    output reg  [10:0] sd_addr,
    output reg  [3:0]  sd_dqm,
    output reg  [1:0]  sd_ba,
    output reg         sd_cke,
    output wire        sd_cs,
    output wire        sd_we,
    output wire        sd_ras,
    output wire        sd_cas,

    // Debug.
    output wire [2:0] dbg_sd_cmd,
    output wire [1:0] dbg_ras1_port,
    output wire [1:0] dbg_cas1_port,
    output wire [4:0] dbg_bankbusy0,
    output wire [4:0] dbg_bankbusy1,
    output wire       dbg_need_refresh_rom,
    output wire       dbg_need_refresh_wram,
    output wire       dbg_force_refresh_rom,
    output wire       dbg_force_refresh_wram,

    output wire [10:0] dbg_refresh_addr_rom,
    output wire [10:0] dbg_refresh_addr_wram,

    output wire [10:0] dbg_bank_row0,
    output wire [10:0] dbg_bank_row1,
    output wire        dbg_bank_rfsh0,
    output wire        dbg_bank_rfsh1,

    output wire [31:0] dbg_sd_data_q,
    output wire [1:0]  dbg_latch2_port,
    output wire [18:0] dbg_latch2_addr,

    output wire [3:0]  dbg_write_recent
);

localparam RAS_WIDTH = 11;
localparam CAS_WIDTH = 8;

// Command encoding and mode register as in NanoMig's sdram.sv.
localparam CMD_NOP          = 3'b111;
localparam CMD_ACTIVE       = 3'b011;
localparam CMD_READ         = 3'b101;
localparam CMD_WRITE        = 3'b100;
localparam CMD_PRECHARGE    = 3'b010;
localparam CMD_AUTO_REFRESH = 3'b001;
localparam CMD_LOAD_MODE    = 3'b000;

localparam BURST_LENGTH   = 3'b001;  // burst of 2
localparam ACCESS_TYPE    = 1'b0;
localparam CAS_LATENCY    = 3'd2;
localparam OP_MODE        = 2'b00;
localparam NO_WRITE_BURST = 1'b1;
localparam [10:0] MODE = {3'b0, NO_WRITE_BURST, OP_MODE, CAS_LATENCY, ACCESS_TYPE, BURST_LENGTH};

reg [2:0] sd_cmd;
assign sd_cs  = 1'b0;
assign sd_ras = sd_cmd[2];
assign sd_cas = sd_cmd[1];
assign sd_we  = sd_cmd[0];

// Which client an access in the pipeline belongs to.
localparam [2:0] PORT_NONE = 3'd0, PORT_ROM = 3'd1, PORT_WRAM = 3'd2,
                 PORT_REFRESH = 3'd3, PORT_ROMW = 3'd4;

// Power-up: precharge all, 8 auto-refreshes, load the mode register.
reg        init = 1'b1;
reg [4:0]  reset_cnt;
localparam [4:0] RESET_START = 5'd20;

wire init_done = ~init;
assign ready = init_done;

// Per-bank busy countdown; bit 4 set = ready.
reg [4:0] bankbusy0, bankbusy1;
wire      bankready0 = bankbusy0[4];
wire      bankready1 = bankbusy1[4];

reg rom_port_state, wram_port_state, romw_port_state;

// A refresh is allowed for a short window after a client request, so it
// slots in between accesses. If none comes in time it is forced.
localparam [3:0] REFRESH_ALLOW_CYCLES = 4'hf;

reg [3:0] romsync_ctr;   reg rom_req_d, romw_req_d;   reg allowrefresh_rom;
reg [3:0] wramsync_ctr;  reg wram_req_d;  reg allowrefresh_wram;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        allowrefresh_rom  <= 1'b0;
        allowrefresh_wram <= 1'b0;
        rom_req_d  <= 1'b0;
        romw_req_d <= 1'b0;
        wram_req_d <= 1'b0;
        romsync_ctr  <= 4'd0;
        wramsync_ctr <= 4'd0;
    end else begin
        rom_req_d  <= rom_req;
        romw_req_d <= sdcw_req;
        if (|romsync_ctr) romsync_ctr <= romsync_ctr - 4'd1;
        else allowrefresh_rom <= 1'b0;
        if ((rom_req_d != rom_req) || (romw_req_d != sdcw_req)) begin
            allowrefresh_rom <= 1'b1;
            romsync_ctr      <= REFRESH_ALLOW_CYCLES;
        end

        wram_req_d <= wram_req;
        if (|wramsync_ctr) wramsync_ctr <= wramsync_ctr - 4'd1;
        else allowrefresh_wram <= 1'b0;
        if (wram_req_d != wram_req) begin
            allowrefresh_wram <= 1'b1;
            wramsync_ctr      <= REFRESH_ALLOW_CYCLES;
        end
    end
end

wire need_refresh_rom,  force_refresh_rom;
wire need_refresh_wram, force_refresh_wram;
wire [RAS_WIDTH-1:0] refresh_addr_rom, refresh_addr_wram;

// One refresh scheduler per bank in use.
refresh_schedule #(.ROWBITS(RAS_WIDTH), .RAM_CLOCK_SPEED(RAM_CLOCK_SPEED)) refresh_rom (
    .clk(clk), .reset_n(reset_n),
    .refreshing(cas2_port == PORT_REFRESH && cas2_ba == 2'b00),
    .allow(allowrefresh_rom),
    .refresh_req(need_refresh_rom), .refresh_force(force_refresh_rom),
    .addr(refresh_addr_rom)
);
refresh_schedule #(.ROWBITS(RAS_WIDTH), .RAM_CLOCK_SPEED(RAM_CLOCK_SPEED)) refresh_wram (
    .clk(clk), .reset_n(reset_n),
    .refreshing(cas2_port == PORT_REFRESH && cas2_ba == 2'b01),
    .allow(allowrefresh_wram),
    .refresh_req(need_refresh_wram), .refresh_force(force_refresh_wram),
    .addr(refresh_addr_wram)
);

// Per-bank request latch, picked each cycle: a client request, unless a
// refresh is being forced, otherwise a refresh when one is due.
reg                 bank_req0,  bank_req1;
reg                 bank_we0,   bank_we1;
reg                 bank_rfsh0, bank_rfsh1;
reg                 bank_owner0;
reg [CAS_WIDTH-1:0] bank_col0,  bank_col1;
reg [RAS_WIDTH-1:0] bank_row0,  bank_row1;
reg [31:0]          bank_wdata0, bank_wdata1;
reg [3:0]           bank_dqm0,  bank_dqm1;

always @(posedge clk) begin
    if (!force_refresh_rom && (rom_req ^ rom_port_state)) begin
        bank_req0   <= 1'b1;
        bank_rfsh0  <= 1'b0;
        bank_owner0 <= 1'b0;
        bank_we0    <= rom_we;
        bank_col0   <= rom_addr[CAS_WIDTH-1:0];
        bank_row0   <= rom_addr[18:CAS_WIDTH];
        bank_wdata0 <= rom_din;
        bank_dqm0   <= rom_dqm;
    end else if (!force_refresh_rom && (sdcw_req ^ romw_port_state)) begin
        bank_req0   <= 1'b1;
        bank_rfsh0  <= 1'b0;
        bank_owner0 <= 1'b1;
        bank_we0    <= 1'b1;
        bank_col0   <= sdcw_addr[CAS_WIDTH-1:0];
        bank_row0   <= sdcw_addr[18:CAS_WIDTH];
        bank_wdata0 <= sdcw_din;
        bank_dqm0   <= sdcw_dqm;
    end else begin
        bank_req0   <= need_refresh_rom;
        bank_rfsh0  <= 1'b1;
        bank_we0    <= 1'b0;
        bank_dqm0   <= 4'hF;
        bank_row0   <= refresh_addr_rom;
    end
end

always @(posedge clk) begin
    if (!force_refresh_wram && (wram_req ^ wram_port_state)) begin
        bank_req1   <= 1'b1;
        bank_rfsh1  <= 1'b0;
        bank_we1    <= wram_we;
        bank_col1   <= wram_addr[CAS_WIDTH-1:0];
        bank_row1   <= wram_addr[18:CAS_WIDTH];
        bank_wdata1 <= wram_din;
        bank_dqm1   <= wram_dqm;
    end else begin
        bank_req1   <= need_refresh_wram;
        bank_rfsh1  <= 1'b1;
        bank_we1    <= 1'b0;
        bank_dqm1   <= 4'hF;
        bank_row1   <= refresh_addr_wram;
    end
end

// Write-after-read spacing: a write waits one slot after a read so the two
// never drive DQ at the same time.
reg [1:0] readcycles;
reg       writeblocked;
always @(posedge clk) writeblocked <= |readcycles;

// Pipeline stages: RAS (2) -> CAS (2) -> MASK -> LATCH (2, 3).
reg [2:0]           ras1_port, ras2_port;
reg [1:0]           ras_ba;
reg [CAS_WIDTH-1:0] ras_col;
reg                 ras_wr;
reg [31:0]          ras_wdata;
reg [3:0]           ras_dqm;

reg [2:0]            cas1_port, cas2_port;
reg [1:0]            cas_ba, cas2_ba;
reg [RAS_WIDTH-1:0]  cas_addr;
reg                  cas_wr;
reg [31:0]           cas_wdata;
reg [3:0]            cas_dqm;

reg [2:0] mask2_port;
reg       mask_wr;

reg [3:0] write_recent_sr;

reg [2:0] latch1_port, latch2_port;

reg [2:0] latch3_port;

reg [RAS_WIDTH-1:0] ras_row;
reg [18:0] cas1_addr, cas2_addr, mask_addr, latch1_addr, latch2_addr;

reg        drive_dq;
reg [31:0] dq_reg;
assign sd_data = drive_dq ? dq_reg : {32{1'bz}};

// keeps DQM low one cycle more for the second burst word
reg dqm_extend_r;

reg [31:0] sd_data_q;
always @(posedge clk) sd_data_q <= sd_data;

always @(posedge clk, negedge reset_n) begin
    if (!reset_n) begin
        sd_cmd          <= CMD_NOP;
        sd_cke          <= 1'b0;
        sd_addr         <= 11'd0;
        sd_ba           <= 2'd0;
        sd_dqm          <= 4'hF;
        rom_port_state  <= 1'b0;
        wram_port_state <= 1'b0;
        romw_port_state <= 1'b0;
        bankbusy0       <= 5'h1F;
        bankbusy1       <= 5'h1F;
        init            <= 1'b1;
        reset_cnt       <= RESET_START;
        readcycles      <= 2'd0;
        drive_dq        <= 1'b0;
        ras1_port <= PORT_NONE; ras2_port <= PORT_NONE;
        cas1_port <= PORT_NONE; cas2_port <= PORT_NONE;
        mask2_port  <= PORT_NONE;
        latch1_port <= PORT_NONE;
        dqm_extend_r <= 1'b0;
    end else begin
        sd_cke   <= 1'b1;
        drive_dq <= 1'b0;

        bankbusy0 <= bankready0 ? bankbusy0 : bankbusy0 - 5'd1;
        bankbusy1 <= bankready1 ? bankbusy1 : bankbusy1 - 5'd1;

        sd_addr <= cas_addr;
        sd_dqm  <= 4'hF;

        if (init) begin
            sd_cmd <= CMD_NOP;
            if (bankready0) begin
                case (reset_cnt)
                    5'd20: cas_addr[10] <= 1'b1;
                    5'd19: sd_cmd <= CMD_PRECHARGE;
                    5'd15: sd_cmd <= CMD_AUTO_REFRESH;
                    5'd14: sd_cmd <= CMD_AUTO_REFRESH;
                    5'd13: sd_cmd <= CMD_AUTO_REFRESH;
                    5'd12: sd_cmd <= CMD_AUTO_REFRESH;
                    5'd11: sd_cmd <= CMD_AUTO_REFRESH;
                    5'd10: sd_cmd <= CMD_AUTO_REFRESH;
                    5'd9:  sd_cmd <= CMD_AUTO_REFRESH;
                    5'd8:  sd_cmd <= CMD_AUTO_REFRESH;
                    5'd3:  cas_addr <= MODE;
                    5'd2:  begin sd_cmd <= CMD_LOAD_MODE; sd_ba <= 2'b00; end
                    default: ;
                endcase
                reset_cnt <= reset_cnt - 5'd1;
                bankbusy0 <= BANK_DELAY[4:0];
                if (reset_cnt == 5'd0) begin
                    init      <= 1'b0;
                    bankbusy0 <= 5'd0;
                    bankbusy1 <= 5'd0;
                end
            end
        end else begin
            sd_cmd <= CMD_NOP;

            ras1_port <= PORT_NONE;
            ras2_port <= ras1_port;

            // RAS: start an access on a ready bank, bank 0 first.
            if (ras1_port == PORT_NONE && cas1_port == PORT_NONE) begin
                readcycles <= {1'b0, readcycles[1]};

                if (bank_req0 && bankready0 && !(writeblocked && bank_we0)) begin
                    readcycles[0]  <= ~bank_we0;
                    if (!bank_rfsh0) begin
                        if (bank_owner0) romw_port_state <= sdcw_req;
                        else             rom_port_state  <= rom_req;
                    end
                    bankbusy0 <= BANK_DELAY[4:0];
                    ras_ba    <= 2'b00;
                    ras_col   <= bank_col0;
                    ras_row   <= bank_row0;
                    ras_wr    <= bank_we0;
                    ras_wdata <= bank_wdata0;
                    ras_dqm   <= bank_dqm0;
                    ras1_port <= bank_rfsh0 ? PORT_REFRESH :
                                 (bank_owner0 ? PORT_ROMW : PORT_ROM);
                    sd_cmd    <= CMD_ACTIVE;
                    sd_addr   <= bank_row0;
                    sd_ba     <= 2'b00;
                end else if (bank_req1 && bankready1 && !(writeblocked && bank_we1)) begin
                    readcycles[0]  <= ~bank_we1;
                    if (!bank_rfsh1) wram_port_state <= wram_req;
                    bankbusy1 <= BANK_DELAY[4:0];
                    ras_ba    <= 2'b01;
                    ras_col   <= bank_col1;
                    ras_row   <= bank_row1;
                    ras_wr    <= bank_we1;
                    ras_wdata <= bank_wdata1;
                    ras_dqm   <= bank_dqm1;
                    ras1_port <= bank_rfsh1 ? PORT_REFRESH : PORT_WRAM;
                    sd_cmd    <= CMD_ACTIVE;
                    sd_addr   <= bank_row1;
                    sd_ba     <= 2'b01;
                end
            end

            // Prepare CAS: column with A10 set = auto-precharge.
            if (ras2_port != PORT_NONE) begin
                cas_addr <= {1'b1, {(RAS_WIDTH-CAS_WIDTH-1){1'b0}}, ras_col};
                cas_wr    <= ras_wr;
                cas_dqm   <= ras_dqm;
                cas_wdata <= ras_wdata;
                cas_ba    <= ras_ba;
            end
            cas1_port <= ras2_port;
            cas1_addr <= {ras_row, ras_col};

            // CAS
            if (cas1_port != PORT_NONE) begin
                sd_ba <= cas_ba;
                if (cas_wr) begin
                    sd_cmd    <= CMD_WRITE;
                    bankbusy0 <= (cas_ba == 2'b00) ? BANK_WRITE_DELAY[4:0] : bankbusy0;
                    bankbusy1 <= (cas_ba == 2'b01) ? BANK_WRITE_DELAY[4:0] : bankbusy1;
                    drive_dq  <= 1'b1;
                    dq_reg    <= cas_wdata;
                    sd_dqm    <= cas_dqm;
                    dqm_extend_r <= 1'b0;
                end else begin
                    sd_cmd <= CMD_READ;
                    sd_dqm <= 4'h0;
                    dqm_extend_r <= 1'b1;
                end
            end else begin
                dqm_extend_r <= 1'b0;
            end
            if (dqm_extend_r) sd_dqm <= 4'h0;
            cas2_port <= cas1_port;
            cas2_ba   <= cas_ba;
            cas2_addr <= cas1_addr;

            mask2_port <= mask_wr ? PORT_NONE : cas2_port;
            mask_wr    <= cas_wr;
            mask_addr  <= cas2_addr;
            write_recent_sr <= {write_recent_sr[2:0], cas_wr};

            latch1_port <= mask2_port;
            latch1_addr <= mask_addr;
        end
    end
end

// Read data is live on the cycle it is latched, then held.
reg [31:0] rom_dout_r, wram_dout_r;
assign rom_dout  = (latch2_port == PORT_ROM)  ? sd_data_q : rom_dout_r;
assign wram_dout = (latch2_port == PORT_WRAM) ? sd_data_q : wram_dout_r;

reg [31:0] rom_dout2_r;
assign rom_dout2 = rom_dout2_r;

always @(posedge clk, negedge reset_n) begin
    if (!reset_n) begin
        rom_ack     <= 1'b0;
        wram_ack    <= 1'b0;
        sdcw_ack    <= 1'b0;
        latch2_port <= PORT_NONE;
        latch3_port <= PORT_NONE;
        rom_dout_r  <= 32'd0;
        wram_dout_r <= 32'd0;
        rom_dout2_r <= 32'd0;
    end else begin
        // Writes ack as soon as their data is captured in the pipeline; reads ack
        // when they reach the latch stage. As in sdram_amr.sv.
        if (ras_wr) begin
            case (ras2_port)
                PORT_ROM:  rom_ack  <= rom_req;
                PORT_WRAM: wram_ack <= wram_req;
                PORT_ROMW: sdcw_ack <= sdcw_req;
                default: ;
            endcase
        end

        latch2_port <= latch1_port;
        latch2_addr <= latch1_addr;
        latch3_port <= latch2_port;

        case (latch1_port)
            PORT_ROM:  rom_ack  <= rom_req;
            PORT_WRAM: wram_ack <= wram_req;
            PORT_ROMW: sdcw_ack <= sdcw_req;
            default: ;
        endcase

        case (latch2_port)
            PORT_ROM:  rom_dout_r  <= sd_data_q;
            PORT_WRAM: wram_dout_r <= sd_data_q;
            default: ;
        endcase

        // the burst's second word, one cycle after the first
        if (latch3_port == PORT_ROM) rom_dout2_r <= sd_data_q;
    end
end

assign dbg_sd_cmd    = sd_cmd;
assign dbg_ras1_port = ras1_port[1:0];
assign dbg_cas1_port = cas1_port[1:0];
assign dbg_bankbusy0 = bankbusy0;
assign dbg_bankbusy1 = bankbusy1;
assign dbg_need_refresh_rom   = need_refresh_rom;
assign dbg_need_refresh_wram  = need_refresh_wram;
assign dbg_force_refresh_rom  = force_refresh_rom;
assign dbg_force_refresh_wram = force_refresh_wram;
assign dbg_refresh_addr_rom   = refresh_addr_rom;
assign dbg_refresh_addr_wram  = refresh_addr_wram;

assign dbg_bank_row0  = bank_row0;
assign dbg_bank_row1  = bank_row1;
assign dbg_bank_rfsh0 = bank_rfsh0;
assign dbg_bank_rfsh1 = bank_rfsh1;

assign dbg_sd_data_q   = sd_data_q;
assign dbg_latch2_port = latch2_port[1:0];
assign dbg_latch2_addr = latch2_addr;
assign dbg_write_recent = write_recent_sr;

endmodule

// Refresh scheduler.
`ifdef YOSYS
`define BK2_ITOR(x) $itor(x)
`define BK2_RTOI(x) $rtoi(x)
`else
`define BK2_ITOR(x) (real'(int'(x)))
`define BK2_RTOI(x) (int'(real'(x)))
`endif

module refresh_schedule #(
    parameter ROWBITS          = 11,
    parameter RAM_CLOCK_SPEED  = 78_000_000,
    parameter real TREF_MS     = 64.0,
    // Refreshes per TREF_MS: more than the 2048 rows strictly need. The
    // datasheet's 4096 made boots fail on hardware; the cause was not found.
    parameter integer REFRESH_CYCLES = 3072
) (
    input  wire clk,
    input  wire reset_n,
    input  wire refreshing,
    input  wire allow,
    output wire refresh_req,
    output wire refresh_force,
    output wire [ROWBITS-1:0] addr
);

localparam real CLK_PERIOD_NS = 1.0e9 / `BK2_ITOR(RAM_CLOCK_SPEED);
localparam integer TICKS_PER_REFRESH =
    `BK2_RTOI((TREF_MS * 1.0e6) / CLK_PERIOD_NS / `BK2_ITOR(REFRESH_CYCLES)) - 2;
localparam integer FORCE_TIME = TICKS_PER_REFRESH - 4;
localparam CNT_W = $clog2(TICKS_PER_REFRESH + 1);

reg [CNT_W-1:0]   refresh_count;
reg               need_refresh_r, force_refresh_r;
reg [ROWBITS-1:0] addr_r;

// Asked for when allowed, forced shortly before the interval runs out.
assign refresh_req   = (allow & need_refresh_r) | force_refresh_r;
assign refresh_force = force_refresh_r;
assign addr           = addr_r;

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        addr_r          <= {ROWBITS{1'b0}};
        refresh_count   <= {CNT_W{1'b0}};
        need_refresh_r  <= 1'b0;
        force_refresh_r <= 1'b0;
    end else begin
        refresh_count <= refresh_count + 1'b1;

        if (refreshing) begin
            need_refresh_r  <= 1'b0;
            force_refresh_r <= 1'b0;
            addr_r          <= addr_r + 1'b1;
        end

        if (refresh_count == TICKS_PER_REFRESH[CNT_W-1:0]) begin
            need_refresh_r <= 1'b1;
            refresh_count  <= {CNT_W{1'b0}};
        end

        if (refresh_count == FORCE_TIME[CNT_W-1:0]) force_refresh_r <= need_refresh_r;
    end
end

endmodule
`default_nettype wire
