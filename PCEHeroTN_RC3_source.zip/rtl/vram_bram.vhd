-- vram_bram.vhd -- PCEHeroTN
--
-- The VDC's 64 KB VRAM (32768 x 16) in block RAM, as a thin wrapper on
-- dpram.vhd with the geometry fixed, so the Verilog top needs no generics.
--
-- The VDC uses one address with read and write in separate slots, so one
-- port is enough; port B is tied off. One clock of read latency, as the
-- huc6270 fetch schedule expects.
--
-- Why not an inferred Verilog array: Gowin ignores the syn_ramstyle
-- attribute in that form and built part of it from fabric. dpram's VHDL
-- attribute is honoured.

library ieee;
use ieee.std_logic_1164.all;

library work;

entity vram_bram is
    port (
        clk  : in  std_logic;
        addr : in  std_logic_vector(14 downto 0);
        din  : in  std_logic_vector(15 downto 0);
        we   : in  std_logic;
        dout : out std_logic_vector(15 downto 0)
    );
end entity;

architecture rtl of vram_bram is
begin

    u_dpram : entity work.dpram
        generic map (
            addr_width    => 15,
            data_width    => 16,
            mem_init_file => " ",
            disable_value => '0'
        )
        port map (
            clock     => clk,

            address_a => addr,
            data_a    => din,
            enable_a  => '1',
            wren_a    => we,
            q_a       => dout,
            cs_a      => '1',

            address_b => (others => '0'),
            data_b    => (others => '0'),
            enable_b  => '1',
            wren_b    => '0',
            q_b       => open,
            cs_b      => '1'
        );

end architecture;
