// sdc_mcu_buffer.v -- PCEHeroTN
//
// One 512-byte SD sector buffer with a port on each clock: the companion's
// SPI side (clk_pixel) and the SD card reader (clk_sys). A true dual-port
// RAM is the simple, safe way to move a whole block between two unrelated
// clocks. The two sides never touch it at the same time: the MCU only reads
// after the reader has signalled the sector is complete.
//
// Modelled on sector_dpram in NanoMig's src/misc/sd_card.v.
//
module sdc_mcu_buffer (
    input        clk_a,      // clk_pixel: companion/MCU side
    input  [8:0] addr_a,
    input  [7:0] din_a,
    input        we_a,
    output reg [7:0] dout_a,

    input        clk_b,      // clk_sys: SD reader side
    input  [8:0] addr_b,
    input  [7:0] din_b,
    input        we_b,
    output reg [7:0] dout_b
);

reg [7:0] mem [0:511];

always @(posedge clk_a) begin
    if (we_a) mem[addr_a] <= din_a;
    dout_a <= mem[addr_a];
end

always @(posedge clk_b) begin
    if (we_b) mem[addr_b] <= din_b;
    dout_b <= mem[addr_b];
end

endmodule
