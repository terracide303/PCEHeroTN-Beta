// joypad.v -- PCEHeroTN
//
// The PC Engine pad port as the HuC6280 sees it: JOY_OUT[0] is SEL, JOY_OUT[1]
// is CLR, and the CPU reads a 4-bit nibble back on JOY_IN. With SEL=0 the
// nibble is Run, Select, II, I; with SEL=1 it is Left, Down, Right, Up. The
// upper nibble (region / CD presence) is driven by pce_top_extram, not here.
//
// Real pad lines are pulled up, so a pressed button reads 0. The pad inputs
// here are active-high; the one inversion happens in this module.
//
// D-pad bit order is Up=0, Right=1, Down=2, Left=3, as in the CD-ROM2 BIOS
// manual's EX_JOYSNS byte. (Torlus's DE0-Nano core swaps Right and Down.)
//
// Multitap and turbo follow MiSTer's TurboGrafx16.sv input block:
//   - CLR high resets the tap to port 0 and reads 0000 (a lone pad does the
//     same); each SEL rising edge with CLR low steps to the next port.
//     Port 0 = P1, port 1 = P2, ports 2-7 read as empty sockets.
//     MULTITAP=0 keeps the port at 0.
//   - Turbo: III/IV are turbo I/II toggling every 4 pad scans, V/VI every 2.
//     The rate counts the game's own scans (one per CLR edge), not time, so a
//     game polling once a frame gets 7.5 Hz and 15 Hz.
//
// pN = {run, select, ii, i, left, down, right, up}.

`default_nettype none

module joypad #(
    parameter MULTITAP = 1
) (
    input  wire        clk,          // clk_sys, the domain JOY_OUT comes from
    input  wire        joy_out_sel,  // JOY_OUT[0] from pce_top_extram
    input  wire        joy_out_clr,  // JOY_OUT[1] from pce_top_extram

    input  wire [7:0]  p1,           // {run, select, ii, i, left, down, right, up}
    input  wire [7:0]  p2,
    input  wire [3:0]  p1_turbo,     // {VI, V, IV, III}, active-high
    input  wire [3:0]  p2_turbo,
    input  wire        turbo_en,     // OSD Controller = 2 Turbo

    output reg  [3:0]  joy_in = 4'hF // to pce_top_extram's JOY_IN
);

reg [2:0] joy_port = 3'd0;
reg       last_sel = 1'b0;
reg       last_clr = 1'b0;
reg [3:0] scan_counter = 4'd0;
reg [1:0] rept1 = 2'b00, rept2 = 2'b00;   // {ii, i} with turbo applied

wire [7:0] p1_eff = turbo_en ? {p1[7:6], rept1, p1[3:0]} : p1;
wire [7:0] p2_eff = turbo_en ? {p2[7:6], rept2, p2[3:0]} : p2;

wire [7:0] port_data = (joy_port == 3'd0) ? ~p1_eff :
                       (joy_port == 3'd1) ? ~p2_eff : 8'hFF;

always @(posedge clk) begin
    last_sel <= joy_out_sel;
    last_clr <= joy_out_clr;

    if (joy_out_clr && !last_clr) begin
        scan_counter <= scan_counter + 4'd1;
        rept1[0] <= (p1_turbo[0] & scan_counter[2]) | (p1_turbo[2] & scan_counter[1]) | p1[4];
        rept1[1] <= (p1_turbo[1] & scan_counter[2]) | (p1_turbo[3] & scan_counter[1]) | p1[5];
        rept2[0] <= (p2_turbo[0] & scan_counter[2]) | (p2_turbo[2] & scan_counter[1]) | p2[4];
        rept2[1] <= (p2_turbo[1] & scan_counter[2]) | (p2_turbo[3] & scan_counter[1]) | p2[5];
    end

    joy_in   <= joy_out_sel ? port_data[3:0] : port_data[7:4];

    if (joy_out_clr) begin
        joy_port <= 3'd0;
        joy_in   <= 4'h0;
    end else if (MULTITAP && joy_out_sel && !last_sel)
        joy_port <= joy_port + 3'd1;
end

endmodule

`default_nettype wire
