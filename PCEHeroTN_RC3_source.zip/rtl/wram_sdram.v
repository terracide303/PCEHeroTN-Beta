// wram_sdram.v -- PCEHeroTN
//
// The CPU's 8 KB work RAM served from SDRAM, for builds where the core's
// on-chip work RAM is turned off (pce_top_extram USE_INTERNAL_RAM = 0). The
// shipping build keeps work RAM in block RAM (WRAM_BRAM=1) and ignores this
// module's data and ready, but this module still runs and makes an SDRAM
// access for every work-RAM cycle.
//
// Same shape as rom_loader's ROM client, plus writes: one SDRAM access per
// CPU work-RAM cycle, and wram_rdy is ANDed into ROM_RDY so the CPU waits
// (WAIT_N) until the access is done. Ready is high when idle and at reset;
// a low-at-reset ready would freeze the CPU before its first access.
//
// It shares the SDRAM CPU port with rom_loader without an arbiter: the CPU
// makes one memory access at a time, and a ROM miss stalls it, so the two
// are never active in the same cycle. `active` just selects the port mux.
//
// Work RAM sits in SDRAM bank 1 (0x200000), away from ROM (bank 0) and the
// old VRAM area (bank 3).

module wram_sdram #(
    // Byte address; bits [22:21] = 01 select bank 1. 8 KB window = ext_a[12:0].
    parameter [22:0] WRAM_BASE = 23'h200000,
    // Test only: 1 brings back the old W_REL exit (on the strobes dropping) so a
    // testbench can reproduce the hang. Must be 0 in a build.
    parameter        WREL_LEGACY = 0
) (
    input  wire        clk,  // clk_sys
    input  wire        rstn,
    input  wire        loading,  // idle through the ROM copy
    input  wire        mem_ready,
    input  wire        cpu_ce,  // HuC6280 CPU_CE: one pulse per completed memory cycle

    // From pce_top_extram's EXT_RAM port. ce/rd/wr are levels held for the whole
    // memory cycle, including any stall.
    input  wire        ext_ce,
    input  wire        ext_rd,
    input  wire        ext_wr,
    input  wire [21:0] ext_a,
    input  wire [7:0]  ext_do,
    output reg  [7:0]  ext_di,  // read data back to the CPU
    output wire        wram_rdy,  // ANDed into ROM_RDY; high when idle

    // SDRAM CPU port, shared with rom_loader through the top's mux.
    output reg  [22:0] ram_addr,
    output reg  [7:0]  ram_din,
    output reg         ram_req,
    output reg         ram_write,
    input  wire [7:0]  ram_dout,
    input  wire        ram_busy,

    output wire        active  // this FSM owns the CPU port
);

    localparam [2:0] W_IDLE = 3'd0,
                     W_REQ  = 3'd1,
                     W_WAIT = 3'd2,
                     W_REL  = 3'd3;  // done; wait for the CPU to finish its cycle

    reg [2:0] st;

    // ext_rd and ext_wr are never both high.
    wire new_access = ext_ce & (ext_rd | ext_wr) & ~loading & mem_ready;

    assign active   = (st != W_IDLE);
    // Ready except while an access is in flight.
    assign wram_rdy = (st == W_IDLE) | (st == W_REL);

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            st        <= W_IDLE;
            ram_addr  <= 23'd0;
            ram_din   <= 8'd0;
            ram_req   <= 1'b0;
            ram_write <= 1'b0;
            ext_di    <= 8'hFF;
        end else begin
            case (st)

            W_IDLE:
                if (new_access) begin
                    ram_addr  <= WRAM_BASE | {10'd0, ext_a[12:0]};
                    ram_din   <= ext_do;
                    ram_write <= ext_wr;
                    ram_req   <= 1'b1;
                    st        <= W_REQ;
                end

            // busy rises = accepted; busy falls after ram_req drops = done.
            W_REQ:
                if (ram_busy) begin
                    ram_req <= 1'b0;
                    st      <= W_WAIT;
                end

            W_WAIT:
                if (!ram_busy) begin
                    if (!ram_write)
                        ext_di <= ram_dout;
                    st <= W_REL;
                end

            // Release on cpu_ce, not on the strobes falling: back-to-back work-RAM
            // cycles (zero page, stack, read-modify-write) keep the strobes high, and
            // the FSM would never leave W_REL.
            W_REL:
                if (WREL_LEGACY ? !(ext_rd | ext_wr) : cpu_ce)
                    st <= W_IDLE;

            default: st <= W_IDLE;

            endcase
        end
    end

endmodule
