// pce_video.v -- PCEHeroTN
//
// Not used: analysed by the build but never instantiated. The earlier video
// path (a ping-pong line buffer into a free-running 480p generator), replaced
// by pce_scandoubler.v. Still listed in the build script because removing it
// would change the bitstream.

module pce_video #(
    parameter H_ACTIVE   = 720,
    parameter V_ACTIVE   = 480,
    parameter SRC_WIDTH  = 256,
    parameter SRC_HEIGHT = 240,
    parameter BORDER_BARS = 1,

    parameter RESYNC       = 0,
    parameter RESYNC_GUARD = 20
) (
    input  wire        clk_sys,
    input  wire        video_ce,
    input  wire [2:0]  video_r,
    input  wire [2:0]  video_g,
    input  wire [2:0]  video_b,
    input  wire        video_hbl,
    input  wire        video_vbl,

    input  wire        clk_pixel,
    input  wire [9:0]  cx,
    input  wire [9:0]  cy,
    input  wire [9:0]  frame_height,
    output reg  [23:0] rgb,

    output reg         hdmi_resync
);

localparam X_OFFSET = (H_ACTIVE - SRC_WIDTH*2) / 2;

reg [8:0] linebuf [0:1023];
reg       wr_sel = 0;

reg [9:0] wr_x   = 0;
reg       hbl_d  = 1;
reg       vbl_d  = 1;
reg       fs_toggle = 0;

always @(posedge clk_sys) begin
    hbl_d <= video_hbl;
    vbl_d <= video_vbl;

    if (hbl_d && !video_hbl) begin
        wr_x   <= 0;
        wr_sel <= ~wr_sel;
    end else if (video_ce && !video_hbl && wr_x < SRC_WIDTH) begin
        linebuf[{wr_sel, wr_x[8:0]}] <= {video_r, video_g, video_b};
        wr_x <= wr_x + 1'b1;
    end

    if (vbl_d && !video_vbl)
        fs_toggle <= ~fs_toggle;
end

wire [9:0] src_x = (cx >= X_OFFSET) ? ((cx - X_OFFSET) >> 1) : 10'd0;
wire       in_picture = (cx >= X_OFFSET) && (cx < X_OFFSET + SRC_WIDTH*2)
                     && (cy < SRC_HEIGHT*2);

reg [8:0] pix;
always @(posedge clk_pixel) begin
    pix <= linebuf[{~wr_sel, src_x[8:0]}];

    rgb <= in_picture
         ? { {pix[8:6], pix[8:6], pix[8:7]},
             {pix[5:3], pix[5:3], pix[5:4]},
             {pix[2:0], pix[2:0], pix[2:1]} }
         : border_rgb;
end

reg [23:0] border_rgb;
always @(posedge clk_pixel) begin
    if (BORDER_BARS == 0)
        border_rgb <= 24'h000000;
    else case (cy[7:5])
        3'd0: border_rgb <= 24'hFFFFFF;
        3'd1: border_rgb <= 24'hFFFF00;
        3'd2: border_rgb <= 24'h00FFFF;
        3'd3: border_rgb <= 24'h00FF00;
        3'd4: border_rgb <= 24'hFF00FF;
        3'd5: border_rgb <= 24'hFF0000;
        3'd6: border_rgb <= 24'h0000FF;
        3'd7: border_rgb <= 24'h404040;
    endcase
end

localparam [9:0] GUARD = RESYNC_GUARD;
reg fs_meta = 0, fs_sync = 0, fs_d = 0;
always @(posedge clk_pixel) begin
    fs_meta <= fs_toggle;
    fs_sync <= fs_meta;
    fs_d    <= fs_sync;

    hdmi_resync <= 1'b0;
    if (RESYNC != 0 && (fs_sync ^ fs_d)) begin
        if (frame_height > (GUARD << 1)
            && cy > GUARD && cy < (frame_height - GUARD))
            hdmi_resync <= 1'b1;
    end
end

endmodule
