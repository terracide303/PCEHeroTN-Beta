// pce_scandoubler.v -- PCEHeroTN
//
// The PC Engine's video into a 480p DVI/HDMI raster, timed by the console
// itself rather than by a free-running video timing generator. A free-running
// generator drifts against the console and the picture rolls. This follows
// Torlus's FPGAPCE, where the scandoubler sits on the core clock.
//
// Two clocks. Line writes are on clk_sys; everything on the output side runs
// on clk_pixel = clk_sys * 2/3, from a second PLL fed by clk_sys, so the
// ratio is exact:
// one source line (2730 clk_sys) is exactly two output lines of OLINE = 910
// clk_pixel. Nothing accumulates, and the HDMI encoder is never reset, so the
// TV stays locked. Output frame rate = console frame rate.
//
// Per source line a toggle crosses to clk_pixel and realigns the output line
// counter; per frame another toggle zeroes the row counter during vertical
// blanking, which absorbs the console's 262/263-line alternation.
//
// The line buffer holds 4 lines so the CRT-Lite kernel (crt_lite_px) can
// read the line above, this line and the line below for every output pixel.
// With CRT-Lite on the picture sits one source line (2 output rows) lower.
//
// Horizontal: all three dot clocks (5.37 / 7.16 / 10.74 MHz) are resampled
// onto the same output width, as a real console fills the same screen width
// in each. In 10.74 MHz mode the last ~28 border dots fall outside the
// 512-dot buffer.

module pce_scandoubler #(
    // OLINE = 2730 clk_sys * (2/3) / 2
    parameter OLINE           = 910,
    parameter HS_WIDTH        = 64,
    parameter VS_LINES_OUT    = 6,

    // Data-enable window.
    parameter H_ACT_START     = 95,
    parameter H_ACT_W         = 720,
    parameter V_ACT_START     = 38,
    parameter V_ACT_H          = 480,

    // Source content fills this fixed window in every dot-clock mode.
    parameter H_CONT_START    = 95,
    parameter H_CONT_W        = 720,
    parameter V_CONTENT_START = 40,

    // Value ox is set to at each synced source line start; see READ PHASE.
    parameter H_RD_ALIGN      = 190,
    parameter SRC_H           = 240,

    parameter LBUF_DEPTH      = 512,
    parameter LBUF_AW         = 9,

    // Active dots per mode (2160 clk_sys / 8, 6, 4). NDOT2 is clamped to LBUF_DEPTH.
    parameter NDOT0           = 270,
    parameter NDOT1           = 360,
    parameter NDOT2           = 540,

    // Colour bars in the pillarbox instead of black (bring-up aid).
    parameter BORDER_BARS     = 0
) (
    // Source: the console, clk_sys.
    input  wire        clk_sys,
    input  wire        ce,  // VIDEO_CE: one pulse per dot
    input  wire [2:0]  r,
    input  wire [2:0]  g,
    input  wire [2:0]  b,
    input  wire        hs,  // unused; timing keys off HBL and VS
    input  wire        vs,  // active high
    input  wire        hbl,  // 1 = blanking
    input  wire        vbl,  // 1 = line outside the VCE's shown window (Overscan)
    input  wire [1:0]  dcc,  // dot clock: 00=5.37 01=7.16 1x=10.74 MHz

    // Sink: clk_pixel.
    input  wire        clk_pixel,
    output reg  [23:0] rgb,
    output reg         de,
    output reg         hsync,  // high in active, low during the pulse
    output reg         vsync,

    // CRT-Lite on (1) or plain line doubling (0). An OSD setting; sampled once per line.
    input  wire        crt_en
);

// Line buffer: a ring of 4 lines of 9-bit {r,g,b}, written on clk_sys and
// read on clk_pixel. Safe across the clocks because the reader never uses the
// lane being written.
//
// Two SDPX9B blocks, each written 9 bits wide and read 18 bits wide: block j
// holds lanes 2j and 2j+1, so one read returns all four lanes. One block read
// 36 wide is not allowed (UG285 Table 2-4: port B is 2K x 9 or 1K x 18 only).
// It builds and simulates cleanly, but the data comes back scrambled on silicon.
// Instantiated by hand: Gowin does not infer mixed-width RAM.
localparam integer LB_AW = 9;

reg [LBUF_AW:0] wr_dot    = 0;
reg             hbl_d     = 1'b1;
reg             vs_d      = 1'b0;
reg             wr_sel    = 1'b0;  // toggles per source line
reg  [1:0]      wr_lane   = 2'd0;
reg             fs_toggle = 1'b0;
// Dot-clock mode each lane was written in. Games may change mode on any line,
// so the reader uses the lane's own mode, not the live dcc.
reg  [7:0]      lane_dcc  = 8'd0;
// Whether each lane's line is inside the VCE's shown window. Blanked lines
// are drawn black (MiSTer crops them; our raster is fixed).
reg  [3:0]      lane_vbl  = 4'hF;

wire line_begin = hbl_d && !hbl;
wire lb_we      = !line_begin && ce && !hbl && (wr_dot < LBUF_DEPTH);
wire [LB_AW-1:0] wr_dot9 = wr_dot[LBUF_AW-1:0];
wire [1:0]      wr_next = wr_lane + 2'd1;

always @(posedge clk_sys) begin
    hbl_d <= hbl;
    vs_d  <= vs;

    if (line_begin) begin
        wr_sel  <= ~wr_sel;
        wr_lane <= wr_next;
        wr_dot  <= 0;
        lane_dcc[2*wr_next +: 2] <= dcc;
        lane_vbl[wr_next]        <= vbl;
    end else if (lb_we)
        wr_dot <= wr_dot + 1'b1;

    if (vs && !vs_d)
        fs_toggle <= ~fs_toggle;
end

// clk_pixel: 2-FF sync of the toggles and the per-lane tags. A lane's tags
// change only when the writer enters it, far from the reader, and the reader
// samples them once per line.
reg wsel_m = 1'b0, wsel_s = 1'b0, wsel_sd = 1'b0;
reg fs_m   = 1'b0, fs_s   = 1'b0, fs_sd   = 1'b0;
reg [7:0] ldcc_m = 8'd0, ldcc_s = 8'd0;
reg [3:0] lvbl_m = 4'hF, lvbl_s = 4'hF;

always @(posedge clk_pixel) begin
    wsel_m <= wr_sel;    wsel_s <= wsel_m;   wsel_sd <= wsel_s;
    fs_m   <= fs_toggle; fs_s   <= fs_m;     fs_sd   <= fs_s;
    ldcc_m <= lane_dcc;  ldcc_s <= ldcc_m;
    lvbl_m <= lane_vbl;  lvbl_s <= lvbl_m;
end

wire line_start_p  = wsel_s ^ wsel_sd;
wire frame_start_p = fs_s   ^ fs_sd;

// The writer's lane, Gray-coded on clk_sys and synced. A local counter stepped
// on line_start_p would only agree with wr_lane if both clocks started on the
// same line; they come from different PLL outputs.
reg  [1:0] wr_lane_g = 2'd0;
always @(posedge clk_sys) wr_lane_g <= wr_lane ^ (wr_lane >> 1);
reg  [1:0] wlg_m = 2'd0, wlg_s = 2'd0;
always @(posedge clk_pixel) begin wlg_m <= wr_lane_g; wlg_s <= wlg_m; end
wire [1:0] rd_wlane = {wlg_s[1], wlg_s[1] ^ wlg_s[0]};

// Displayed lane: the newest finished line, or one older with CRT-Lite (it
// needs the line below, and the newest finished line is the only candidate).
wire [1:0] rd_bank = rd_wlane - 2'd1 - {1'b0, crt_en};

// READ PHASE. Port B reads both blocks every clk_pixel, and one block always
// holds the writer's lane. A read and a write to the same address at once is
// not allowed (UG285 3.3). The reader walks the content window faster than
// the writer fills it, so its rows are placed so that they never meet the
// writer's dot: ox is set to H_RD_ALIGN at the line start, so the first row's
// content starts T0 = H_CONT_START - H_RD_ALIGN after it. The reader stays
// clear of the writer while 1440 - 910 - H_CONT_W < T0 < 0. In this build
// (H_CONT_START 135, H_CONT_W 640) T0 = -55, inside (-110, 0), and the
// reader comes no closer than 55 clk_pixel to the writer.
//
// So the line start falls mid-row and only re-phases ox; rows begin at the
// ox wrap. oy is zeroed once per frame on a row-0 boundary, so output lines
// 2M and 2M+1 always show the same source line.
reg [11:0] ox = 0;
reg [9:0]  oy = 0;
reg        vs_pending = 1'b0;
reg        pair_row   = 1'b0;
reg        ls_seen    = 1'b0;  // a line start since the last row boundary

wire oline_start = (ox == OLINE-1);

always @(posedge clk_pixel) begin
    if (frame_start_p) vs_pending <= 1'b1;

    if (oline_start) begin
        ox       <= 12'd0;
        pair_row <= !ls_seen;
        ls_seen  <= line_start_p;
        if (vs_pending && ls_seen) begin
            oy         <= 10'd0;
            vs_pending <= 1'b0;
        end else begin
            oy <= oy + 1'b1;
        end
    end else begin
        if (line_start_p) ls_seen <= 1'b1;
        ox <= line_start_p ? H_RD_ALIGN[11:0] : ox + 1'b1;
    end
end

wire        h_pulse = (ox < HS_WIDTH);
wire        v_pulse = (oy < VS_LINES_OUT);
wire        in_h    = (ox >= H_ACT_START) && (ox < H_ACT_START + H_ACT_W);
wire        in_v    = (oy >= V_ACT_START) && (oy < V_ACT_START + V_ACT_H);

wire        in_cont = (ox >= H_CONT_START) && (ox < H_CONT_START + H_CONT_W)
                   && (oy >= V_CONTENT_START) && (oy < V_CONTENT_START + SRC_H*2);

// Horizontal resampler. The active line is 2160 clk_sys in every mode; only
// the dot rate changes, giving ~270 / 360 / 540 dots. A fixed-point step maps
// the fixed output window onto that count:
//   step = round(n_dots * 2^FRAC / H_CONT_W),  rd_dot = acc >> FRAC.
localparam integer FRAC   = 12;
localparam integer NDOT2C = (NDOT2 > LBUF_DEPTH) ? LBUF_DEPTH : NDOT2;
localparam integer STEP0  = (NDOT0  * (1 << FRAC) + H_CONT_W/2) / H_CONT_W;
localparam integer STEP1  = (NDOT1  * (1 << FRAC) + H_CONT_W/2) / H_CONT_W;
localparam integer STEP2  = (NDOT2C * (1 << FRAC) + H_CONT_W/2) / H_CONT_W;

// Everything a line needs is latched one pixel before the content window
// and held across it.
wire [1:0]  prv_bank = rd_bank - 2'd1;
wire [1:0]  nxt_bank = rd_bank + 2'd1;
wire [1:0]  rd_dcc   = ldcc_s[2*rd_bank +: 2];
wire        rd_vbl   = lvbl_s[rd_bank];

reg  [1:0]  line_dcc  = 2'b0;
reg         line_vbl  = 1'b1;
reg  [1:0]  line_own  = 2'd0, line_prv = 2'd0, line_nxt = 2'd0;
reg         line_crt  = 1'b0;
reg         line_row  = 1'b0;
// A neighbour line is black if it was VBL-blanked, and replaced by this line
// if it was written in another dot-clock mode (its columns do not line up).
reg         prv_black = 1'b0, nxt_black = 1'b0;
reg         prv_self  = 1'b0, nxt_self  = 1'b0;

wire [21:0] step = (line_dcc == 2'b00) ? STEP0[21:0] :
                   (line_dcc == 2'b01) ? STEP1[21:0] : STEP2[21:0];

reg  [21:0] acc = 0;
wire [LBUF_AW-1:0] rd_dot = acc[FRAC + LBUF_AW - 1 -: LBUF_AW];

always @(posedge clk_pixel) begin
    // acc restarts one pixel early so rd_dot == 0 on the first content pixel.
    if (ox == H_CONT_START - 1) begin
        acc       <= 22'd0;
        line_dcc  <= rd_dcc;
        line_vbl  <= rd_vbl;
        line_own  <= rd_bank;
        line_prv  <= prv_bank;
        line_nxt  <= nxt_bank;
        line_crt  <= crt_en;
        line_row  <= pair_row;
        prv_black <= lvbl_s[prv_bank];
        nxt_black <= lvbl_s[nxt_bank];
        prv_self  <= ldcc_s[2*prv_bank +: 2] != rd_dcc;
        nxt_self  <= ldcc_s[2*nxt_bank +: 2] != rd_dcc;
    end else if (ox >= H_CONT_START && ox < H_CONT_START + H_CONT_W)
        acc <= acc + step;
end

// lb_q is valid one clock after rd_dot; lane k is lb_q[9k+8:9k].
wire [35:0] lb_q;
wire [LB_AW-1:0] rd_dot9 = rd_dot;

genvar lj;
generate for (lj = 0; lj < 2; lj = lj + 1) begin : g_lb
    wire [35:0] q;
    SDPX9B #(
        .READ_MODE   (1'b0),  // bypass: one clock
        .BIT_WIDTH_0 (9),  // A: write 9 bits, 2K deep
        .BIT_WIDTH_1 (18),  // B: read 18 bits = 2 lanes, 1K deep
        .BLK_SEL_0   (3'b000),
        .BLK_SEL_1   (3'b000),
        .RESET_MODE  ("SYNC")
    ) linebuf (
        .CLKA    (clk_sys),
        .CEA     (lb_we && (wr_lane[1] == lj)),
        .ADA     ({1'b0, wr_dot9, wr_lane[0], 3'b000}),
        .DI      ({27'd0, r, g, b}),
        .BLKSELA (3'b000),
        .RESETA  (1'b0),
        .CLKB    (clk_pixel),
        .CEB     (1'b1),
        .ADB     ({1'b0, rd_dot9, 4'b0000}),
        .DO      (q),
        .BLKSELB (3'b000),
        .RESETB  (1'b0),
        .OCE     (1'b1)
    );
    assign lb_q[18*lj +: 18] = q[17:0];
end endgenerate

wire [8:0] q_own = lb_q[9*line_own +: 9];
wire [8:0] q_prv = lb_q[9*line_prv +: 9];
wire [8:0] q_nxt = lb_q[9*line_nxt +: 9];

wire [8:0] k_own = q_own;
wire [8:0] k_prv = prv_black ? 9'd0 : prv_self ? q_own : q_prv;
wire [8:0] k_nxt = nxt_black ? 9'd0 : nxt_self ? q_own : q_nxt;

// CRT-Lite kernel, KLAT clocks. Its output replaces the pixel on content
// pixels when the line was latched with crt_en; the plain path is delayed
// to match so the raster does not move when the option toggles.
localparam integer KLAT = 5;
wire [23:0] k_rgb;

crt_lite_px crt (
    .clk   (clk_pixel),
    .ce    (1'b1),
    .phase (line_row),
    .prev  (k_prv),
    .own   (k_own),
    .next  (k_nxt),
    .rgb   (k_rgb)
);

reg         de_d, in_cont_d;
reg  [23:0] rgb_p;
reg         de_p, hs_p, vs_p, use_k_p;

always @(posedge clk_pixel) begin
    de_d      <= in_h && in_v;
    in_cont_d <= in_cont && in_h && in_v && !line_vbl;  // blanked line -> black

    de_p    <= de_d;
    hs_p    <= ~h_pulse;
    vs_p    <= ~v_pulse;
    use_k_p <= de_d && in_cont_d && line_crt;

    if (!de_d)
        rgb_p <= 24'h000000;
    else if (in_cont_d)
        // 3 bits per channel -> 8, replicated so full scale stays full scale.
        rgb_p <= { {q_own[8:6], q_own[8:6], q_own[8:7]},
                   {q_own[5:3], q_own[5:3], q_own[5:4]},
                   {q_own[2:0], q_own[2:0], q_own[2:1]} };
    else if (BORDER_BARS != 0)
        rgb_p <= bar_rgb;
    else
        rgb_p <= 24'h000000;
end

// rgb_p is 1 clock after the taps, k_rgb is KLAT: delay the plain path KLAT-1.
reg [23:0]     rgb_q [0:KLAT-2];
reg [KLAT-2:0] de_q = 0, hs_q = 0, vs_q = 0, usek_q = 0;
integer qi;
always @(posedge clk_pixel) begin
    rgb_q[0] <= rgb_p;
    for (qi = 1; qi < KLAT-1; qi = qi + 1) rgb_q[qi] <= rgb_q[qi-1];
    de_q   <= {de_q[KLAT-3:0],   de_p};
    hs_q   <= {hs_q[KLAT-3:0],   hs_p};
    vs_q   <= {vs_q[KLAT-3:0],   vs_p};
    usek_q <= {usek_q[KLAT-3:0], use_k_p};

    de    <= de_q[KLAT-2];
    hsync <= hs_q[KLAT-2];
    vsync <= vs_q[KLAT-2];
    rgb   <= usek_q[KLAT-2] ? k_rgb : rgb_q[KLAT-2];
end

// pillarbox bars (BORDER_BARS only)
reg [23:0] bar_rgb;
always @(posedge clk_pixel) begin
    case (oy[7:5])
        3'd0: bar_rgb <= 24'hFFFFFF;
        3'd1: bar_rgb <= 24'hFFFF00;
        3'd2: bar_rgb <= 24'h00FFFF;
        3'd3: bar_rgb <= 24'h00FF00;
        3'd4: bar_rgb <= 24'hFF00FF;
        3'd5: bar_rgb <= 24'hFF0000;
        3'd6: bar_rgb <= 24'h0000FF;
        3'd7: bar_rgb <= 24'h404040;
    endcase
end

endmodule
