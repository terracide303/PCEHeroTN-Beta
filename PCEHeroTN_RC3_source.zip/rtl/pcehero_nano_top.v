// pcehero_nano_top.v -- PCEHeroTN top level, Tang Nano 20K
//
// A PC Engine / TurboGrafx-16 (HuCard) on the Tang Nano 20K:
//
//   - The core: pce_top_extram.vhd (MiST/MiSTer TurboGrafx16 core), on
//     clk_sys = 43.2 MHz.
//   - Games load from the SD card through FPGA-Companion's OSD (F12, or
//     button S1). There is no built-in game; until one is loaded the screen
//     shows colour bars.
//   - ROM and SDRAM: the ROM lives in the in-package SDRAM, run by
//     pce_sdram_bank2. VRAM and work RAM are in block RAM.
//   - Video: pce_scandoubler turns the console's 15 kHz picture into 480p,
//     timed by the console itself; optional CRT-Lite scanlines.
//   - Audio: the PSG goes out over HDMI (pce_hdmi_di).
//   - Pads: USB pads through the companion, plus the MiSTeryShield20k's DB9
//     port; two players through a multitap.
//
// The OSD menu reuses the companion's generic settings bits (the firmware
// names them after another core's options):
//   S (system_scanlines)    Scanlines: CRT-Lite on/off
//   A (system_wide_screen)  Overscan: Hidden / Visible
//   C (system_second_scc)   Border colour: Original / Black
//   P (system_pal)          Colours: Original palette / Raw RGB
//   F (system_autofire)     Controller: 2 Buttons / 2 Turbo
//   R (system_reset)        the Reset action
//
// Clocks are in clocks_slow.v. Signals from the companion arrive on clk_pixel
// and are 2-flop synchronised into clk_sys where they are used.
//
// The block of debug instruments at the end of this file does not affect the
// console. It stays in this version so the bitstream matches the release.

module pcehero_nano_top (
    input  wire       ex_clk_27m,

    // SPI boot flash (unused while no built-in ROM is copied)
    output wire       mspi_cs,
    output wire       mspi_sclk,
    output wire       mspi_mosi,
    input  wire       mspi_miso,

    // In-package SDRAM
    output wire        O_sdram_clk,
    output wire        O_sdram_cke,
    output wire        O_sdram_cs_n,
    output wire        O_sdram_cas_n,
    output wire        O_sdram_ras_n,
    output wire        O_sdram_wen_n,
    inout  wire [31:0] IO_sdram_dq,
    output wire [10:0] O_sdram_addr,
    output wire [1:0]  O_sdram_ba,
    output wire [3:0]  O_sdram_dqm,

    // HDMI
    output wire       tmds_clk_p,
    output wire       tmds_clk_n,
    output wire [2:0] tmds_data_p,
    output wire [2:0] tmds_data_n,

    output wire [5:0] led,  // active low; led[0] is a heartbeat

    input  wire       s1,  // button S1: opens the OSD

    input  wire       s2,  // button S2: the pad's Run

    input  wire [5:0] db9,  // shield DB9 joystick, active low

    // Companion SPI (BL616 on the board, or the shield RP2040)
    input  wire       spi_sclk,
    input  wire       spi_csn,
    input  wire       spi_dat,
    output wire       spi_dir,
    output wire       spi_irqn,
    inout  wire [4:0] m0s,

    // microSD slot
    output wire        sd_sclk,
    inout  wire        sd_cmd,
    inout  wire [3:0]  sd_dat,

    output wire       ws2812  // on-board RGB LED, held off
);

assign ws2812 = 1'b0;

wire clk_sys, clk_ram, clk_pixel, clk_pixel_x5, pll_locked;
wire clk_ram_sdram;

clocks_slow clocks_inst (
    .clkin_27m    (ex_clk_27m),
    .clk_sys      (clk_sys),
    .clk_ram      (clk_ram),
    .clk_pixel    (clk_pixel),
    .clk_pixel_x5 (clk_pixel_x5),
    .clk_ram_sdram(clk_ram_sdram),
    .locked       (pll_locked)
);

// Power-on reset: ~3 ms after configuration.
reg [17:0] rst_cnt = 0;
always @(posedge clk_sys) begin
    if (!rst_cnt[17]) rst_cnt <= rst_cnt + 1'b1;
end
wire sys_rst_n  = rst_cnt[17];

wire mem_ready;
wire [31:0] ram_dout_w;

wire mem_sync_tick;
wire        vram_clearing;
wire [15:0] vclr_cnt;
wire        clear_done;
wire        reset_n;

// Core reset: held through ROM loading and a short start-up pass.
pce_reset_seq reset_seq (
    .clk_sys       (clk_sys),
    .sys_rst_n     (sys_rst_n),
    .loading       (loading),
    .clear_tick    (mem_sync_tick),
    .vram_clearing (vram_clearing),
    .clear_done    (clear_done),
    .vclr_cnt_out  (vclr_cnt),
    .reset_n       (reset_n)
);

// Button S1: synchronised and debounced (~1.5 ms stable). It reads 1 when
// pressed; s1_db is passed to the companion as the OSD button.
reg  [2:0] s1_sync = 3'b111;
always @(posedge clk_sys) s1_sync <= {s1_sync[1:0], s1};
reg         s1_db  = 1'b1;
reg  [15:0] s1_cnt = 16'd0;
always @(posedge clk_sys) begin
    if (s1_sync[2] == s1_db) s1_cnt <= 16'd0;
    else begin
        s1_cnt <= s1_cnt + 1'b1;
        if (&s1_cnt) s1_db <= s1_sync[2];
    end
end
// s1_core_rst and s1_pressed are unused; named from when S1 was read as
// active low.
wire s1_core_rst = ~s1_db;
wire s1_pressed  = ~s1_db;

wire osd_button = s1_db;

// After an SD game load, hold the core in reset for ~6 ms so the CPU restarts
// on the new ROM. Not a cold reset: COLD_RESET is for power-on only.
reg [17:0] sdc_soft_reset_cnt    = 18'd0;
reg        sdc_soft_reset_active = 1'b0;
always @(posedge clk_sys) begin
    if (sdc_load_done) begin
        sdc_soft_reset_active <= 1'b1;
        sdc_soft_reset_cnt    <= 18'd0;
    end else if (sdc_soft_reset_active) begin
        if (&sdc_soft_reset_cnt) sdc_soft_reset_active <= 1'b0;
        else                     sdc_soft_reset_cnt    <= sdc_soft_reset_cnt + 1'b1;
    end
end
wire sdc_soft_reset = sdc_soft_reset_active;

// No built-in game: rom_loader skips the flash copy and the CPU is held in
// reset until the first game is loaded from the SD card.
localparam NO_BUILTIN_ROM = 1'b1;

// OSD Reset: the menu sets R=1 for 10 ms. Bit 0 restarts the game, as in
// NanoMig. 10 ms is longer than the 6 ms load reset, so no stretch is needed.
// Declared before use: Gowin makes a net used before its declaration a
// 1-bit wire.
wire [1:0] companion_system_reset;
(* async_reg = "true" *) reg [1:0] osd_reset_sync = 2'b00;
always @(posedge clk_sys) osd_reset_sync <= {osd_reset_sync[0], companion_system_reset[0]};
wire osd_reset = osd_reset_sync[1];

// OSD "No game" then Reset unloads the game: the CPU is held and the colour
// bars return. A new load re-arms it, so Reset alone still restarts the game.
wire sdc_ejected;
reg cart_ejected = 1'b0;
always @(posedge clk_sys)
    if (sdc_load_done)    cart_ejected <= 1'b0;
    else if (sdc_ejected) cart_ejected <= 1'b1;
reg cart_loaded = 1'b0;
always @(posedge clk_sys)
    if (sdc_load_done)                  cart_loaded <= 1'b1;
    else if (osd_reset & cart_ejected)  cart_loaded <= 1'b0;
wire no_cart_hold = NO_BUILTIN_ROM & ~cart_loaded;

wire core_reset = ~reset_n | sdc_soft_reset | no_cart_hold | osd_reset;
wire cold_reset = ~reset_n;

// Button S2 (the pad's Run): synchronised and debounced.
reg  [2:0] s2_sync = 3'b000;
always @(posedge clk_sys) s2_sync <= {s2_sync[1:0], s2};
reg         s2_db  = 1'b0;
reg  [15:0] s2_cnt = 16'd0;
always @(posedge clk_sys) begin
    if (s2_sync[2] == s2_db) s2_cnt <= 16'd0;
    else begin
        s2_cnt <= s2_cnt + 1'b1;
        if (&s2_cnt) s2_db <= s2_sync[2];
    end
end
wire s2_pressed = s2_db;

// Core outputs.
wire o_rom_rd;
wire [21:0] o_rom_a;
wire o_rom_clken;
wire [10:0] o_brm_a;
wire [7:0] o_brm_di;
wire o_brm_we;
wire [15:0] o_vram0_a;
wire [15:0] o_vram0_do;
wire o_vram0_rd;
wire o_vram0_we;
wire [15:0] o_vram1_a;
wire [15:0] o_vram1_do;
wire o_vram1_rd;
wire o_vram1_we;
wire o_gg_avail;
wire [1:0] o_joy_out;
wire [21:0] o_ext_ram_a;
wire [7:0] o_ext_ram_do;
wire o_ext_ram_ce;
wire o_ext_ram_rd;
wire o_ext_ram_wr;
wire [16:0] o_adram_a;
wire [3:0] o_adram_di;
wire o_adram_we;
wire o_adram_rd;
wire [95:0] o_cd_comm;
wire o_cd_comm_send;
wire [79:0] o_cd_dout;
wire o_cd_dout_send;
wire o_cd_reset;
wire o_cd_data_end;
wire o_cd_fifo_halffull;
wire [15:0] o_cdda_sl;
wire [15:0] o_cdda_sr;
wire [15:0] o_adpcm_s;
wire [15:0] o_psg_sl;
wire [15:0] o_psg_sr;
wire [1:0] o_video_dcc;
wire [2:0] o_video_r;
wire [2:0] o_video_g;
wire [2:0] o_video_b;
wire o_video_bw;
wire o_video_ce;
wire o_video_ce_fs;
wire o_video_vs;
wire o_video_hs;
wire o_video_hbl;
wire o_video_vbl;

// Debug nets. Not connected to the core and not driven, so the flags built
// on them below are constants.
wire o_vdc_irq_n;
wire o_vce_wr, o_vdc_wr;
wire o_vram_write_raw, o_vram_a15;
wire o_vdisp, o_cpuwr_pend, o_slot_cpu;
wire o_cr_ie_vc, o_irq_vbl;
wire o_cr_ie_rc, o_irq_rcr, o_irq_any;
wire o_ram_we, o_ram_sel, o_any_wr;
wire [7:0] o_ram_do;
wire [4:0] o_ar;
wire [1:0] o_vdc_wr_a;
wire [7:0] o_cpu_do;

wire [4:0] w_dbg_vdc_ar;
wire [7:0] w_dbg_vdc_wdata;
wire       w_dbg_vdc_wstb;
wire [4:0] w_dbg_vdc_armax;
wire       w_dbg_vdc_initdone;

wire       w_dbg_cpu_wr;

// Memory configuration of this build:
//   WRAM_BRAM=1    work RAM in block RAM (wram_bram); overrides WRAM_SDRAM
//   SDRAM_BANK2=1  ROM and SD writes on pce_sdram_bank2
//   VRAM_BRAM=1    VRAM in block RAM (below)
localparam WRAM_SDRAM = 1;

localparam WRAM_BRAM = 1;

localparam SDRAM_BANK2 = 1;

wire        wram_active, wram_rdy;
wire        wram_cpu_ce;
wire [22:0] wc_ram_addr;
wire [7:0]  wc_ram_din;
wire        wc_ram_req, wc_ram_write;
wire [7:0]  wram_ext_di;
wire [7:0]  wram_sdram_ext_di;
wire [7:0]  wram_bram_dout;
wire        wram_bram_rdy = 1'b1;

// Block-RAM work RAM needs no wait states.
wire        wram_active_eff = WRAM_BRAM ? 1'b0          : wram_active;
wire        wram_rdy_eff    = WRAM_BRAM ? wram_bram_rdy : wram_rdy;
assign      wram_ext_di     = WRAM_BRAM ? wram_bram_dout : wram_sdram_ext_di;

wire        rom_rdy_ldr;
wire [22:0] ldr_ram_addr;
wire [7:0]  ldr_ram_din;
wire        ldr_ram_req, ldr_ram_write;
wire        ldr_ram_wword;
wire [15:0] ldr_ram_din16;

wire        sdc_want_write;
wire [22:0] sdc_write_addr;
wire [7:0]  sdc_write_din;
wire        sdc_write_ack;

// SDRAM CPU port of pce_sdram_ctrl (unused with SDRAM_BANK2=1: ram_req is 0).
// ROM_RDY is the AND of every client's ready; any of them can stall the CPU.
wire [22:0] ram_addr   = wram_active_eff ? wc_ram_addr  : ldr_ram_addr;
wire [7:0]  ram_din    = wram_active_eff ? wc_ram_din   : ldr_ram_din;
wire        ram_req    = SDRAM_BANK2 ? 1'b0 : (wram_active_eff ? wc_ram_req : ldr_ram_req);
wire        ram_write  = wram_active_eff ? wc_ram_write : ldr_ram_write;
wire        ram_wword  = wram_active_eff ? 1'b0 : ldr_ram_wword;
wire [15:0] ram_din16  = ldr_ram_din16;
wire        rom_rdy    = rom_rdy_ldr & wram_rdy_eff;
wire [7:0]  rom_do_pce;

// pce_sdram_bank2 client ports: ROM, work RAM (unused here) and SD writes.
wire [7:0]  rom_b2_dout;
wire [31:0] rom_b2_dout_w;
wire [31:0] rom_b2_dout_w2;
wire        rom_b2_busy;
wire [18:0] rom_b2_addr;
wire [31:0] rom_b2_din, rom_b2_dout32, rom_b2_dout32_2;
wire [3:0]  rom_b2_dqm;
wire        rom_b2_req, rom_b2_we, rom_b2_ack;

wire [7:0]  wram_b2_dout;
wire        wram_b2_busy;
wire [18:0] wram_b2_addr;
wire [31:0] wram_b2_din, wram_b2_dout32;
wire [3:0]  wram_b2_dqm;
wire        wram_b2_req, wram_b2_we, wram_b2_ack;

wire [22:0] sdcw_ram_addr;
wire [7:0]  sdcw_ram_din;
wire        sdcw_ram_req;
wire        sdcw_ram_busy;

wire [18:0] sdcw_b2_addr;
wire [31:0] sdcw_b2_din;
wire [3:0]  sdcw_b2_dqm;
wire        sdcw_b2_req, sdcw_b2_ack;

wire        bank2_ready;
wire [10:0] bank2_sd_addr;
wire [3:0]  bank2_sd_dqm;
wire [1:0]  bank2_sd_ba;
wire        bank2_sd_cke, bank2_sd_cs, bank2_sd_we, bank2_sd_ras, bank2_sd_cas;

wire [31:0] b2_dbg_sd_data_q;
wire [1:0]  b2_dbg_latch2_port;
wire [18:0] b2_dbg_latch2_addr;
wire [3:0]  b2_dbg_write_recent;

// pce_sdram_ctrl's pins, selected away when SDRAM_BANK2=1
wire        ctrl_O_sdram_clk, ctrl_O_sdram_cke, ctrl_O_sdram_cs_n;
wire        ctrl_O_sdram_cas_n, ctrl_O_sdram_ras_n, ctrl_O_sdram_wen_n;
wire [10:0] ctrl_O_sdram_addr;
wire [1:0]  ctrl_O_sdram_ba;
wire [3:0]  ctrl_O_sdram_dqm;
wire        ctrl_mem_ready;

wire [3:0] joypad_joy_in;
wire       pad_run_w;
// OSD Controller: 0 = 2 Buttons, 1 = 2 Turbo.
wire [1:0] companion_system_autofire;
(* async_reg = "true" *) reg [1:0] pad_turbo_sync = 2'b00;
always @(posedge clk_sys) pad_turbo_sync <= {pad_turbo_sync[0], companion_system_autofire == 2'd1};
wire pad_turbo_en = pad_turbo_sync[1];

// USB pads from the companion (clk_pixel), 2-flop synchronised per bit into
// clk_sys. Each bit is an independent button, so a sample split across two
// bits only means two presses seen one scan apart.
// joystick[5:4] = II, I; [7:6] = IV, III (turbo); console [1:0] = VI, V,
// [2] Select, [3] Run.
wire [7:0]   joystick0, joystick0_console;
wire [7:0]   joystick1, joystick1_console;
(* async_reg = "true" *) reg [31:0] pad_sync1 = 32'd0;
(* async_reg = "true" *) reg [31:0] pad_sync2 = 32'd0;
always @(posedge clk_sys) begin
    pad_sync1 <= {joystick1_console, joystick1, joystick0_console, joystick0};
    pad_sync2 <= pad_sync1;
end
wire [7:0] joy0_s  = pad_sync2[7:0];
wire [7:0] con0_s  = pad_sync2[15:8];
wire [7:0] joy1_s  = pad_sync2[23:16];
wire [7:0] con1_s  = pad_sync2[31:24];
assign pad_run_w = s2_pressed | con0_s[3];

// P1 is the USB pad ORed with the shield DB9 port (active low).
joypad #(.MULTITAP(1)) joypad_inst (
    .clk         (clk_sys),
    .joy_out_sel (o_joy_out[0]),
    .joy_out_clr (o_joy_out[1]),
    .p1_turbo    ({con0_s[1], con0_s[0], joy0_s[7], joy0_s[6]}),
    .p2_turbo    ({con1_s[1], con1_s[0], joy1_s[7], joy1_s[6]}),
    .turbo_en    (pad_turbo_en),
    .p1          ({pad_run_w,          con0_s[2],
                   joy0_s[5] | ~db9[5], joy0_s[4] | ~db9[0],
                   joy0_s[1] | ~db9[4], joy0_s[2] | ~db9[1],
                   joy0_s[0] | ~db9[3], joy0_s[3] | ~db9[2]}),
    .p2          ({con1_s[3], con1_s[2],
                   joy1_s[5], joy1_s[4],
                   joy1_s[1], joy1_s[2],
                   joy1_s[0], joy1_s[3]}),
    .joy_in      (joypad_joy_in)
);

// Companion outputs.
wire [127:0] companion_keyboard;
wire         companion_osd_strobe, companion_osd_start;
wire [7:0]   companion_osd_data;
wire         companion_system_turbo, companion_system_turbo_boot;
wire         companion_system_scanlines, companion_system_wide_screen;
wire         companion_system_stereo, companion_system_second_scc;
wire [2:0]   companion_system_volume;
wire         companion_system_pal;
wire [1:0]   companion_system_keyboard;
wire         companion_system_db9_port;
wire         companion_system_save;

wire        companion_sdc_inserted_strobe;
wire [7:0]  companion_sdc_inserted_drive;
wire [31:0] companion_sdc_inserted_size;
wire        companion_sdc_direct_strobe;
wire [7:0]  companion_sdc_direct_drive;
wire [31:0] companion_sdc_direct_start_sector;

wire        companion_sdc_mcu_read_req_toggle;
wire [31:0] companion_sdc_mcu_read_sector;
wire        companion_sdc_mcu_read_ready_toggle;
wire [8:0]  companion_sdc_mcu_buf_addr;
wire [7:0]  companion_sdc_mcu_buf_dout;

wire       sdc_card_ready_w;
// clk_sys -> clk_pixel: card status and the CORE_RW request are levels that
// hold for a whole request, so a plain 2-flop sync is enough.
reg sdc_card_ready_sync1 = 1'b0, sdc_card_ready_sync2 = 1'b0;
reg [1:0] sdc_card_type_sync1 = 2'b00, sdc_card_type_sync2 = 2'b00;
always @(posedge clk_pixel) begin
    sdc_card_ready_sync1 <= sdc_card_ready_w;
    sdc_card_ready_sync2 <= sdc_card_ready_sync1;
    sdc_card_type_sync1  <= sdc_card_type;
    sdc_card_type_sync2  <= sdc_card_type_sync1;
end

wire        sdc_core_rw_want_w;
wire [31:0] sdc_core_rw_lsector_w;
wire        sdc_core_rw_local_busy_w;
reg         sdc_core_rw_want_sync1 = 1'b0, sdc_core_rw_want_sync2 = 1'b0;
reg  [31:0] sdc_core_rw_lsector_sync1 = 32'd0, sdc_core_rw_lsector_sync2 = 32'd0;
reg         sdc_core_rw_local_busy_sync1 = 1'b0, sdc_core_rw_local_busy_sync2 = 1'b0;
always @(posedge clk_pixel) begin
    sdc_core_rw_want_sync1       <= sdc_core_rw_want_w;
    sdc_core_rw_want_sync2       <= sdc_core_rw_want_sync1;
    sdc_core_rw_lsector_sync1    <= sdc_core_rw_lsector_w;
    sdc_core_rw_lsector_sync2    <= sdc_core_rw_lsector_sync1;
    sdc_core_rw_local_busy_sync1 <= sdc_core_rw_local_busy_w;
    sdc_core_rw_local_busy_sync2 <= sdc_core_rw_local_busy_sync1;
end

// The CORE_RW interrupt to the MCU waits ~6 ms after the request. The request
// is raised while the firmware is still sending the INSERTED command that
// caused it, and an interrupt at that moment crashed the companion. The
// STATUS bit (read when the MCU polls) is not delayed.
reg [17:0] sdc_core_rw_irq_delay_cnt = 18'd0;
reg        sdc_core_rw_irq_w = 1'b0;
always @(posedge clk_sys) begin
    if (!sdc_core_rw_want_w) begin
        sdc_core_rw_irq_delay_cnt <= 18'd0;
        sdc_core_rw_irq_w         <= 1'b0;
    end else if (&sdc_core_rw_irq_delay_cnt) begin
        sdc_core_rw_irq_w <= 1'b1;
    end else begin
        sdc_core_rw_irq_delay_cnt <= sdc_core_rw_irq_delay_cnt + 1'b1;
    end
end

reg sdc_core_rw_irq_sync1 = 1'b0, sdc_core_rw_irq_sync2 = 1'b0;
always @(posedge clk_pixel) begin
    sdc_core_rw_irq_sync1 <= sdc_core_rw_irq_w;
    sdc_core_rw_irq_sync2 <= sdc_core_rw_irq_sync1;
end

// Debug: sticky flags for the SD load handshake.
reg sdc_core_rw_want_ever_seen  = 1'b0;
reg sdc_core_rw_irq_ever_seen   = 1'b0;
reg sdc_core_rw_reply_ever_seen = 1'b0;
reg sdc_load_done_ever_seen     = 1'b0;
reg sdc_core_rw_want_d = 1'b0;
always @(posedge clk_sys) begin
    sdc_core_rw_want_d <= sdc_core_rw_want_w;
    if (sdc_core_rw_want_w)                            sdc_core_rw_want_ever_seen  <= 1'b1;
    if (sdc_core_rw_irq_w)                             sdc_core_rw_irq_ever_seen   <= 1'b1;
    if (sdc_core_rw_want_d && !sdc_core_rw_want_w)      sdc_core_rw_reply_ever_seen <= 1'b1;
    if (sdc_load_done)                                  sdc_load_done_ever_seen     <= 1'b1;
end

wire        companion_sdc_core_rw_reply_toggle;
wire [31:0] companion_sdc_core_rw_reply_psector;

// FPGA-Companion: SPI to the MCU, USB HID, OSD, settings and SD card access.
// On clk_pixel, the same clock as the OSD it draws.
fpga_companion fpga_companion_inst (
    .clk   (clk_pixel),
    .reset (~pll_locked),

    .buttons  ({osd_button, 1'b0}),

    .m0s      (m0s),
    .spi_sclk (spi_sclk),
    .spi_csn  (spi_csn),
    .spi_dir  (spi_dir),
    .spi_dat  (spi_dat),
    .spi_irqn (spi_irqn),

    .keyboard          (companion_keyboard),
    .joystick0         (joystick0),
    .joystick0_console (joystick0_console),
    .joystick1         (joystick1),
    .joystick1_console (joystick1_console),
    .ws2812_color      (),

    .osd_strobe (companion_osd_strobe),
    .osd_start  (companion_osd_start),
    .osd_data   (companion_osd_data),

    .system_reset       (companion_system_reset),
    .system_turbo       (companion_system_turbo),
    .system_turbo_boot  (companion_system_turbo_boot),
    .system_scanlines   (companion_system_scanlines),
    .system_wide_screen (companion_system_wide_screen),
    .system_stereo      (companion_system_stereo),
    .system_second_scc  (companion_system_second_scc),
    .system_volume      (companion_system_volume),
    .system_pal         (companion_system_pal),
    .system_keyboard    (companion_system_keyboard),
    .system_db9_port    (companion_system_db9_port),
    .system_autofire    (companion_system_autofire),
    .system_save        (companion_system_save),

    .sdc_inserted_strobe     (companion_sdc_inserted_strobe),
    .sdc_inserted_drive      (companion_sdc_inserted_drive),
    .sdc_inserted_size       (companion_sdc_inserted_size),
    .sdc_direct_strobe       (companion_sdc_direct_strobe),
    .sdc_direct_drive        (companion_sdc_direct_drive),
    .sdc_direct_start_sector (companion_sdc_direct_start_sector),

    .sdc_mcu_read_req_toggle  (companion_sdc_mcu_read_req_toggle),
    .sdc_mcu_read_sector      (companion_sdc_mcu_read_sector),
    .sdc_mcu_read_ready_toggle(companion_sdc_mcu_read_ready_toggle),
    .sdc_mcu_buf_addr         (companion_sdc_mcu_buf_addr),
    .sdc_mcu_buf_dout         (companion_sdc_mcu_buf_dout),

    .sdc_card_ready (sdc_card_ready_sync2),
    .sdc_card_type  (sdc_card_type_sync2),

    .sdc_core_rw_want      (sdc_core_rw_want_sync2),
    .sdc_core_rw_lsector   (sdc_core_rw_lsector_sync2),
    .sdc_core_rw_reply_toggle (companion_sdc_core_rw_reply_toggle),
    .sdc_core_rw_reply_psector(companion_sdc_core_rw_reply_psector),
    .sdc_core_rw_local_busy(sdc_core_rw_local_busy_sync2),
    .sdc_core_rw_irq       (sdc_core_rw_irq_sync2)
);

wire        sdc_loading, sdc_load_done;
wire [15:0] sdc_sectors_total, sdc_sector_idx;
wire [15:0] sdc_rom_sectors;
wire [3:0]  sdc_card_stat;
wire [1:0]  sdc_card_type;

sdc_write_bridge sdc_write_bridge_inst (
    .clk           (clk_sys),
    .rstn          (sys_rst_n),
    .sdc_want_write(sdc_want_write),
    .sdc_write_addr(sdc_write_addr),
    .sdc_write_din (sdc_write_din),
    .sdc_write_ack (sdc_write_ack),
    .ram_addr      (sdcw_ram_addr),
    .ram_din       (sdcw_ram_din),
    .ram_req       (sdcw_ram_req),
    .ram_busy      (sdcw_ram_busy)
);

// SD card: game loading and the MCU's raw sector reads.
rom_sdc_loader #(
    .SDRAM_BASE (23'h000000),
    .SD_CLK_DIV (3'd2),
    .SD_SIMULATE(0),
    .DIAGNOSTIC_MAX_SECTORS(16'd0)
) rom_sdc_loader_inst (
    .clk    (clk_sys),
    .rstn   (sys_rst_n),
    .mcu_clk(clk_pixel),

    .sd_sclk (sd_sclk),
    .sd_cmd  (sd_cmd),
    .sd_dat0 (sd_dat[0]),
    .sd_dat1 (sd_dat[1]),
    .sd_dat2 (sd_dat[2]),
    .sd_dat3 (sd_dat[3]),

    .mcu_direct_strobe      (companion_sdc_direct_strobe),
    .mcu_direct_start_sector(companion_sdc_direct_start_sector),
    .mcu_inserted_strobe    (companion_sdc_inserted_strobe),
    .mcu_inserted_size      (companion_sdc_inserted_size),

    .mcu_read_req_toggle  (companion_sdc_mcu_read_req_toggle),
    .mcu_read_sector      (companion_sdc_mcu_read_sector),
    .mcu_read_ready_toggle(companion_sdc_mcu_read_ready_toggle),
    .mcu_buf_addr         (companion_sdc_mcu_buf_addr),
    .mcu_buf_dout         (companion_sdc_mcu_buf_dout),

    .sdc_want_write (sdc_want_write),
    .sdc_write_addr (sdc_write_addr),
    .sdc_write_din  (sdc_write_din),
    .sdc_write_ack  (sdc_write_ack),

    .loading        (sdc_loading),
    .load_done      (sdc_load_done),
    .ejected        (sdc_ejected),
    .sectors_total  (sdc_sectors_total),
    .sector_idx_out (sdc_sector_idx),
    .rom_sectors    (sdc_rom_sectors),
    .header_skipped (),
    .sd_card_stat   (sdc_card_stat),
    .sd_card_type   (sdc_card_type),
    .sd_card_ready  (sdc_card_ready_w),

    .core_rw_want          (sdc_core_rw_want_w),
    .core_rw_lsector       (sdc_core_rw_lsector_w),
    .core_rw_reply_toggle  (companion_sdc_core_rw_reply_toggle),
    .core_rw_reply_psector (companion_sdc_core_rw_reply_psector),
    .core_rw_local_busy    (sdc_core_rw_local_busy_w)
);

// ROM_SZ for the core's mapper, from the ROM size in 512-byte sectors
// (copier header already removed): 128K, 256K, 384K, 512K, 768K.
function [7:0] rom_sz_from_sectors;
    input [15:0] sectors;
    case (sectors)
        16'd256:  rom_sz_from_sectors = 8'h02;
        16'd512:  rom_sz_from_sectors = 8'h04;
        16'd768:  rom_sz_from_sectors = 8'h06;
        16'd1024: rom_sz_from_sectors = 8'h08;
        16'd1536: rom_sz_from_sectors = 8'h0C;
        default:  rom_sz_from_sectors = 8'h00;
    endcase
endfunction

reg [7:0] rom_sz_r = 8'd4;
always @(posedge clk_sys)
    if (sdc_load_done) rom_sz_r <= rom_sz_from_sectors(sdc_rom_sectors);

// OSD Overscan (MiSTer's option): 0 = Hidden (231 lines shown), 1 = Visible
// (242). The VCE marks hidden lines with VBL; the scandoubler draws them black.
(* async_reg = "true" *) reg [1:0] overscan_vis_sync = 2'b00;
always @(posedge clk_sys) overscan_vis_sync <= {overscan_vis_sync[0], companion_system_wide_screen};
wire overscan_visible = overscan_vis_sync[1];

// OSD Border colour: 0 = the game's colour, 1 = black (BORDER_EN = 0).
(* async_reg = "true" *) reg [1:0] border_black_sync = 2'b00;
always @(posedge clk_sys) border_black_sync <= {border_black_sync[0], companion_system_second_scc};
wire border_en = ~border_black_sync[1];

// The PC Engine. USE_INTERNAL_RAM=0: work RAM is outside the core, on
// EXT_RAM_*. No CD (CD_EN=0), no SuperGrafx, no Game Genie.
pce_top #(.USE_INTERNAL_RAM((WRAM_SDRAM || WRAM_BRAM) ? 0 : 1)) pce (
.RESET            (core_reset),
    .COLD_RESET       (cold_reset),
    .CLK              (clk_sys),
    .ROM_RD           (o_rom_rd),
    .ROM_RDY          (rom_rdy),
    .ROM_A            (o_rom_a),
    .ROM_DO           (rom_do_pce),
    .ROM_SZ           (rom_sz_r),
    .ROM_POP          (1'd0),
    .ROM_CLKEN        (o_rom_clken),
    .BRM_A            (o_brm_a),
    .BRM_DI           (o_brm_di),
    .BRM_DO           (8'd0),
    .BRM_WE           (o_brm_we),
    .VRAM0_A          (o_vram0_a),
    .VRAM0_DO         (o_vram0_do),
    .VRAM0_RD         (o_vram0_rd),
    .VRAM0_WE         (o_vram0_we),
    .VRAM0_DI         (vram_dout),
    .VRAM1_A          (o_vram1_a),
    .VRAM1_DO         (o_vram1_do),
    .VRAM1_RD         (o_vram1_rd),
    .VRAM1_WE         (o_vram1_we),
    .VRAM1_DI         (16'd0),
    .GG_EN            (1'd0),
    .GG_CODE          (129'd0),
    .GG_RESET         (1'd0),
    .GG_AVAIL         (o_gg_avail),
    .SP64             (1'd0),
    .SGX              (1'd0),
    .JOY_OUT          (o_joy_out),
    .JOY_IN           (joypad_joy_in),
    .CD_EN            (1'd0),
    .EXT_RAM_A        (o_ext_ram_a),
    .EXT_RAM_DO       (o_ext_ram_do),
    .EXT_RAM_DI       (wram_ext_di),
    .EXT_RAM_CE       (o_ext_ram_ce),
    .EXT_RAM_RD       (o_ext_ram_rd),
    .EXT_RAM_WR       (o_ext_ram_wr),
    .EXT_RAM_CPU_CE   (wram_cpu_ce),
    .AC_EN            (1'd0),
    .ADRAM_A          (o_adram_a),
    .ADRAM_DI         (o_adram_di),
    .ADRAM_DO         (4'd0),
    .ADRAM_WE         (o_adram_we),
    .ADRAM_RD         (o_adram_rd),
    .CD_STAT          (8'd0),
    .CD_MSG           (8'd0),
    .CD_STAT_GET      (1'd0),
    .CD_COMM          (o_cd_comm),
    .CD_COMM_SEND     (o_cd_comm_send),
    .CD_DOUT_REQ      (1'd0),
    .CD_DOUT          (o_cd_dout),
    .CD_DOUT_SEND     (o_cd_dout_send),
    .CD_REGION        (1'd0),
    .CD_RESET         (o_cd_reset),
    .CD_DATA          (8'd0),
    .CD_WR            (1'd0),
    .CD_DATA_END      (o_cd_data_end),
    .CD_DM            (1'd0),
    .CD_FIFO_HALFFULL (o_cd_fifo_halffull),
    .CDDA_SL          (o_cdda_sl),
    .CDDA_SR          (o_cdda_sr),
    .ADPCM_S          (o_adpcm_s),
    .PSG_SL           (o_psg_sl),
    .PSG_SR           (o_psg_sr),
    .BG_EN            (1'b1),
    .SPR_EN           (1'b1),
    .GRID_EN          (2'd0),
    .CPU_PAUSE_EN     (1'd0),
    .BORDER_EN        (border_en),
    .ReducedVBL       (overscan_visible),
    .VIDEO_DCC        (o_video_dcc),
    .VIDEO_R          (o_video_r),
    .VIDEO_G          (o_video_g),
    .VIDEO_B          (o_video_b),
    .VIDEO_BW         (o_video_bw),
    .VIDEO_CE         (o_video_ce),
    .VIDEO_CE_FS      (o_video_ce_fs),
    .VIDEO_VS         (o_video_vs),
    .VIDEO_HS         (o_video_hs),
    .VIDEO_HBL        (o_video_hbl),
    .VIDEO_VBL        (o_video_vbl),
    .DBG_VDC_AR       (w_dbg_vdc_ar),
    .DBG_VDC_WDATA    (w_dbg_vdc_wdata),
    .DBG_VDC_WSTB     (w_dbg_vdc_wstb),
    .DBG_VDC_ARMAX    (w_dbg_vdc_armax),
    .DBG_VDC_INITDONE (w_dbg_vdc_initdone),
    .DBG_CPU_WR       (w_dbg_cpu_wr)
);

// VRAM in block RAM (32 of the 46 blocks). The VRAM paths into
// pce_sdram_ctrl are left from builds with VRAM in SDRAM.
localparam VRAM_BRAM = 1;

localparam UNGATE_VDC_SYNC = 0;  // debug knob for pce_sdram_ctrl; 0

wire [15:0] vram_dout;
wire [15:0] vram_dout_sdram;

reg [14:0] vram_addr_r;
reg [15:0] vram_din_r;
reg        vram_we_r;
reg        vram_rd_r;
always @(posedge clk_sys) begin
    vram_addr_r <= o_vram0_a[14:0];
    vram_din_r  <= o_vram0_do;
    vram_we_r   <= o_vram0_we;
    vram_rd_r   <= o_vram0_rd;
end

generate
if (VRAM_BRAM) begin : g_vram_bram
    vram_bram vram0_bram (
        .clk  (clk_sys),
        .addr (o_vram0_a[14:0]),
        .din  (o_vram0_do),
        .we   (o_vram0_we),
        .dout (vram_dout)
    );
end else begin : g_vram_sdram
    assign vram_dout = vram_dout_sdram;
end
endgenerate

wire [7:0]  ram_dout;
wire        ram_busy;
wire [7:0]  rom_do;
wire        rom_hit;
wire        loading, rom_ok, sdram_ok;

// Bit-reversed US HuCard dumps boot as-is. MiSTer has a manual "ROM Data
// Swap" option; here it is automatic. A real card's reset vector high byte
// (ROM offset 0x1FFF) is always >= $E0; if it is not, but its bit-reverse is,
// every ROM byte is reversed on the CPU's read path. Decided on each load.
function [7:0] bitrev8;
    input [7:0] b;
    bitrev8 = {b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7]};
endfunction

reg rom_flip = 1'b0;
always @(posedge clk_sys)
    if (sdc_want_write && sdc_write_addr == 23'h001FFF)
        rom_flip <= (sdc_write_din < 8'hE0) && (bitrev8(sdc_write_din) >= 8'hE0);

assign rom_do_pce = rom_flip ? bitrev8(rom_do) : rom_do;
// Debug nets.
wire        verified_out;
wire [3:0]  ldr_state;
wire [2:0]  mem_cstate;
wire        mem_sync;
wire [3:0]  mem_sdst;
wire        mem_p2ack;

wire rom_match, any_bad, first_ok, scan_done, verify_ran;
wire [7:0] first_byte_rd;
wire [2:0] bad_blk;
wire [3:0] bad_cnt;

// ROM reads for the CPU, through an 8-byte line cache with read-ahead.
// SKIP_FLASH_COPY: the ROM comes from the SD card only.
rom_loader #(.WORD_WRITE(0), .SKIP_FLASH_COPY(NO_BUILTIN_ROM)) loader (
    .clk        (clk_sys),
    .rstn       (rst_cnt[17]),
    .mem_ready  (mem_ready),
    .ram_dout_w (SDRAM_BANK2 ? rom_b2_dout_w : ram_dout_w),
    .ram_dout_w2(SDRAM_BANK2 ? rom_b2_dout_w2 : 32'd0),
    .mspi_sclk  (mspi_sclk),
    .mspi_cs    (mspi_cs),
    .mspi_mosi  (mspi_mosi),
    .mspi_miso  (mspi_miso),
    .ram_addr   (ldr_ram_addr),
    .ram_din    (ldr_ram_din),
    .ram_din16  (ldr_ram_din16),
    .ram_wword  (ldr_ram_wword),
    .ram_req    (ldr_ram_req),
    .ram_write  (ldr_ram_write),
    .ram_dout   (SDRAM_BANK2 ? rom_b2_dout : ram_dout),
    .ram_busy   (SDRAM_BANK2 ? rom_b2_busy : ram_busy),
    .cache_invalidate(sdc_load_done),
    .rom_a      (o_rom_a),
    .rom_rd     (o_rom_rd),
    .rom_clken  (o_rom_clken),
    .rom_do     (rom_do),
    .rom_hit    (rom_hit),
    .rom_rdy    (rom_rdy_ldr),
    .loading    (loading),
    .rom_ok     (rom_ok),
    .sdram_ok   (sdram_ok)
);

// Work RAM in SDRAM. With WRAM_BRAM=1 its data and ready are not used, but it
// still runs: every CPU work-RAM access also starts a bank-1 SDRAM access.
wram_sdram wram (
    .clk       (clk_sys),
    .rstn      (rst_cnt[17]),
    .loading   (loading),
    .mem_ready (mem_ready),
    .ext_ce    (o_ext_ram_ce),
    .ext_rd    (o_ext_ram_rd),
    .ext_wr    (o_ext_ram_wr),
    .ext_a     (o_ext_ram_a),
    .ext_do    (o_ext_ram_do),
    .ext_di    (wram_sdram_ext_di),
    .cpu_ce    (wram_cpu_ce),
    .wram_rdy  (wram_rdy),
    .ram_addr  (wc_ram_addr),
    .ram_din   (wc_ram_din),
    .ram_req   (wc_ram_req),
    .ram_write (wc_ram_write),
    .ram_dout  (SDRAM_BANK2 ? wram_b2_dout : ram_dout),
    .ram_busy  (SDRAM_BANK2 ? wram_b2_busy : ram_busy),
    .active    (wram_active)
);

generate
if (WRAM_BRAM) begin : g_wram_bram
    // Work RAM in block RAM, no wait states.
    wram_bram wram_bram_probe (
        .clk  (clk_sys),
        .addr (o_ext_ram_a[12:0]),
        .din  (o_ext_ram_do),
        .we   (o_ext_ram_ce & o_ext_ram_wr),
        .dout (wram_bram_dout)
    );
end else begin : g_no_wram_bram
    assign wram_bram_dout = 8'h00;
end
endgenerate

// Refresh request window for pce_sdram_ctrl's old interface.
reg [6:0] rfsh_cnt = 0;
always @(posedge clk_sys) rfsh_cnt <= rfsh_cnt + 1'b1;
wire rfsh_n = |rfsh_cnt[6:3];

// The first SDRAM controller. With SDRAM_BANK2=1 its pins are not used and
// it gets no CPU requests or VRAM writes, but its VRAM read port still runs
// (results unused). Its sync_tick_27m paces pce_reset_seq.
pce_sdram_ctrl #(
    .SYNC_DELAY       (3),
    .FAILSAFE_CLKRAM  (20),
    .UNGATE_CHIPSET   (UNGATE_VDC_SYNC)
) memory (
    .clk_27m      (clk_sys),
    .clk_108m     (clk_ram),
    .clk_sdram    (clk_ram_sdram),
    .bus_reset_n  (sys_rst_n),
    .video_ce     (o_video_ce),
    .sync_tick_27m(mem_sync_tick),

    .ram_din      (ram_din),
    .ram_din16    (ram_din16),
    .ram_wword    (ram_wword),
    .ram_req      (ram_req),
    .ram_write    (ram_write),
    .ram_addr     (ram_addr),
    .bus_rfsh_n   (rfsh_n),
    .mem_ready    (ctrl_mem_ready),
    .ram_dout_w   (ram_dout_w),
    .ram_dout     (ram_dout),
    .ram_busy     (ram_busy),

    .vram_din     (vram_clearing ? 16'd0 : vram_din_r),
    .vram_write   (SDRAM_BANK2 ? 1'b0
                                : (vram_clearing ? 1'b1
                                                  : (VRAM_BRAM ? 1'b0 : vram_we_r))),
    .vram_addr    (vram_clearing ? {2'b00, vclr_cnt[14:0]}
                                 : {2'b00, vram_addr_r}),
    .vram_dout    (vram_dout_sdram),

    .vram_rd      (vram_clearing ? 1'b0 : vram_rd_r),
    .cstate_out   (mem_cstate),
    .dbg_sync     (mem_sync),
    .dbg_sdst     (mem_sdst),
    .dbg_p2ack    (mem_p2ack),

    .O_sdram_clk  (ctrl_O_sdram_clk),
    .O_sdram_cke  (ctrl_O_sdram_cke),
    .O_sdram_cs_n (ctrl_O_sdram_cs_n),
    .O_sdram_cas_n(ctrl_O_sdram_cas_n),
    .O_sdram_ras_n(ctrl_O_sdram_ras_n),
    .O_sdram_wen_n(ctrl_O_sdram_wen_n),
    .IO_sdram_dq  (IO_sdram_dq),
    .O_sdram_addr (ctrl_O_sdram_addr),
    .O_sdram_ba   (ctrl_O_sdram_ba),
    .O_sdram_dqm  (ctrl_O_sdram_dqm)
);

generate
if (SDRAM_BANK2) begin : g_sdram_bank2

    // pce_sdram_bank2 and its clients. The ROM client fetches 8-byte lines;
    // the work RAM client still runs with WRAM_BRAM=1 (results unused); sdcw
    // writes SD data.
    pce_sdram_bank2_client #(.ENABLE_CACHE(0), .WIDE_LINE(1)) rom_client (
        .clk        (clk_sys),
        .rstn       (rst_cnt[17]),
        .ram_din16  (ldr_ram_din16),
        .ram_wword  (ldr_ram_wword),
        .ram_din    (ldr_ram_din),
        .ram_req    (ldr_ram_req),
        .ram_write  (ldr_ram_write),
        .ram_addr   (ldr_ram_addr),
        .ram_dout   (rom_b2_dout),
        .ram_dout_w (rom_b2_dout_w),
        .ram_dout_w2(rom_b2_dout_w2),
        .ram_busy   (rom_b2_busy),
        .b2_addr    (rom_b2_addr),
        .b2_din     (rom_b2_din),
        .b2_dout    (rom_b2_dout32),
        .b2_dout2   (rom_b2_dout32_2),
        .b2_dqm     (rom_b2_dqm),
        .b2_req     (rom_b2_req),
        .b2_we      (rom_b2_we),
        .b2_ack     (rom_b2_ack)
    );

    pce_sdram_bank2_client #(.ENABLE_CACHE(1), .CACHE_LINES(4)) wram_client (
        .clk        (clk_sys),
        .rstn       (rst_cnt[17]),
        .ram_din16  (16'd0),
        .ram_wword  (1'b0),
        .ram_din    (wc_ram_din),
        .ram_req    (wc_ram_req),
        .ram_write  (wc_ram_write),
        .ram_addr   (wc_ram_addr),
        .ram_dout   (wram_b2_dout),
        .ram_dout_w (),
        .ram_dout_w2(),
        .ram_busy   (wram_b2_busy),
        .b2_addr    (wram_b2_addr),
        .b2_din     (wram_b2_din),
        .b2_dout    (wram_b2_dout32),
        .b2_dout2   (32'd0),
        .b2_dqm     (wram_b2_dqm),
        .b2_req     (wram_b2_req),
        .b2_we      (wram_b2_we),
        .b2_ack     (wram_b2_ack)
    );

    pce_sdram_bank2_client #(.ENABLE_CACHE(0), .WIDE_LINE(0)) sdcw_client (
        .clk        (clk_sys),
        .rstn       (rst_cnt[17]),
        .ram_din16  (16'd0),
        .ram_wword  (1'b0),
        .ram_din    (sdcw_ram_din),
        .ram_req    (sdcw_ram_req),
        .ram_write  (1'b1),
        .ram_addr   (sdcw_ram_addr),
        .ram_dout   (),
        .ram_dout_w (),
        .ram_dout_w2(),
        .ram_busy   (sdcw_ram_busy),
        .b2_addr    (sdcw_b2_addr),
        .b2_din     (sdcw_b2_din),
        .b2_dout    (32'd0),
        .b2_dout2   (32'd0),
        .b2_dqm     (sdcw_b2_dqm),
        .b2_req     (sdcw_b2_req),
        .b2_we      (),
        .b2_ack     (sdcw_b2_ack)
    );

    pce_sdram_bank2 #(
        .RAM_CLOCK_SPEED(86_400_000)
    ) bank2 (
        .clk      (clk_ram),
        .reset_n  (sys_rst_n),
        .ready    (bank2_ready),

        .rom_addr (rom_b2_addr), .rom_din (rom_b2_din), .rom_dout (rom_b2_dout32),
        .rom_dout2(rom_b2_dout32_2),
        .rom_dqm  (rom_b2_dqm),  .rom_req (rom_b2_req), .rom_we  (rom_b2_we), .rom_ack(rom_b2_ack),

        .sdcw_addr(sdcw_b2_addr), .sdcw_din(sdcw_b2_din), .sdcw_dqm(sdcw_b2_dqm),
        .sdcw_req (sdcw_b2_req),  .sdcw_ack(sdcw_b2_ack),

        .wram_addr(wram_b2_addr), .wram_din(wram_b2_din), .wram_dout(wram_b2_dout32),
        .wram_dqm (wram_b2_dqm),  .wram_req(wram_b2_req), .wram_we (wram_b2_we), .wram_ack(wram_b2_ack),

        .sd_data (IO_sdram_dq),
        .sd_addr (bank2_sd_addr),
        .sd_dqm  (bank2_sd_dqm),
        .sd_ba   (bank2_sd_ba),
        .sd_cke  (bank2_sd_cke),
        .sd_cs   (bank2_sd_cs),
        .sd_we   (bank2_sd_we),
        .sd_ras  (bank2_sd_ras),
        .sd_cas  (bank2_sd_cas),

        .dbg_sd_cmd(), .dbg_ras1_port(), .dbg_cas1_port(),
        .dbg_bankbusy0(), .dbg_bankbusy1(),
        .dbg_need_refresh_rom(), .dbg_need_refresh_wram(),
        .dbg_force_refresh_rom(), .dbg_force_refresh_wram(),
        .dbg_refresh_addr_rom(), .dbg_refresh_addr_wram(),
        .dbg_bank_row0(), .dbg_bank_row1(),
        .dbg_bank_rfsh0(), .dbg_bank_rfsh1(),

        .dbg_sd_data_q   (b2_dbg_sd_data_q),
        .dbg_latch2_port (b2_dbg_latch2_port),
        .dbg_latch2_addr (b2_dbg_latch2_addr),
        .dbg_write_recent(b2_dbg_write_recent)
    );

end else begin : g_no_sdram_bank2
    assign bank2_ready   = 1'b0;
    assign bank2_sd_addr = 11'd0;
    assign bank2_sd_dqm  = 4'd0;
    assign bank2_sd_ba   = 2'd0;
    assign bank2_sd_cke  = 1'b0;
    assign bank2_sd_cs   = 1'b1;
    assign bank2_sd_we   = 1'b1;
    assign bank2_sd_ras  = 1'b1;
    assign bank2_sd_cas  = 1'b1;
    assign rom_b2_dout   = 8'h00;
    assign rom_b2_dout_w = 32'h0;
    assign rom_b2_busy   = 1'b0;
    assign wram_b2_dout  = 8'h00;
    assign wram_b2_busy  = 1'b0;
    assign sdcw_ram_busy = 1'b0;
end
endgenerate

// SDRAM pins from whichever controller is selected.
assign mem_ready     = SDRAM_BANK2 ? bank2_ready   : ctrl_mem_ready;
assign O_sdram_clk   = SDRAM_BANK2 ? clk_ram_sdram : ctrl_O_sdram_clk;
assign O_sdram_cke   = SDRAM_BANK2 ? bank2_sd_cke  : ctrl_O_sdram_cke;
assign O_sdram_cs_n  = SDRAM_BANK2 ? bank2_sd_cs   : ctrl_O_sdram_cs_n;
assign O_sdram_cas_n = SDRAM_BANK2 ? bank2_sd_cas  : ctrl_O_sdram_cas_n;
assign O_sdram_ras_n = SDRAM_BANK2 ? bank2_sd_ras  : ctrl_O_sdram_ras_n;
assign O_sdram_wen_n = SDRAM_BANK2 ? bank2_sd_we   : ctrl_O_sdram_wen_n;
assign O_sdram_addr  = SDRAM_BANK2 ? bank2_sd_addr : ctrl_O_sdram_addr;
assign O_sdram_ba    = SDRAM_BANK2 ? bank2_sd_ba   : ctrl_O_sdram_ba;
assign O_sdram_dqm   = SDRAM_BANK2 ? bank2_sd_dqm  : ctrl_O_sdram_dqm;

wire [9:0]  tmds_internal [2:0];
wire [23:0] sd_rgb;
wire        sd_de, sd_hsync, sd_vsync;

// OSD Scanlines: the CRT-Lite kernel in the scandoubler.
localparam CRT_LITE = 1;
wire crt_en = (CRT_LITE != 0) && companion_system_scanlines;

// The picture fills 640 of the 720-pixel active width (pillarboxed), which
// gives a 4:3 picture.
pce_scandoubler #(
    .H_CONT_START (135),
    .H_CONT_W     (640)
) scandoubler (
    .clk_sys   (clk_sys),
    .ce        (o_video_ce),
    .r         (o_video_r),
    .g         (o_video_g),
    .b         (o_video_b),
    .hs        (o_video_hs),
    .vs        (o_video_vs),
    .hbl       (o_video_hbl),
    .vbl       (o_video_vbl),
    .dcc       (o_video_dcc),

    .clk_pixel (clk_pixel),
    .rgb       (sd_rgb),
    .de        (sd_de),
    .hsync     (sd_hsync),
    .vsync     (sd_vsync),
    .crt_en    (crt_en)
);

// With no game loaded: 8 vertical colour bars (75%), 90 pixels each. Drawn
// before the OSD, so the menu shows on top.
reg  [1:0] idle_sync = 2'b00;
always @(posedge clk_pixel) idle_sync <= {idle_sync[0], no_cart_hold};
wire       idle_bars = idle_sync[1];

reg  [9:0] idle_hx = 10'd0;
always @(posedge clk_pixel) idle_hx <= sd_de ? idle_hx + 10'd1 : 10'd0;

reg  [2:0] idle_bar;
always @* begin
    if      (idle_hx <  10'd90)  idle_bar = 3'd0;
    else if (idle_hx < 10'd180)  idle_bar = 3'd1;
    else if (idle_hx < 10'd270)  idle_bar = 3'd2;
    else if (idle_hx < 10'd360)  idle_bar = 3'd3;
    else if (idle_hx < 10'd450)  idle_bar = 3'd4;
    else if (idle_hx < 10'd540)  idle_bar = 3'd5;
    else if (idle_hx < 10'd630)  idle_bar = 3'd6;
    else                         idle_bar = 3'd7;
end

wire [7:0] idle_r = (idle_bar == 3'd0 || idle_bar == 3'd1 || idle_bar == 3'd4 || idle_bar == 3'd5) ? 8'hC0 : 8'h00;
wire [7:0] idle_g = (idle_bar <= 3'd3) ? 8'hC0 : 8'h00;
wire [7:0] idle_b = (idle_bar[0] == 1'b0 && idle_bar != 3'd7) ? 8'hC0 : 8'h00;
wire [23:0] pal_rgb;
// OSD Colours: 0 = Original (MiSTer's palette), 1 = Raw RGB (the core's 3
// bits per channel, widened). With CRT-Lite on, pixels are blended levels
// rather than palette indices, so the palette is bypassed.
pce_colour_pal colour_pal (
    .grb ({sd_rgb[15:13], sd_rgb[23:21], sd_rgb[7:5]}),
    .q   (pal_rgb)
);
wire        colours_orig = ~companion_system_pal & ~crt_en;
wire [23:0] col_rgb = colours_orig ? pal_rgb : sd_rgb;
wire [23:0] pic_rgb = idle_bars ? {idle_r, idle_g, idle_b} : col_rgb;

// Audio: a phase accumulator on clk_pixel makes clk_audio, averaging
// 48 kHz: AUD_INC = 48000 * 2^25 / 28.8 MHz. The PSG output (clk_sys) is
// sampled on each tick without a synchroniser; at worst one sample is noisy.
// Samples are two's complement, as HDMI (IEC 60958) expects.
localparam integer      AUD_ACC_W = 25;
localparam [AUD_ACC_W-1:0] AUD_INC = 25'd55924;
reg  [AUD_ACC_W-1:0] aud_acc    = {AUD_ACC_W{1'b0}};
reg                  clk_audio  = 1'b0;
reg                  aud_tick   = 1'b0;
reg  [15:0]          aud_word_l = 16'h0000;
reg  [15:0]          aud_word_r = 16'h0000;
always @(posedge clk_pixel) begin
    aud_acc   <= aud_acc + AUD_INC;
    clk_audio <= aud_acc[AUD_ACC_W-1];
    aud_tick  <= (clk_audio != aud_acc[AUD_ACC_W-1]);
    if (aud_tick) begin
        aud_word_l <= o_psg_sl;
        aud_word_r <= o_psg_sr;
    end
end

wire [23:0] osd_rgb;
wire [5:0]  osd_r6, osd_g6, osd_b6;
// OSD overlay. It works on 6 bits per channel; the core has only 3, so
// nothing is lost. The offsets position the menu on the picture.
osd_u8g2 osd_u8g2_inst (
    .clk   (clk_pixel),
    .reset (~pll_locked),

    .data_in_strobe (companion_osd_strobe),
    .data_in_start  (companion_osd_start),
    .data_in        (companion_osd_data),

    .hs (sd_hsync),
    .vs (sd_vsync),

    .x_offset (-12'sd64),
    .y_offset (10'sd15),

    .r_in (pic_rgb[23:18]),
    .g_in (pic_rgb[15:10]),
    .b_in (pic_rgb[7:2]),

    .r_out (osd_r6),
    .g_out (osd_g6),
    .b_out (osd_b6)
);
assign osd_rgb = { osd_r6, osd_r6[5:4], osd_g6, osd_g6[5:4], osd_b6, osd_b6[5:4] };

// Debug: the OSD changed a pixel.
wire [23:0] pic_rgb6 = { pic_rgb[23:18], pic_rgb[23:22], pic_rgb[15:10], pic_rgb[15:14], pic_rgb[7:2], pic_rgb[7:6] };
wire       dbg_osd_diff = (osd_rgb != pic_rgb6);
reg        dbg_osd_diff_seen = 1'b0;
always @(posedge clk_pixel) if (dbg_osd_diff) dbg_osd_diff_seen <= 1'b1;

wire [2:0]  di_mode;
wire [23:0] di_video;
wire [5:0]  di_control;
wire [11:0] di_island;
wire        dbg_hb0_acr_seen;
wire        dbg_hb0_audio_seen;

// HDMI timing, audio and InfoFrames. VIDEO_RATE must match clk_pixel for
// the audio clock regeneration packets.
pce_hdmi_di #(
    .LINE(910), .H_ACT_LO(95), .H_ACT_HI(815),
    .V_ACT_START(38), .V_ACT_LINES(480),
    .DI_PACKETS(1),
    .DI_ENABLE(1),
    .VIDEO_RATE(28_800_000.0), .AUDIO_RATE(48_000), .AUDIO_BIT_WIDTH(16),
    .VIDEO_ID_CODE(2)
) hdmi_di (
    .clk_pixel   (clk_pixel),
    .clk_audio   (clk_audio),
    .reset       (1'b0),
    .rgb         (osd_rgb),
    .de          (sd_de),
    .hsync       (sd_hsync),
    .vsync       (sd_vsync),
    .audio_word_l(aud_word_l),
    .audio_word_r(aud_word_r),
    .aspect_16_9 (1'b0),
    .tmds_mode        (di_mode),
    .tmds_video_data  (di_video),
    .tmds_control_data(di_control),
    .tmds_island_data (di_island),
    .dbg_hb0_acr_seen  (dbg_hb0_acr_seen),
    .dbg_hb0_audio_seen(dbg_hb0_audio_seen)
);

tmds_channel #(.CN(0)) tmds0 (
    .clk_pixel(clk_pixel), .video_data(di_video[7:0]),
    .data_island_data(di_island[3:0]), .control_data(di_control[1:0]),
    .mode(di_mode), .tmds(tmds_internal[0])
);
tmds_channel #(.CN(1)) tmds1 (
    .clk_pixel(clk_pixel), .video_data(di_video[15:8]),
    .data_island_data(di_island[7:4]), .control_data(di_control[3:2]),
    .mode(di_mode), .tmds(tmds_internal[1])
);
tmds_channel #(.CN(2)) tmds2 (
    .clk_pixel(clk_pixel), .video_data(di_video[23:16]),
    .data_island_data(di_island[11:8]), .control_data(di_control[5:4]),
    .mode(di_mode), .tmds(tmds_internal[2])
);

// Serialiser reset at power-up, synchronised into clk_pixel_x5.
reg [7:0] vrst_cnt = 0;
always @(posedge clk_pixel) begin
    if (!vrst_cnt[7]) vrst_cnt <= vrst_cnt + 1'b1;
end

(* syn_preserve = 1 *) reg vrst_sync1 = 1'b0;
(* syn_preserve = 1 *) reg vrst_sync2 = 1'b0;
always @(posedge clk_pixel_x5) begin
    vrst_sync1 <= vrst_cnt[7];
    vrst_sync2 <= vrst_sync1;
end
wire ser_reset = ~vrst_sync2;

wire [2:0] tmds;
serializer #(.NUM_CHANNELS(3), .VIDEO_RATE(0)) serializer_inst (
    .clk_pixel     (clk_pixel),
    .clk_pixel_x5  (clk_pixel_x5),
    .reset         (ser_reset),
    .tmds_internal (tmds_internal),
    .tmds          (tmds),
    .tmds_clock    ()
);

ELVDS_OBUF tmds_bufds [3:0] (
    .I  ({clk_pixel, tmds}),
    .O  ({tmds_clk_p, tmds_data_p}),
    .OB ({tmds_clk_n, tmds_data_n})
);

// ---------------------------------------------------------------------------
// Debug instruments. Sticky flags and counters that were read with a logic
// analyser (Gowin GAO, or jcapture over JTAG) while bringing the core up.
// gao_keep folds them into the heartbeat so synthesis keeps them. They do
// not affect the console.
// ---------------------------------------------------------------------------
reg sticky_rom_ok   = 0;
reg sticky_sdram_ok = 0;
reg sticky_loaded   = 0;
reg sticky_mem_rdy  = 0;
reg loading_d       = 0;
reg [3:0] reloads   = 0;

always @(posedge clk_sys) begin
    loading_d <= loading;
    if (rom_ok)             sticky_rom_ok   <= 1'b1;
    if (sdram_ok)           sticky_sdram_ok <= 1'b1;
    if (!loading)           sticky_loaded   <= 1'b1;
    if (mem_ready)          sticky_mem_rdy  <= 1'b1;
    if (loading & ~loading_d) reloads <= reloads + 1'b1;
end

reg [24:0] heartbeat = 0;
reg        gao_keep  = 0;
always @(posedge clk_sys) heartbeat <= heartbeat + 1'b1 + {24'd0, gao_keep};

reg vec_lo_seen = 0, vec_hi_seen = 0;
reg vec_lo_bad  = 0, vec_hi_bad  = 0;
always @(posedge clk_sys) begin
    if (!loading && rom_rdy && rom_hit && o_rom_rd) begin
        if (o_rom_a[21:0] == 22'h001FFE) begin
            vec_lo_seen <= 1'b1;
            if (rom_do != 8'h27) vec_lo_bad <= 1'b1;
        end
        if (o_rom_a[21:0] == 22'h001FFF) begin
            vec_hi_seen <= 1'b1;
            if (rom_do != 8'hE1) vec_hi_bad <= 1'b1;
        end
    end
end

reg ldr_done = 0, ldr_again = 0;
always @(posedge clk_sys) begin
    if (!loading) ldr_done <= 1'b1;
    else if (ldr_done) ldr_again <= 1'b1;
end

reg [16:0] wr_done_cnt = 0;
reg        ram_busy_d  = 0;
always @(posedge clk_sys) begin
    ram_busy_d <= ram_busy;
    if (loading && ram_busy_d && !ram_busy && !wr_done_cnt[16])
        wr_done_cnt <= wr_done_cnt + 1'b1;
end

assign led[0] = ~heartbeat[24];  // heartbeat, ~1.3 Hz
reg [8:0] cpu_fetch_cnt = 0;
always @(posedge clk_sys) begin
    if (!loading && ldr_state == 4'd6 && !cpu_fetch_cnt[8])
        cpu_fetch_cnt <= cpu_fetch_cnt + 1'b1;
end

reg core_ran = 0;
always @(posedge clk_sys) if (reset_n) core_ran <= 1'b1;

reg [8:0] mem_done_cnt = 0;
reg       cst_d = 0;
always @(posedge clk_sys) begin
    cst_d <= (mem_cstate == 3'd4);
    if ((mem_cstate == 3'd4) && !cst_d && !mem_done_cnt[8])
        mem_done_cnt <= mem_done_cnt + 1'b1;
end

reg [4:0] max_page = 0;
always @(posedge clk_sys) begin
    if (!loading && o_rom_rd && o_rom_a[21:13] == 9'd0
        && o_rom_a[12:8] != 5'd31 && o_rom_a[12:8] > max_page)
        max_page <= o_rom_a[12:8];
end

assign led[1] = ~1'b0;
reg [12:0] vram_wr_cnt = 0;
always @(posedge clk_sys)
    if (!loading && o_vram0_we && !vram_wr_cnt[12]) vram_wr_cnt <= vram_wr_cnt + 1'b1;
assign led[2] = ~1'b0;
assign led[3] = ~1'b0;
assign led[4] = ~1'b0;
assign led[5] = ~1'b0;

reg core_pixel_nonzero = 0;
always @(posedge clk_sys)
    if (!loading && o_video_ce && !o_video_hbl && !o_video_vbl &&
        {o_video_r, o_video_g, o_video_b} != 9'd0)
        core_pixel_nonzero <= 1'b1;

reg late_write = 0;
reg late_lo    = 0;
always @(posedge clk_sys) begin
    if (!loading && ram_write && ram_req) begin
        late_write <= 1'b1;
        if (ram_addr < 23'h002000) late_lo <= 1'b1;
    end
end

reg [25:0] boot_dly = 0;
always @(posedge clk_sys)
    if (!loading && !boot_dly[25]) boot_dly <= boot_dly + 1'b1;

reg        vbl_d = 0;
reg [7:0]  irq_hold = 0;
wire       force_irq = |irq_hold;
always @(posedge clk_sys) begin
    vbl_d <= o_video_vbl;
    if (boot_dly[25] && o_video_vbl && !vbl_d) irq_hold <= 8'd64;
    else if (|irq_hold)                        irq_hold <= irq_hold - 1'b1;
end

reg force_fired = 0;
reg irq1_low_seen = 0;
always @(posedge clk_sys) begin
    if (force_irq)    force_fired   <= 1'b1;
    if (!o_vdc_irq_n) irq1_low_seen <= 1'b1;
end

reg forced_taken = 0;
always @(posedge clk_sys)
    if (!loading && o_rom_rd && (o_rom_a == 22'h001FF8 || o_rom_a == 22'h001FF9))
        forced_taken <= 1'b1;

reg [21:0] dbg_rom_a  = 0;
reg [7:0]  dbg_rom_do = 0;
reg        dbg_rom_rd = 0, dbg_rom_rdy = 0, dbg_loading = 1;
always @(posedge clk_sys) begin
    dbg_rom_a   <= o_rom_a;
    dbg_rom_do  <= rom_do;
    dbg_rom_rd  <= o_rom_rd;
    dbg_rom_rdy <= rom_rdy;
    dbg_loading <= loading;
end

reg ie_any_s = 0, irq_vbl_s = 0, irq_rcr_s = 0, irq_any_s = 0, vec_taken_s = 0;
always @(posedge clk_sys) if (!loading) begin
    if (o_cr_ie_vc | o_cr_ie_rc) ie_any_s <= 1'b1;
    if (o_irq_vbl)  irq_vbl_s <= 1'b1;
    if (o_irq_rcr)  irq_rcr_s <= 1'b1;
    if (o_irq_any)  irq_any_s <= 1'b1;
    if (dbg_rom_rd && (dbg_rom_a == 22'h001FF8 || dbg_rom_a == 22'h001FF9))
        vec_taken_s <= 1'b1;
end

reg [24:0] slow = 0;
reg [4:0]  bank_now = 0;
always @(posedge clk_sys) begin
    slow <= slow + 1'b1;
    if (slow == 0 && !loading && o_rom_rd) bank_now <= o_rom_a[17:13];
end

reg [4:0] bank_or = 0;
always @(posedge clk_sys)
    if (!loading && o_rom_rd) bank_or <= bank_or | o_rom_a[17:13];

reg mism_00 = 0, mism_1F = 0, mism_10 = 0, mism_20 = 0;
always @(posedge clk_sys) begin
    if (!loading && rom_rdy && rom_hit) begin
        if (o_rom_a == 22'h000000 && rom_do != 8'h62) mism_00 <= 1'b1;
        if (o_rom_a == 22'h001FFE && rom_do != 8'h27) mism_1F <= 1'b1;
        if (o_rom_a == 22'h010000 && rom_do != 8'hCE) mism_10 <= 1'b1;
        if (o_rom_a == 22'h020000 && rom_do != 8'hE0) mism_20 <= 1'b1;
    end
end

reg ram_write_seen = 0;
reg ram_read_nonzero = 0;
reg ram_sel_seen = 0;
reg any_wr_seen = 0;
always @(posedge clk_sys) begin
    if (!loading && o_ram_we)          ram_write_seen   <= 1'b1;
    if (!loading && o_ram_sel)         ram_sel_seen     <= 1'b1;
    if (!loading && o_any_wr)          any_wr_seen      <= 1'b1;
    if (!loading && o_ram_do != 8'd0)  ram_read_nonzero <= 1'b1;
end

reg any_wr_real_seen = 0;
always @(posedge clk_sys) if (w_dbg_cpu_wr) any_wr_real_seen <= 1'b1;

reg ar2_exact = 0;
always @(posedge clk_sys)
    if (!loading && o_ar == 5'd2) ar2_exact <= 1'b1;

reg [4:0] ar_or = 0;
always @(posedge clk_sys)
    if (!loading) ar_or <= ar_or | o_ar;

reg ar_nonzero_seen = 0;
reg ar2_seen = 0;
reg cpuwr_pend_seen = 0;
always @(posedge clk_sys) begin
    if (!loading && o_ar != 5'd0)  ar_nonzero_seen <= 1'b1;
    if (!loading && o_ar == 5'd2)  ar2_seen        <= 1'b1;
    if (!loading && o_cpuwr_pend)  cpuwr_pend_seen <= 1'b1;
end

reg vbl_seen = 0;
reg vdisp_d = 0;
reg slot_cpu_seen = 0;
always @(posedge clk_sys) begin
    vdisp_d <= o_vdisp;
    if (!loading && vdisp_d && !o_vdisp) vbl_seen <= 1'b1;
    if (!loading && o_slot_cpu)    slot_cpu_seen   <= 1'b1;
end

reg vram_write_raw_seen = 0;
reg vram_a15_seen = 0;
always @(posedge clk_sys) begin
    if (!loading && o_vram_write_raw) vram_write_raw_seen <= 1'b1;
    if (!loading && o_vram_a15)       vram_a15_seen       <= 1'b1;
end

reg vce_written = 0;
reg vdc_written = 0;
always @(posedge clk_sys) begin
    if (!loading && o_vce_wr) vce_written <= 1'b1;
    if (!loading && o_vdc_wr) vdc_written <= 1'b1;
end

reg above8k_seen = 0;
always @(posedge clk_sys)
    if (!dbg_loading && dbg_rom_rd && dbg_rom_a[21:13] != 9'd0) above8k_seen <= 1'b1;

reg vdc_irq_seen = 0;
always @(posedge clk_sys)
    if (!loading && !o_vdc_irq_n) vdc_irq_seen <= 1'b1;

reg reset_vec_ok = 0;
always @(posedge clk_sys)
    if (!dbg_loading && dbg_rom_rdy && dbg_rom_a == 22'h001FFE && dbg_rom_do == 8'h27)
        reset_vec_ok <= 1'b1;

reg any_fetch_seen = 0;
always @(posedge clk_sys)
    if (!dbg_loading && dbg_rom_rd) any_fetch_seen <= 1'b1;

reg       vec_addr_seen = 0;
reg       vec_rdy_seen  = 0;
reg [7:0] vec_byte      = 0;
always @(posedge clk_sys) if (!dbg_loading) begin
    if (dbg_rom_rd && dbg_rom_a == 22'h001FFE)
        vec_addr_seen <= 1'b1;
    if (dbg_rom_rdy && dbg_rom_a == 22'h001FFE && !vec_rdy_seen) begin
        vec_byte     <= dbg_rom_do;
        vec_rdy_seen <= 1'b1;
    end
end

reg [21:0] fetches = 0;
reg        vram_written = 0;
reg [21:0] rom_a_d = 0;

always @(posedge clk_sys) begin
    rom_a_d <= o_rom_a;
    if (!loading && o_rom_rd && (o_rom_a != rom_a_d))
        fetches <= fetches + 1'b1;
    if (!loading && o_vram0_we)
        vram_written <= 1'b1;
end

reg [7:0]  g_ram_dw  ;
reg [7:0]  g_linedat ;
reg [7:0]  g_linetag ;
reg [3:0]  g_roma    ;
reg        g_lvalid  ;
reg        g_fetching;
reg        g_lhit    ;
reg [2:0]  g_cstate  ;
reg [3:0]  g_sdst    ;
reg [2:0]  g_ldst    ;
reg        g_p2ack   ;
reg        g_rom_rdy ;
reg        g_ram_req ;
reg        g_ram_busy;
always @(posedge clk_sys) begin
    g_ram_dw   <= ram_dout_w[7:0];
    g_linedat  <= loader.line_data[7:0];
    g_linetag  <= loader.line_tag[7:0];
    g_roma     <= o_rom_a[5:2];
    g_lvalid   <= loader.line_valid;
    g_fetching <= loader.fetching;
    g_lhit     <= loader.line_hit;
    g_cstate   <= mem_cstate;
    g_sdst     <= mem_sdst;
    g_ldst     <= loader.state;
    g_p2ack    <= mem_p2ack;
    g_rom_rdy  <= rom_rdy;
    g_ram_req  <= ram_req;
    g_ram_busy <= ram_busy;
end

reg [9:0]  g_romahi   ;
reg [1:0]  g_romalo   ;
reg [7:0]  g_romdo    ;
reg [3:0]  g_vblcnt   ;
reg        g_vs       ;
reg [7:0]  g_vramwecnt;
reg        g_forceirq  ;
reg        g_ivec     ;
reg        g_resetn   ;
reg        g_loading  ;
always @(posedge clk_sys) begin
    g_romahi    <= o_rom_a[15:6];
    g_romalo    <= o_rom_a[1:0];
    g_romdo     <= rom_do;
    g_vblcnt    <= g_vblcnt    + {3'd0, o_video_vbl};
    g_vs        <= o_video_vs;
    g_vramwecnt <= g_vramwecnt + {7'd0, o_vram0_we};
    g_forceirq  <= force_irq;
    g_ivec      <= o_rom_rd && (o_rom_a == 22'h001FF8 || o_rom_a == 22'h001FF9);
    g_resetn    <= reset_n;
    g_loading   <= loading;
end

// jcapture2 JTAG logic analyser: off. 1 adds it, with the taps below.
localparam JCAPTURE = 0;

wire        jcap_trigger_match;
wire [3:0]  jcap_user_ir;
wire        jcap_user_q;
wire        jcap_user_ir_update, jcap_user_update;

wire [20:0] dbg_flashboot_d = { any_fetch_seen, vec_addr_seen, vec_rdy_seen,
                                 vec_byte, reset_vec_ok, above8k_seen,
                                 mism_00, mism_1F, mism_10, mism_20,
                                 ram_write_seen, vbl_seen, vdc_irq_seen,
                                 dbg_loading };
reg [20:0] dbg_flashboot_sync1 = 0, dbg_flashboot_sync2 = 0;
reg        dbg_osd_diff_seen_sync1 = 0, dbg_osd_diff_seen_sync2 = 0;
always @(posedge clk_ram) begin
    dbg_flashboot_sync1     <= dbg_flashboot_d;
    dbg_flashboot_sync2     <= dbg_flashboot_sync1;
    dbg_osd_diff_seen_sync1 <= dbg_osd_diff_seen;
    dbg_osd_diff_seen_sync2 <= dbg_osd_diff_seen_sync1;
end

wire [19:0] dbg_vdcprobe_d = { ar_or, bank_or, any_wr_real_seen, core_ran,
                                sdc_core_rw_want_ever_seen, sdc_core_rw_irq_ever_seen, sdc_core_rw_reply_ever_seen,
                                sdc_load_done_ever_seen, ar2_seen, ar_nonzero_seen,
                                ram_sel_seen, any_wr_seen };
reg [19:0] dbg_vdcprobe_sync1 = 0, dbg_vdcprobe_sync2 = 0;
always @(posedge clk_ram) begin
    dbg_vdcprobe_sync1 <= dbg_vdcprobe_d;
    dbg_vdcprobe_sync2 <= dbg_vdcprobe_sync1;
end

reg video_vbl_toggle_seen = 0;
always @(posedge clk_sys)
    if (!loading && (o_video_vbl != vbl_d)) video_vbl_toggle_seen <= 1'b1;
reg video_vbl_toggle_seen_sync1 = 0, video_vbl_toggle_seen_sync2 = 0;
always @(posedge clk_ram) begin
    video_vbl_toggle_seen_sync1 <= video_vbl_toggle_seen;
    video_vbl_toggle_seen_sync2 <= video_vbl_toggle_seen_sync1;
end

reg [13:0] dbg_fetches_sync1 = 0, dbg_fetches_sync2 = 0;
always @(posedge clk_ram) begin
    dbg_fetches_sync1 <= fetches[13:0];
    dbg_fetches_sync2 <= dbg_fetches_sync1;
end

localparam JCAP_PAD = 0;
reg [3:0] dbg_btn_nib = 4'hF;
always @(posedge clk_sys) if (!o_joy_out[0]) dbg_btn_nib <= joypad_joy_in;
wire [11:0] dbg_cpu_d = { dbg_btn_nib, joypad_joy_in, o_joy_out, s2_pressed, pad_run_w };
reg [11:0] dbg_cpu_sync1 = 0, dbg_cpu_sync2 = 0;
always @(posedge clk_ram) begin
    dbg_cpu_sync1 <= dbg_cpu_d;
    dbg_cpu_sync2 <= dbg_cpu_sync1;
end
reg [7:0] dbg_joy_sync1 = 0, dbg_joy_sync2 = 0;
reg [7:0] dbg_con_sync1 = 0, dbg_con_sync2 = 0;
always @(posedge clk_ram) begin
    dbg_joy_sync1 <= joystick0;
    dbg_joy_sync2 <= dbg_joy_sync1;
    dbg_con_sync1 <= joystick0_console;
    dbg_con_sync2 <= dbg_con_sync1;
end

wire [57:0] jcapture_d = JCAP_PAD ?
                          { 29'd0,
                            dbg_cpu_sync2,
                            dbg_con_sync2,
                            dbg_joy_sync2,
                            pll_locked } :
                          { dbg_fetches_sync2,
                            video_vbl_toggle_seen_sync2,
                            dbg_vdcprobe_sync2,
                            dbg_osd_diff_seen_sync2,
                            dbg_flashboot_sync2,
                            pll_locked };

generate
if (JCAPTURE) begin : g_jcapture
    jcapture #(
        .capturewidth(58),
        .capturedepth(10),
        .userwidth(1)
    ) jcapture_probe (
        .clk            (clk_ram),
        .reset_n        (sys_rst_n),
        .stb            (1'b1),
        .capture_d      (jcapture_d),
        .trigger_match  (jcap_trigger_match),
        .user_ir        (jcap_user_ir),
        .user_ir_update (jcap_user_ir_update),
        .user_d         (1'd0),
        .user_q         (jcap_user_q),
        .user_update    (jcap_user_update)
    );
end
endgenerate

reg [7:0] g5_memrdycnt;
reg [7:0] g5_ramreqcnt;
reg [7:0] g5_romrdcnt ;
reg [7:0] g5_synccnt  ;
reg [7:0] g5_vclrcnt  ;
reg       g5_srun     ;
reg       g5_sfetch   ;
reg       g5_sfetchd  ;
reg       g5_cidle    ;
reg       g5_crd1     ;
reg       g5_yield    ;
reg       g5_cpupend  ;
reg       g5_chcs     ;
always @(posedge clk_sys) begin
    g5_memrdycnt <= g5_memrdycnt + {7'd0, mem_ready};
    g5_ramreqcnt <= g5_ramreqcnt + {7'd0, ram_req};
    g5_romrdcnt  <= g5_romrdcnt  + {7'd0, o_rom_rd};
    g5_synccnt   <= g5_synccnt   + {7'd0, mem_sync};
    g5_vclrcnt   <= g5_vclrcnt   + {7'd0, vram_clearing};
    g5_srun      <= (loader.state == 3'd4);
    g5_sfetch    <= (loader.state == 3'd5);
    g5_sfetchd   <= (loader.state == 3'd6);
    g5_cidle     <= (mem_cstate == 3'd0);
    g5_crd1      <= (mem_cstate == 3'd3);
    g5_yield     <= memory.yield_next;
    g5_cpupend   <= memory.cpu_pending;
    g5_chcs      <= memory.ch_cs;
end

reg       g6_sync_seen  = 1'b0;
reg       g6_p2ack_seen = 1'b0;
reg       g6_p2ack_d    = 1'b0;
reg [7:0] g6_sync_div   = 8'd0;
reg       g6_sync_beat  = 1'b0;
always @(posedge clk_ram or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        g6_sync_seen  <= 1'b0;
        g6_p2ack_seen <= 1'b0;
        g6_p2ack_d    <= 1'b0;
        g6_sync_div   <= 8'd0;
        g6_sync_beat  <= 1'b0;
    end else begin
        if (mem_sync)                g6_sync_seen <= 1'b1;
        g6_sync_div <= g6_sync_div + {7'd0, mem_sync};
        if (mem_sync && g6_sync_div == 8'hFF) g6_sync_beat <= ~g6_sync_beat;
        g6_p2ack_d  <= mem_p2ack;
        if (mem_p2ack != g6_p2ack_d) g6_p2ack_seen <= 1'b1;
    end
end

reg [23:0] g7_linedat_hi;
always @(posedge clk_sys) g7_linedat_hi <= loader.line_data[31:8];

reg        g10_seen;
reg [15:0] g10_sddin_l;
reg [15:0] g10_dq_l;
reg        g10_wen_n_l;
reg [15:1] g10_wraddr;
always @(posedge clk_sys or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        g10_seen <= 1'b0;
    end else begin
        g10_wraddr <= ram_addr[15:1];
        if ((loader.state == 3'd2) && (ram_addr == 23'h000138)) begin
            g10_seen     <= 1'b1;
            g10_sddin_l  <= memory.ram.ram_din;
            g10_dq_l     <= IO_sdram_dq[15:0];
            g10_wen_n_l  <= O_sdram_wen_n;
        end
    end
end

reg g12_verify_seen;
always @(posedge clk_sys or negedge sys_rst_n) begin
    if (!sys_rst_n) g12_verify_seen <= 1'b0;
    else if (loader.state == 3'd7) g12_verify_seen <= 1'b1;
end

reg [15:0] g13_vclrcnt;
always @(posedge clk_sys) g13_vclrcnt <= vclr_cnt;

reg g14_s1db;
always @(posedge clk_sys) g14_s1db <= s1_db;

reg g15_pin_low_seen;
reg g15_pin_low_during_copy;
always @(posedge clk_sys or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        g15_pin_low_seen        <= 1'b0;
        g15_pin_low_during_copy <= 1'b0;
    end else begin
        if (!s1_sync[2]) g15_pin_low_seen <= 1'b1;
        if (!s1_sync[2] && loading) g15_pin_low_during_copy <= 1'b1;
    end
end

reg g16_vramwe_seen;
always @(posedge clk_sys or negedge sys_rst_n) begin
    if (!sys_rst_n) g16_vramwe_seen <= 1'b0;
    else if (!loading && o_vram0_we) g16_vramwe_seen <= 1'b1;
end

reg [17:0] g17_vramwecnt;
always @(posedge clk_sys or negedge sys_rst_n) begin
    if (!sys_rst_n)
        g17_vramwecnt <= 18'd0;
    else if (!loading && o_vram0_we && ~&g17_vramwecnt)
        g17_vramwecnt <= g17_vramwecnt + 1'b1;
end

reg  [4:0] g18_vdc_ar;
reg  [7:0] g18_vdc_wdata;
reg        g18_vdc_wstb;
reg  [4:0] g18_vdc_armax;
reg        g18_vdc_initdone;
always @(posedge clk_sys) begin
    g18_vdc_ar       <= w_dbg_vdc_ar;
    g18_vdc_wdata    <= w_dbg_vdc_wdata;
    g18_vdc_wstb     <= w_dbg_vdc_wstb;
    g18_vdc_armax    <= w_dbg_vdc_armax;
    g18_vdc_initdone <= w_dbg_vdc_initdone;
end

reg [14:0] g18_ramA;
reg        g18_ramA_bat_seen;
reg        g18_ramA_hi_seen;
reg [14:0] g18_ramA_max;
always @(posedge clk_sys or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        g18_ramA          <= 15'd0;
        g18_ramA_bat_seen <= 1'b0;
        g18_ramA_hi_seen  <= 1'b0;
        g18_ramA_max      <= 15'd0;
    end else if (!loading && o_vram0_rd) begin
        g18_ramA <= o_vram0_a[14:0];
        if (o_vram0_a[14:0] <  15'h0800)           g18_ramA_bat_seen <= 1'b1;
        if (o_vram0_a[14:0] >= 15'h6800)           g18_ramA_hi_seen  <= 1'b1;
        if (o_vram0_a[14:0] >  g18_ramA_max)       g18_ramA_max      <= o_vram0_a[14:0];
    end
end

reg g19_acr_seen_m   = 1'b0, g19_acr_seen   = 1'b0;
reg g19_audio_seen_m = 1'b0, g19_audio_seen = 1'b0;
always @(posedge clk_sys) begin
    g19_acr_seen_m   <= dbg_hb0_acr_seen;    g19_acr_seen   <= g19_acr_seen_m;
    g19_audio_seen_m <= dbg_hb0_audio_seen;  g19_audio_seen <= g19_audio_seen_m;
end

reg g19_clkaud_m = 1'b0, g19_clkaud_s = 1'b0, g19_clkaud_sd = 1'b0, g19_clkaud_toggled = 1'b0;
always @(posedge clk_sys) begin
    g19_clkaud_m  <= clk_audio;
    g19_clkaud_s  <= g19_clkaud_m;
    g19_clkaud_sd <= g19_clkaud_s;
    if (g19_clkaud_s != g19_clkaud_sd) g19_clkaud_toggled <= 1'b1;
end

always @(posedge clk_sys)
    // Fold every tap into one bit so none is optimised away.
    gao_keep <= ^{ g_linedat, g_linetag, g_roma, g_lvalid, g_fetching,
                   g_lhit, g_cstate, g_sdst, g_ldst, g_p2ack, g_rom_rdy,
                   g_ram_req, g_ram_busy,
                   g_romahi, g_romalo, g_romdo, g_vblcnt, g_vs, g_vramwecnt,
                   g_forceirq, g_ivec, g_resetn, g_loading,
                   g5_memrdycnt, g5_ramreqcnt, g5_romrdcnt, g5_synccnt,
                   g5_vclrcnt, g5_srun, g5_sfetch, g5_sfetchd, g5_cidle,
                   g5_crd1, g5_yield, g5_cpupend, g5_chcs,
                   g6_sync_seen, g6_p2ack_seen, g6_sync_beat, g6_sync_div,
                   g7_linedat_hi,
                   g10_seen, g10_sddin_l,
                   g10_wen_n_l, g10_wraddr,
                   g12_verify_seen, g13_vclrcnt, g14_s1db,
                   g15_pin_low_seen, g15_pin_low_during_copy,
                   g16_vramwe_seen, g17_vramwecnt,
                   g18_vdc_ar, g18_vdc_wdata, g18_vdc_wstb, g18_vdc_armax,
                   g18_vdc_initdone, g18_ramA, g18_ramA_bat_seen,
                   g18_ramA_hi_seen, g18_ramA_max,
                   g19_acr_seen, g19_audio_seen, g19_clkaud_toggled,
                   jcap_trigger_match, jcap_user_ir, jcap_user_q,
                   jcap_user_ir_update, jcap_user_update };

endmodule
