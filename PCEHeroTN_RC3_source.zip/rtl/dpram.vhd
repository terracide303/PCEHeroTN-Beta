-- dpram.vhd -- PCEHeroTN
--
-- Vendor-neutral replacement for MiSTer's Altera dpram. The core's block
-- RAMs go through this entity (the PSG volume table uses dprom.vhd), and it
-- was the only Altera-specific part of the core. The interface (generics, ports and
-- defaults) is MiSTer's, so no instantiation changes.
--
-- Behaviour of the altsyncram it replaces:
--   BIDIR_DUAL_PORT, one clock, enable_a/enable_b as clock enables,
--   unregistered output (q valid one clock after the address),
--   read-during-write = NEW_DATA: a write returns the written data.
--
-- Gowin's DPB/DPX9B refuse write-first mode, so the memory is described as
-- no-change and a bypass register puts the written data on the output.
-- Same result at the ports. Getting this wrong would show as the odd wrong
-- pixel or stale sprite, not as a build error.
--
-- Initial contents come from init_pkg.vhd, not from a file; see init_ram.
--
-- Interface after MiSTer TurboGrafx16 (rtl/dpram.vhd); the body is new.

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library work;
use work.pce_init_pkg.all;

entity dpram is
    generic (
        addr_width    : integer := 8;
        data_width    : integer := 8;
        mem_init_file : string := " ";
        disable_value : std_logic := '1'
    );
    port (
        clock     : in  std_logic;

        address_a : in  std_logic_vector(addr_width-1 downto 0);
        data_a    : in  std_logic_vector(data_width-1 downto 0) := (others => '0');
        enable_a  : in  std_logic := '1';
        wren_a    : in  std_logic := '0';
        q_a       : out std_logic_vector(data_width-1 downto 0);
        cs_a      : in  std_logic := '1';

        address_b : in  std_logic_vector(addr_width-1 downto 0) := (others => '0');
        data_b    : in  std_logic_vector(data_width-1 downto 0) := (others => '0');
        enable_b  : in  std_logic := '1';
        wren_b    : in  std_logic := '0';
        q_b       : out std_logic_vector(data_width-1 downto 0);
        cs_b      : in  std_logic := '1'
    );
end entity;

architecture rtl of dpram is

    type ram_t is array (0 to 2**addr_width - 1)
        of std_logic_vector(data_width-1 downto 0);

    -- Initial contents: the VCE boot palette. (The PSG volume table branch is
    -- unused here: the PSG reads its table through dprom.vhd.) Matched on the
    -- strings the core already passes. Not read from mem_init_file: VHDL file reads are a simulation
    -- feature that a synthesis tool may accept and then silently zero.
    function init_ram return ram_t is
        variable r : ram_t := (others => (others => '0'));
    begin
        if mem_init_file = "HUC6280/voltab.mif" then
            for i in INIT_VOLTAB'range loop
                if i <= r'high then
                    r(i) := INIT_VOLTAB(i)(data_width-1 downto 0);
                end if;
            end loop;
        elsif mem_init_file = "huc6260_palette_init.mif" then
            for i in INIT_PALETTE'range loop
                if i <= r'high then
                    r(i) := INIT_PALETTE(i)(data_width-1 downto 0);
                end if;
            end loop;
        end if;
        return r;
    end function;

    shared variable ram : ram_t := init_ram;

    -- Force block RAM. Left to itself Gowin built small instances from LUTs,
    -- which are the scarcer resource here.
    attribute syn_ramstyle : string;
    attribute syn_ramstyle of ram : variable is "block_ram";

    signal q0        : std_logic_vector(data_width-1 downto 0) := (others => '0');
    signal q1        : std_logic_vector(data_width-1 downto 0) := (others => '0');

    -- write-first bypass, see the header
    signal bypass_a  : std_logic := '0';
    signal bypass_b  : std_logic := '0';
    signal held_a    : std_logic_vector(data_width-1 downto 0) := (others => '0');
    signal held_b    : std_logic_vector(data_width-1 downto 0) := (others => '0');

    signal we_a      : std_logic;
    signal we_b      : std_logic;

begin

    -- cs gates writes, as in the original
    we_a <= wren_a and cs_a;
    we_b <= wren_b and cs_b;

    process (clock)
    begin
        if rising_edge(clock) then
            if enable_a = '1' then
                -- No-change: write or read, never both. The bypass supplies the written data.
                if we_a = '1' then
                    ram(to_integer(unsigned(address_a))) := data_a;
                else
                    q0 <= ram(to_integer(unsigned(address_a)));
                end if;

                bypass_a <= we_a;
                held_a   <= data_a;
            end if;
        end if;
    end process;

    process (clock)
    begin
        if rising_edge(clock) then
            if enable_b = '1' then
                -- Same as port A.
                if we_b = '1' then
                    ram(to_integer(unsigned(address_b))) := data_b;
                else
                    q1 <= ram(to_integer(unsigned(address_b)));
                end if;

                bypass_b <= we_b;
                held_b   <= data_b;
            end if;
        end if;
    end process;

    -- As in the original: a deselected port reads disable_value. VRAM relies
    -- on reading 0.
    q_a <= (others => disable_value) when cs_a = '0' else
           held_a                    when bypass_a = '1' else
           q0;

    q_b <= (others => disable_value) when cs_b = '0' else
           held_b                    when bypass_b = '1' else
           q1;

end architecture;
