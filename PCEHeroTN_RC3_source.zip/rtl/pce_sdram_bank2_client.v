// pce_sdram_bank2_client.v -- PCEHeroTN
//
// Adapter between a CPU-side client (rom_loader or wram_sdram) and one
// 32-bit client port of pce_sdram_bank2. One instance per client, each with
// its own SDRAM bank, so ROM and work RAM never queue behind each other.
//
// Client side (clk_sys): byte address, ram_req held until ram_busy drops,
// ram_dout / ram_dout_w valid when it does.
//
// Engine side (clk_ram): b2_* are driven from clk_sys and held for the whole
// transaction; clk_ram and clk_sys come from one PLL and are timed as one
// clock group. b2_req and b2_ack are toggles; the ack comes back through
// a 3-flop synchroniser.
//
// Address: ram_addr[20:2] is the word address inside the client's own bank.
// ROM starts at 0 and work RAM's base sets only bit 21, so the bank-local
// address is just that slice.
//
// Writes: DQM is active low. A byte write enables one lane from ram_addr[1:0]
// with the byte copied to all four; a word write enables two lanes. Reads
// always fetch the whole 32-bit word.
//
// Optional read cache (ENABLE_CACHE), direct-mapped, 1/2/4 words. Worth it
// only for work RAM, which reads single bytes and goes back to the same
// addresses often (sequential read 15 -> 8.25 clk_sys). rom_loader has its own
// line cache, so every ROM request reaching here is already a miss. A write
// to a cached word invalidates it before the write starts, and the client
// cannot issue another request until ram_busy drops.

`default_nettype none

module pce_sdram_bank2_client #(
    // 0 = no read cache (ROM), 1 = on (work RAM)
    parameter ENABLE_CACHE = 0,
    // Cache lines when ENABLE_CACHE=1: 1, 2 or 4.
    parameter CACHE_LINES  = 1,
    // 1 = also return the burst's second word on ram_dout_w2 (ROM's 8-byte lines).
    parameter WIDE_LINE = 0
) (
    input  wire        clk,  // clk_sys
    input  wire        rstn,

    // Client side, byte addressed.
    input  wire [15:0] ram_din16,
    input  wire        ram_wword,  // write ram_din16 as a 16-bit word
    input  wire [7:0]  ram_din,
    input  wire        ram_req,
    input  wire        ram_write,
    input  wire [22:0] ram_addr,
    output reg  [7:0]  ram_dout,
    output reg  [31:0] ram_dout_w,
    output reg  [31:0] ram_dout_w2,  // WIDE_LINE only; valid with ram_dout_w
    output reg         ram_busy,

    // Engine side: one pce_sdram_bank2 client port, toggle handshake.
    output reg  [18:0] b2_addr,
    output reg  [31:0] b2_din,
    input  wire [31:0] b2_dout,
    input  wire [31:0] b2_dout2,  // WIDE_LINE only
    output reg  [3:0]  b2_dqm,
    output reg         b2_req,
    output reg         b2_we,
    input  wire        b2_ack
);

// Extra clk_sys cycles after the synchronised ack before the data is
// sampled. 0 is enough: the data path is timed by STA, and the data is valid
// 2 clk_ram after the ack, well before the synchroniser lets it be read.
localparam [1:0] SETTLE = 2'd0;

localparam [1:0] A_IDLE   = 2'd0,
                 A_WAIT   = 2'd1,  // b2_req flipped, waiting for the ack
                 A_SETTLE = 2'd2,  // ack synchronised
                 A_DONE   = 2'd3;  // data valid; busy until ram_req drops

reg [1:0] state;
reg [1:0] byte_sel;
reg [1:0] settle_cnt;

// Arrays are sized for 4 lines; with fewer, IDX_MASK keeps the index in
// range and the unused entries are removed by synthesis.
localparam [1:0] IDX_MASK = (CACHE_LINES == 4) ? 2'b11 :
                             (CACHE_LINES == 2) ? 2'b01 :
                                                   2'b00;

reg        cache_valid [0:3];
reg [18:0] cache_tag   [0:3];
reg [31:0] cache_data  [0:3];
reg [1:0]  fill_idx;  // line to fill or invalidate
integer    li;

reg ack_s1 = 1'b0, ack_s2 = 1'b0, ack_s3 = 1'b0;  // b2_ack synchroniser
always @(posedge clk or negedge rstn) begin
    if (!rstn) begin
        ack_s1 <= 1'b0; ack_s2 <= 1'b0; ack_s3 <= 1'b0;
    end else begin
        ack_s1 <= b2_ack;
        ack_s2 <= ack_s1;
        ack_s3 <= ack_s2;
    end
end
wire ack_done = (ack_s2 != ack_s3);

always @(posedge clk or negedge rstn) begin
    if (!rstn) begin
        state      <= A_IDLE;
        b2_addr    <= 19'd0;
        b2_din     <= 32'd0;
        b2_dqm     <= 4'hF;
        b2_req     <= 1'b0;
        b2_we      <= 1'b0;
        byte_sel   <= 2'd0;
        settle_cnt <= 2'd0;
        ram_busy   <= 1'b0;
        ram_dout   <= 8'd0;
        ram_dout_w <= 32'd0;
        ram_dout_w2 <= 32'd0;
        fill_idx   <= 2'd0;
        for (li = 0; li < 4; li = li + 1) cache_valid[li] <= 1'b0;
    end else begin
        case (state)

        A_IDLE:
            if (ram_req) begin
                ram_busy <= 1'b1;
                byte_sel <= ram_addr[1:0];
                // Cache hit: no SDRAM access.
                if (ENABLE_CACHE && !ram_write &&
                    cache_valid[ram_addr[3:2] & IDX_MASK] &&
                    cache_tag[ram_addr[3:2] & IDX_MASK] == ram_addr[20:2]) begin
                    ram_dout_w <= cache_data[ram_addr[3:2] & IDX_MASK];
                    ram_dout   <= (ram_addr[1:0] == 2'd0) ? cache_data[ram_addr[3:2] & IDX_MASK][7:0]   :
                                  (ram_addr[1:0] == 2'd1) ? cache_data[ram_addr[3:2] & IDX_MASK][15:8]  :
                                  (ram_addr[1:0] == 2'd2) ? cache_data[ram_addr[3:2] & IDX_MASK][23:16] :
                                                             cache_data[ram_addr[3:2] & IDX_MASK][31:24];
                    state      <= A_DONE;
                end else begin
                    b2_addr  <= ram_addr[20:2];
                    b2_we    <= ram_write;
                    fill_idx <= ram_addr[3:2] & IDX_MASK;
                    if (ram_write) begin
                        // A write drops the cached copy of its word.
                        if (cache_valid[ram_addr[3:2] & IDX_MASK] &&
                            cache_tag[ram_addr[3:2] & IDX_MASK] == ram_addr[20:2])
                            cache_valid[ram_addr[3:2] & IDX_MASK] <= 1'b0;
                        if (ram_wword) begin
                            b2_dqm <= ram_addr[1] ? 4'b0011 : 4'b1100;
                            b2_din <= {ram_din16, ram_din16};
                        end else begin
                            b2_dqm <= (ram_addr[1:0] == 2'd0) ? 4'b1110 :
                                      (ram_addr[1:0] == 2'd1) ? 4'b1101 :
                                      (ram_addr[1:0] == 2'd2) ? 4'b1011 :
                                                                 4'b0111;
                            b2_din <= {4{ram_din}};
                        end
                    end else begin
                        b2_dqm <= 4'hF;  // DQM is ignored on reads
                        b2_din <= 32'd0;
                    end
                    b2_req <= ~b2_req;
                    state  <= A_WAIT;
                end
            end

        A_WAIT:
            if (ack_done) begin
                settle_cnt <= 2'd0;
                state      <= A_SETTLE;
            end

        A_SETTLE:
            if (settle_cnt >= SETTLE) begin
                ram_dout_w <= b2_dout;
                if (WIDE_LINE) ram_dout_w2 <= b2_dout2;  // the second word lands 1 clk_ram after the first
                ram_dout   <= (byte_sel == 2'd0) ? b2_dout[7:0]   :
                              (byte_sel == 2'd1) ? b2_dout[15:8]  :
                              (byte_sel == 2'd2) ? b2_dout[23:16] :
                                                    b2_dout[31:24];
                if (ENABLE_CACHE && !b2_we) begin
                    cache_valid[fill_idx] <= 1'b1;
                    cache_tag[fill_idx]   <= b2_addr;
                    cache_data[fill_idx]  <= b2_dout;
                end
                state      <= A_DONE;
            end else
                settle_cnt <= settle_cnt + 2'd1;

        A_DONE: begin
            ram_busy <= 1'b0;
            if (!ram_req) state <= A_IDLE;
        end

        default: state <= A_IDLE;

        endcase
    end
end

endmodule
