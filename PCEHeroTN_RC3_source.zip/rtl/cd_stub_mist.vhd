-- cd_stub_mist.vhd -- PCEHeroTN
--
-- An empty `cd` entity with the port list of cd.vhd in mist-devel/TurboGrafx16_FPGA.
-- The HuCard build sets WITH_CD = 0, so it is never elaborated, but the
-- core's direct `entity work.cd` instantiation still needs an entity to bind
-- to. A CD build would use the real cd.vhd instead.

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity cd is
	generic(
		CDDA_O_WIDTH : integer := 16
	);
	port(
		RST_N			: in  std_logic;
		CLK 			: in  std_logic;
		EN 			: in  std_logic;

		EXT_A 		: in  std_logic_vector(20 downto 0);
		EXT_DI 		: in  std_logic_vector(7 downto 0);
		EXT_DO 		: out std_logic_vector(7 downto 0);
		EXT_WR_N		: in  std_logic;
		EXT_RD_N		: in  std_logic;
		CPU_CE		: in  std_logic;

		ADRAM_A		: out std_logic_vector(16 downto 0);
		ADRAM_DI	: out std_logic_vector(3 downto 0);
		ADRAM_DO	: in  std_logic_vector(3 downto 0);
		ADRAM_WE	: out std_logic;
		ADRAM_RD  : out std_logic;
		ADRAM_CLKEN : out std_logic;

		SEL_N			: out std_logic;
		IRQ_N			: out std_logic;

		RAM_CS_N		: out std_logic;
		BRAM_EN		: out std_logic;

		CD_STAT		: in std_logic_vector(7 downto 0);
		CD_MSG		: in std_logic_vector(7 downto 0);
		CD_STAT_GET	: in std_logic;

		CD_COMM		: out std_logic_vector(95 downto 0);
		CD_COMM_SEND: out std_logic;

		CD_DOUT_REQ	: in std_logic;
		CD_DOUT		: out std_logic_vector(79 downto 0);
		CD_DOUT_SEND: out std_logic;

		CD_REGION   : in  std_logic;
		CD_RESET		: out std_logic;

		CD_DATA		: in std_logic_vector(7 downto 0);
		CD_WR			: in std_logic;
		CD_DATA_END	: out std_logic;
		CD_FIFO_HALFFULL: out std_logic;

		DM				: in std_logic;

		CD_SL			: out signed(CDDA_O_WIDTH-1 downto 0);
		CD_SR			: out signed(CDDA_O_WIDTH-1 downto 0);
		AD_S			: out signed(15 downto 0)
	);
end cd;
architecture stub of cd is
begin
	EXT_DO           <= (others => '0');
	ADRAM_A          <= (others => '0');
	ADRAM_DI         <= (others => '0');
	ADRAM_WE         <= '0';
	ADRAM_RD         <= '0';
	ADRAM_CLKEN      <= '0';
	SEL_N            <= '1';
	IRQ_N            <= '1';
	RAM_CS_N         <= '1';
	BRAM_EN          <= '0';
	CD_COMM          <= (others => '0');
	CD_COMM_SEND     <= '0';
	CD_DOUT          <= (others => '0');
	CD_DOUT_SEND     <= '0';
	CD_RESET         <= '0';
	CD_DATA_END      <= '0';
	CD_FIFO_HALFFULL <= '0';
	CD_SL            <= (others => '0');
	CD_SR            <= (others => '0');
	AD_S             <= (others => '0');
end architecture;
