// rom_loader.v -- PCEHeroTN
//
// Puts the HuCard ROM in SDRAM, then serves the CPU's ROM reads from it.
//
//   LOADING  copy the ROM out of the Tang's SPI flash into SDRAM, with the
//            core held in reset. (Skipped when SKIP_FLASH_COPY=1: the ROM
//            then comes from the SD card loader instead.)
//   RUNNING  answer ROM_RD from an 8-byte line cache, with a second line
//            read ahead in the background.
//
// ROM_RDY drives the CPU's WAIT_N, so a miss simply stalls the CPU until the
// data arrives. Most CPU reads are sequential and hit the cached line, so few
// of them wait for SDRAM at all.

module rom_loader #(
    // Where the ROM sits in the Tang's flash, clear of the bitstream.
    parameter [23:0] FLASH_BASE = 24'h400000,
    parameter [23:0] ROM_BYTES  = 24'h040000,
    parameter [22:0] SDRAM_BASE = 23'h000000,  // bank 0

    // First byte of the expected ROM image, checked by rom_ok and sdram_ok.
    parameter [7:0]  FIRST_BYTE = 8'h62,

    // 1 = write the ROM as 16-bit words (even byte + odd byte, both byte lanes
    // enabled), as the MiST and MiSTer SDRAM loaders do. 0 = one byte per write.
    parameter        WORD_WRITE = 0,

    // 1 = never read the flash; go straight to RUNNING once SDRAM is ready and
    // let the SD loader supply the ROM.
    parameter        SKIP_FLASH_COPY = 0
) (
    input  wire        clk,
    input  wire        rstn,

    // SDRAM init finished. The copy must wait for it: before init the controller
    // acknowledges writes and drops them.
    input  wire        mem_ready,

    output wire        mspi_sclk,
    output wire        mspi_cs,
    output wire        mspi_mosi,
    input  wire        mspi_miso,

    output reg  [22:0] ram_addr,
    output reg  [7:0]  ram_din,
    // WORD_WRITE data, and the flag that asks for a full-word write.
    output reg  [15:0] ram_din16,
    output reg         ram_wword,
    output reg         ram_req,
    output reg         ram_write,
    input  wire [7:0]  ram_dout,
    input  wire [31:0] ram_dout_w,
    input  wire [31:0] ram_dout_w2,  // second word of a 2-beat burst (the line's upper 4 bytes)
    input  wire        ram_busy,

    input  wire [21:0] rom_a,
    input  wire        rom_rd,

    // Unused; kept so the port list matches pce_top's ROM_CLKEN. Gating fetches
    // on it deadlocks: it comes from CPU_CE, which stops while ROM_RDY is low.
    input  wire        rom_clken,
    output wire [7:0]  rom_do,
    output wire        rom_rdy,

    // Pulse after the SD loader has written a new ROM. Drops the cached lines
    // only; it does not restart the flash copy.
    input  wire        cache_invalidate,

    // The cached line covers rom_a. rom_rdy alone is not enough to know rom_do
    // belongs to rom_a: it is also high when no read is outstanding.
    output wire        rom_hit,

    output reg         loading,  // high until the ROM is in SDRAM; holds the core in reset

    // Flash returned the expected first byte. Without this check, a dead SPI bus
    // copies 0x00 or 0xFF and looks exactly like a working loader.
    output reg         rom_ok,

    // Address 0 read back from SDRAM after the copy matched.
    output reg         sdram_ok
);

wire [7:0]  fl_dout;
wire        fl_valid, fl_busy, fl_done;
wire [23:0] fl_index;
reg         fl_start;

// Declared before the flash_reader instance: Gowin rejects a forward
// reference to a localparam (EX3884).
localparam S_START   = 3'd0;
localparam S_COPY    = 3'd1;
localparam S_WRITE   = 3'd2;
localparam S_WRDONE  = 3'd3;
localparam S_RUN     = 3'd4;
localparam S_FETCH   = 3'd5;
localparam S_FETCHED = 3'd6;
localparam S_VERIFY  = 3'd7;
localparam S_PREFETCH  = 4'd8;
localparam S_PREFETCHED = 4'd9;

reg [3:0] state;

// hold pauses the reader while a byte is being written, so no byte is
// dropped. The MiST and MiSTer loaders flow-control their download the same way.
flash_reader reader (
    .clk        (clk),
    .rstn       (rstn),
    .sclk       (mspi_sclk),
    .cs_n       (mspi_cs),
    .mosi       (mspi_mosi),
    .miso       (mspi_miso),
    .start      (fl_start),
    .hold       (state != S_COPY),
    .base_addr  (FLASH_BASE),
    .length     (ROM_BYTES),
    .dout       (fl_dout),
    .dout_valid (fl_valid),
    .dout_index (fl_index),
    .busy       (fl_busy),
    .done       (fl_done)
);

reg [7:0] hold_byte;
reg [7:0] hold_lo;
reg [15:0] hold_word;
reg [22:0] hold_addr;
reg       verified;

// A demand fetch is in flight.
reg        fetching;

// One-line ROM cache: an 8-byte line, read from SDRAM as a 2-beat burst of
// 32-bit words. The ROM is read-only after loading, so it never needs to be
// written back.
reg [63:0] line_data;
reg [18:0] line_tag;
reg        line_valid;

wire line_hit = line_valid && (rom_a[21:3] == line_tag);

// Read-ahead: while the CPU hits line_data, fetch the next line into pf_data.
// Crossing into it is then free. A prefetch never lowers rom_rdy. A demand miss
// that arrives during a prefetch waits for it to finish (one extra SDRAM round
// trip at most).
localparam ENABLE_PREFETCH = 1;

reg [63:0] pf_data;
reg [18:0] pf_tag;
reg        pf_valid;
reg        prefetching;

wire pf_hit = ENABLE_PREFETCH && pf_valid && (rom_a[21:3] == pf_tag);

always @(posedge clk or negedge rstn) begin
    if (!rstn) begin
        state     <= S_START;
        loading   <= 1'b1;
        fl_start  <= 1'b0;
        ram_req   <= 1'b0;
        ram_write <= 1'b0;
        ram_addr  <= 23'd0;
        ram_din   <= 8'd0;
        ram_din16 <= 16'd0;
        ram_wword <= 1'b0;
        hold_lo   <= 8'd0;
        hold_word <= 16'd0;
        line_valid <= 1'b0;
        line_tag   <= 19'd0;
        line_data  <= 64'd0;
        pf_valid    <= 1'b0;
        pf_tag      <= 19'd0;
        pf_data     <= 64'd0;
        prefetching <= 1'b0;
        fetching   <= 1'b0;
        rom_ok    <= 1'b0;
        sdram_ok  <= 1'b0;
        verified  <= 1'b0;
    end else begin
        case (state)

        S_START: begin
            // fl_start is held until flash_reader reports busy: a one-cycle start
            // can be missed.
            if (SKIP_FLASH_COPY) begin
                if (mem_ready) begin
                    loading <= 1'b0;
                    state   <= S_RUN;
                end
            end else if (mem_ready) fl_start <= 1'b1;
            if (!SKIP_FLASH_COPY && fl_busy) begin
                fl_start <= 1'b0;
                state    <= S_COPY;
            end
        end

        S_COPY: begin
            if (fl_valid) begin
                hold_byte <= fl_dout;
                // Hold the even byte; on its odd partner write both as one word.
                // ROM_BYTES is even, so no byte is left over.
                if (WORD_WRITE) begin
                    if (!fl_index[0]) begin
                        hold_lo <= fl_dout;
                    end else begin
                        hold_addr <= SDRAM_BASE + {fl_index[22:1], 1'b0};
                        hold_word <= {fl_dout, hold_lo};
                        state     <= S_WRITE;
                    end
                end else begin
                    hold_addr <= SDRAM_BASE + fl_index[22:0];
                    state     <= S_WRITE;
                end
                // Prove the flash is really being read, not just clocked.
                if (fl_index == 24'd0 && fl_dout == FIRST_BYTE)
                    rom_ok <= 1'b1;
            end else if (fl_done) begin  // Read address 0 back before releasing the core.
                ram_addr  <= SDRAM_BASE;
                ram_write <= 1'b0;
                ram_wword <= 1'b0;
                ram_req   <= 1'b1;
                state     <= S_VERIFY;
            end
        end

        S_WRITE: begin
            ram_addr  <= hold_addr;
            ram_din   <= hold_byte;
            ram_din16 <= hold_word;
            ram_wword <= WORD_WRITE[0];
            ram_write <= 1'b1;
            ram_req   <= 1'b1;
            if (ram_busy) state <= S_WRDONE;
        end

        S_WRDONE: begin
            ram_req <= 1'b0;
            // The controller only goes idle once ram_req drops.
            if (!ram_busy) state <= S_COPY;
        end

        S_VERIFY: begin
            if (ram_busy) ram_req <= 1'b0;
            else if (!ram_req) begin
                if (ram_dout == FIRST_BYTE) sdram_ok <= 1'b1;
                verified <= 1'b1;
                loading  <= 1'b0;  // release the core either way
                state    <= S_RUN;
            end
        end

        S_RUN: begin
            ram_write <= 1'b0;
            ram_wword <= 1'b0;
            // rom_clken is not required here: see the rom_clken port. rom_rd is a level
            // held for many clk_sys cycles, but the FSM leaves S_RUN on the first one,
            // so it cannot trigger twice.
            if (rom_rd && !line_hit) begin
                if (pf_hit) begin
                    // The line the CPU just crossed into is already in the read-ahead buffer.
                    line_data  <= pf_data;
                    line_tag   <= pf_tag;
                    line_valid <= 1'b1;
                    pf_valid   <= 1'b0;
                end else begin
                    ram_addr <= SDRAM_BASE + {1'b0, rom_a[21:3], 3'b000};
                    ram_req  <= 1'b1;
                    fetching <= 1'b1;
                    state    <= S_FETCH;
                end
            end else if (ENABLE_PREFETCH && rom_rd && line_hit && !pf_valid && !prefetching) begin
                // rom_rd is required: ROM_A follows CPU_A on every cycle, ROM read or not, so
                // without it a RAM or I/O cycle could start a prefetch.
                ram_addr    <= SDRAM_BASE + {1'b0, (line_tag + 19'd1), 3'b000};
                pf_tag      <= line_tag + 19'd1;
                ram_req     <= 1'b1;
                prefetching <= 1'b1;
                state       <= S_PREFETCH;
            end
        end

        S_FETCH: if (ram_busy) state <= S_FETCHED;

        S_FETCHED: begin
            ram_req <= 1'b0;
            if (!ram_busy) begin
                line_data  <= {ram_dout_w2, ram_dout_w};  // {second word, first word}
                line_tag   <= ram_addr[21:3] - SDRAM_BASE[21:3];
                line_valid <= 1'b1;
                fetching   <= 1'b0;
                state     <= S_RUN;
            end
        end

        S_PREFETCH: if (ram_busy) state <= S_PREFETCHED;

        S_PREFETCHED: begin
            ram_req <= 1'b0;
            if (!ram_busy) begin
                pf_data     <= {ram_dout_w2, ram_dout_w};
                pf_valid    <= 1'b1;
                prefetching <= 1'b0;
                state       <= S_RUN;
            end
        end

        default: state <= S_START;

        endcase

        // After the case, so an invalidate always wins over a fill in the same cycle.
        if (cache_invalidate) begin
            line_valid <= 1'b0;
            pf_valid   <= 1'b0;
        end
    end
end

// Ready means the byte on rom_do belongs to rom_a. It stays high while no read
// is outstanding: HUC6280 only advances while WAIT_N (= ROM_RDY) is high, so a
// ready that dropped whenever the line missed, read or not, would freeze the
// CPU before it could ask for anything. It drops only on a real miss.
// Advertising ready during a miss let the CPU latch the previous line's byte,
// which showed up as boots that failed on some power-ups and not others.
assign rom_rdy = ~loading & ~fetching & (~rom_rd | line_hit);
assign rom_hit = line_hit;

// Byte A sits in lane A[1:0] of its word; the burst's second word holds
// bytes 4-7.
assign rom_do = (rom_a[2:0] == 3'd0) ? line_data[7:0]   :
                (rom_a[2:0] == 3'd1) ? line_data[15:8]  :
                (rom_a[2:0] == 3'd2) ? line_data[23:16] :
                (rom_a[2:0] == 3'd3) ? line_data[31:24] :
                (rom_a[2:0] == 3'd4) ? line_data[39:32] :
                (rom_a[2:0] == 3'd5) ? line_data[47:40] :
                (rom_a[2:0] == 3'd6) ? line_data[55:48] :
                                       line_data[63:56];

endmodule
