// flash_reader.v -- PCEHeroTN
//
// Streams bytes out of the Tang's SPI boot flash: one 0x03 READ command, then
// bytes for as long as CS stays low. Two clocks per SPI bit, about 20 clocks
// per byte with the handshake, so 256 KB takes about 0.12 s at 43.2 MHz.
//
// Used to copy a ROM written with `openFPGALoader --external-flash` into
// SDRAM at start-up.

module flash_reader (
    input  wire        clk,
    input  wire        rstn,

    output reg         sclk,
    output reg         cs_n,
    output reg         mosi,
    input  wire        miso,

    // Hold start high until busy rises.
    input  wire        start,

    // Raise while the consumer cannot take a byte. The transfer in flight
    // finishes and is presented, then the reader waits.
    input  wire        hold,
    input  wire [23:0] base_addr,
    input  wire [23:0] length,

    // One pulse per byte, with the byte and its index.
    output reg  [7:0]  dout,
    output reg         dout_valid,
    output reg  [23:0] dout_index,

    output reg         busy,
    output reg         done
);

localparam CMD_READ = 8'h03;

// Byte-level SPI, mode 0: MOSI changes on the falling edge, MISO is sampled
// on the rising edge.
reg        xfer_req;
reg [7:0]  xfer_tx;
reg [7:0]  xfer_rx;
reg        xfer_ack;
reg [3:0]  bitcnt;
reg [7:0]  shreg;
reg        phase;
reg        xfer_active;

always @(posedge clk or negedge rstn) begin
    if (!rstn) begin
        sclk <= 1'b0; mosi <= 1'b0; xfer_active <= 1'b0; xfer_ack <= 1'b0;
        bitcnt <= 4'd0; shreg <= 8'd0; phase <= 1'b0; xfer_rx <= 8'd0;
    end else begin
        xfer_ack <= 1'b0;
        if (!xfer_active) begin
            sclk <= 1'b0;
            if (xfer_req) begin
                shreg <= xfer_tx; bitcnt <= 4'd8; phase <= 1'b0;
                xfer_active <= 1'b1; mosi <= xfer_tx[7];
            end
        end else if (!phase) begin
            sclk  <= 1'b1;
            shreg <= { shreg[6:0], miso };
            phase <= 1'b1;
        end else begin
            sclk   <= 1'b0;
            phase  <= 1'b0;
            bitcnt <= bitcnt - 4'd1;
            if (bitcnt == 4'd1) begin
                xfer_active <= 1'b0;
                xfer_rx     <= shreg;
                xfer_ack    <= 1'b1;
            end else
                // shreg was shifted on the rising edge, so the next bit is bit 7, not bit 6.
                mosi <= shreg[7];
        end
    end
end

localparam S_IDLE  = 3'd0;
localparam S_GAP   = 3'd1;
localparam S_CMD   = 3'd2;
localparam S_ADDR  = 3'd3;
localparam S_DATA  = 3'd4;
localparam S_DONE  = 3'd5;
localparam S_HOLD  = 3'd6;  // byte delivered, let `hold` settle
localparam S_HOLD2 = 3'd7;  // now sample it

reg [2:0]  state;
reg [1:0]  sub;
reg [23:0] cur;
reg [23:0] remaining;
reg [7:0]  gap;

// The index of the byte being presented. dout_valid and dout_index are both
// registered, so a counter bumped in the same cycle would label byte N as N+1.
reg [23:0] idx;

wire [7:0] addr_byte = (sub == 2'd0) ? cur[23:16] :
                       (sub == 2'd1) ? cur[15:8]  : cur[7:0];

always @(posedge clk or negedge rstn) begin
    if (!rstn) begin
        state <= S_IDLE; cs_n <= 1'b1; xfer_req <= 1'b0;
        busy <= 1'b0; done <= 1'b0; dout_valid <= 1'b0;
        cur <= 24'd0; remaining <= 24'd0; sub <= 2'd0; gap <= 8'd0; idx <= 24'd0;
        dout <= 8'd0; dout_index <= 24'd0;
    end else begin
        xfer_req   <= 1'b0;
        dout_valid <= 1'b0;

        case (state)

        S_IDLE: begin
            cs_n <= 1'b1;
            if (start) begin
                busy       <= 1'b1;
                cur        <= base_addr;
                remaining  <= length;
                idx        <= 24'd0;
                dout_index <= 24'd0;
                gap        <= 8'd0;
                state      <= S_GAP;
            end
        end

        // CS-high gap before the command: 8 clocks against a 30-50 ns minimum.
        S_GAP: begin
            cs_n <= 1'b1;
            if (gap == 8'd8) begin
                gap      <= 8'd0;
                cs_n     <= 1'b0;
                xfer_tx  <= CMD_READ;
                xfer_req <= 1'b1;
                sub      <= 2'd0;
                state    <= S_CMD;
            end else
                gap <= gap + 8'd1;
        end

        S_CMD: if (xfer_ack) begin
            xfer_tx  <= addr_byte;
            xfer_req <= 1'b1;
            sub      <= sub + 2'd1;
            state    <= S_ADDR;
        end

        S_ADDR: if (xfer_ack) begin
            // After the 3 address bytes, data streams with no per-byte command.
            if (sub == 2'd3) begin
                xfer_tx  <= 8'h00;
                xfer_req <= 1'b1;
                state    <= S_DATA;
            end else begin
                xfer_tx  <= addr_byte;
                xfer_req <= 1'b1;
                sub      <= sub + 2'd1;
            end
        end

        S_DATA: if (xfer_ack) begin
            dout       <= xfer_rx;
            dout_valid <= 1'b1;
            dout_index <= idx;
            idx        <= idx + 24'd1;

            if (remaining <= 24'd1) begin
                cs_n  <= 1'b1;
                busy  <= 1'b0;
                done  <= 1'b1;
                state <= S_DONE;
            end else begin
                remaining <= remaining - 24'd1;
                state     <= S_HOLD;
            end
        end

        // One settle cycle before sampling hold. The consumer only raises hold on
        // the clock after a byte is delivered; sampling at once would start the next
        // transfer and that byte would be lost.
        S_HOLD: state <= S_HOLD2;

        S_HOLD2: if (!hold) begin
            xfer_tx  <= 8'h00;
            xfer_req <= 1'b1;
            state    <= S_DATA;
        end

        S_DONE: cs_n <= 1'b1;

        default: state <= S_IDLE;

        endcase
    end
end

endmodule
