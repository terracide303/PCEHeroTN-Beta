// rom_sdc_loader.v -- PCEHeroTN
//
// The SD card engine. One sd_reader (WonderTANG, SPI mode) is shared by two
// clients:
//
//   1. The core's own game load: once a file is picked in the OSD, read it
//      sector by sector and write each byte into SDRAM.
//   2. The companion MCU's raw sector reads, which its own file system uses
//      to browse folders (FPGA-Companion's sdc_read_sector()).
//
// MCU reads take priority; an interactive browse should not wait behind a
// game load. The same arrangement as NanoMig's src/misc/sd_card.v, with one
// core client instead of eight.
//
// Clocks: the companion side runs on clk_pixel, the SD engine and SDRAM side
// on clk_sys. Single-cycle requests cross as toggles (2-flop resync plus edge
// detect). The sector buffer crosses as a dual-clock RAM (sdc_mcu_buffer).
//
// The last sector of a file is always written in full, so up to 511 bytes
// past the end of the ROM are written in SDRAM. Nothing may be kept there.

module rom_sdc_loader #(
    parameter [22:0] SDRAM_BASE  = 23'h000000,
    parameter [2:0]  SD_CLK_DIV  = 3'd2,  // clk is 25-50 MHz
    // Shrinks sd_reader's power-up waits for simulation. Must be 0 on hardware:
    // a real card needs the full SD power-up sequence.
    parameter        SD_SIMULATE = 0,

    // Debug: a non-zero value caps how many sectors a load reads. 0 = normal.
    parameter [15:0] DIAGNOSTIC_MAX_SECTORS = 16'd0
) (
    input  wire        clk,
    input  wire        rstn,

    input  wire        mcu_clk,  // clk_pixel

    // SPI mode: only sclk, cmd and dat0 are used
    output wire        sd_sclk,
    inout               sd_cmd,
    inout               sd_dat0,
    // Held high to keep the card out of 4-bit SD bus mode.
    output wire         sd_dat1,
    output wire         sd_dat2,
    output wire         sd_dat3,

    // From sdc.v, clk_pixel domain.
    input  wire         mcu_direct_strobe,
    input  wire [31:0]  mcu_direct_start_sector,
    input  wire         mcu_inserted_strobe,
    input  wire [31:0]  mcu_inserted_size,

    // From sdc_mcu_read.v, clk_pixel domain.
    input  wire         mcu_read_req_toggle,
    input  wire [31:0]  mcu_read_sector,
    output reg          mcu_read_ready_toggle,
    input  wire [8:0]   mcu_buf_addr,  // sdc_mcu_buffer port A, clk_pixel
    output wire [7:0]   mcu_buf_dout,

    // Game bytes to SDRAM: held until acked (see sdc_write_bridge).
    output reg          sdc_want_write,
    output reg  [22:0]  sdc_write_addr,
    output reg  [7:0]   sdc_write_din,
    input  wire         sdc_write_ack,

    output wire         loading,  // a file is being read
    output wire         load_done,  // one-cycle pulse: file fully written
    output wire         ejected,  // one-cycle pulse: OSD picked 'No game' (size 0)
    output wire [15:0]  sectors_total,
    output wire [15:0]  sector_idx_out,
    // sectors_total minus a skipped copier header
    output wire [15:0]  rom_sectors,
    output wire         header_skipped,
    output wire  [3:0]  sd_card_stat,
    output wire  [1:0]  sd_card_type,  // 0=unknown 1=SDv1 2=SDv2 3=SDHCv2

    // The companion will not browse until its status reads (s & 0xF0) == 0x80. That is
    // true once the engine leaves E_INIT, which happens only once per reset.
    output wire         sd_card_ready,

    // CORE_RW: ask the MCU which physical sector holds logical sector N of the
    // open file. The request is a held level; the reply comes back as a toggle.
    output reg          core_rw_want,
    output reg [31:0]   core_rw_lsector,
    input  wire         core_rw_reply_toggle,
    input  wire [31:0]  core_rw_reply_psector,
    output wire         core_rw_local_busy
);

// clk_pixel -> clk_sys pulses: toggle in the source domain, resync and
// edge-detect here. The data that goes with each pulse (sector numbers,
// file size) is written once and then held, so it is stable long before the
// resynced pulse arrives and needs no synchroniser of its own.
reg direct_toggle_mcu = 1'b0, inserted_toggle_mcu = 1'b0;
always @(posedge mcu_clk) begin
    if (mcu_direct_strobe)   direct_toggle_mcu   <= ~direct_toggle_mcu;
    if (mcu_inserted_strobe) inserted_toggle_mcu <= ~inserted_toggle_mcu;
end

reg [2:0] direct_sync   = 3'b000;
reg [2:0] inserted_sync = 3'b000;
reg [2:0] mcu_read_req_sync = 3'b000;
reg [2:0] core_rw_reply_sync = 3'b000;
always @(posedge clk) begin
    direct_sync        <= {direct_sync[1:0],        direct_toggle_mcu};
    inserted_sync       <= {inserted_sync[1:0],       inserted_toggle_mcu};
    mcu_read_req_sync   <= {mcu_read_req_sync[1:0],   mcu_read_req_toggle};
    core_rw_reply_sync  <= {core_rw_reply_sync[1:0],  core_rw_reply_toggle};
end
wire core_rw_reply_pulse = core_rw_reply_sync[2] ^ core_rw_reply_sync[1];
// DIRECT: the MCU sends a start sector only when the file is in one
// contiguous run on the card. Used as a fast path; CORE_RW is the fallback.
wire direct_pulse       = direct_sync[2]       ^ direct_sync[1];
wire inserted_pulse     = inserted_sync[2]     ^ inserted_sync[1];
wire mcu_read_req_pulse = mcu_read_req_sync[2] ^ mcu_read_req_sync[1];

reg [31:0] file_size = 32'd0;
always @(posedge clk) if (inserted_pulse) file_size <= mcu_inserted_size;

// Size 0 is the OSD's 'No game'; the top unloads the card on it.
assign ejected = inserted_pulse && (mcu_inserted_size == 32'd0);

wire        rd_busy, rd_done;
wire        outen;
wire [8:0]  outaddr;
wire [7:0]  outbyte;
reg         rstart;
reg  [31:0] rsector;

// Shared by both clients. Only the arbiter below drives rstart/rsector.
sd_reader #(
    .CLK_DIV (SD_CLK_DIV),
    .SIMULATE(SD_SIMULATE)
) sd_reader_inst (
    .rstn         (rstn),
    .clk          (clk),
    .sdclk        (sd_sclk),
    .sdcmd        (sd_cmd),
    .sddat0       (sd_dat0),
    .card_stat    (sd_card_stat),
    .card_type    (sd_card_type),
    .rstart       (rstart),
    .rsector      (rsector),
    .rbusy        (rd_busy),
    .rdone        (rd_done),
    .outen        (outen),
    .outaddr      (outaddr),
    .outbyte      (outbyte),
    .wstart       (1'b0),
    .inbyte       (8'h00),
    .c_size       (),
    .c_size_mult  (),
    .read_bl_len  (),
    .mid          (),
    .oid          (),
    .pnm          (),
    .psn          (),
    .crc_error    (),
    .timeout_error(),
    .init         (1'b1)
);

assign sd_dat1 = 1'b1;
assign sd_dat2 = 1'b1;
assign sd_dat3 = 1'b1;

reg        mcu_buf_we_b;
reg [8:0]  mcu_buf_addr_b;
reg [7:0]  mcu_buf_din_b;

sdc_mcu_buffer sdc_mcu_buffer_inst (
    .clk_a  (mcu_clk),
    .addr_a (mcu_buf_addr),
    .din_a  (8'd0),
    .we_a   (1'b0),
    .dout_a (mcu_buf_dout),

    .clk_b  (clk),
    .addr_b (mcu_buf_addr_b),
    .din_b  (mcu_buf_din_b),
    .we_b   (mcu_buf_we_b),
    .dout_b ()
);

// Arbiter. E_INIT waits out the card's power-up: sd_reader ignores rstart
// until it is idle, and the end of init would otherwise look like the end of
// a read that was never started.
localparam E_INIT       = 3'd0;
localparam E_IDLE       = 3'd1;
localparam E_MCU_START  = 3'd2;
localparam E_MCU_WAIT   = 3'd3;
localparam E_CORE_START = 3'd4;
localparam E_CORE_WAIT  = 3'd5;

reg [2:0]  engine_state = E_INIT;
reg        mcu_read_pending = 1'b0;
reg [31:0] mcu_read_sector_r;
reg        core_req_pending = 1'b0;
reg [31:0] core_req_sector;
reg        core_req_done_r;

always @(posedge clk) begin
    rstart          <= 1'b0;
    core_req_done_r <= 1'b0;
    mcu_buf_we_b    <= 1'b0;

    if (!rstn) begin
        engine_state          <= E_INIT;
        mcu_read_pending      <= 1'b0;
        mcu_read_ready_toggle <= 1'b0;
    end else begin
        // Latch MCU requests in any state, so one arriving mid-core-read is kept.
        if (mcu_read_req_pulse) begin
            mcu_read_pending  <= 1'b1;
            mcu_read_sector_r <= mcu_read_sector;
        end

        // While the MCU owns the engine, its bytes go to the sector buffer.
        if ((engine_state == E_MCU_START || engine_state == E_MCU_WAIT) && outen) begin
            mcu_buf_we_b   <= 1'b1;
            mcu_buf_addr_b <= outaddr;
            mcu_buf_din_b  <= outbyte;
        end

        case (engine_state)
            E_INIT: if (!rd_busy) engine_state <= E_IDLE;

            E_IDLE: begin
                if (mcu_read_pending) begin
                    rsector      <= mcu_read_sector_r;
                    engine_state <= E_MCU_START;
                end else if (core_req_pending && !core_req_done_r) begin
                    rsector      <= core_req_sector;
                    engine_state <= E_CORE_START;
                end
            end

            E_MCU_START: begin
                rstart <= 1'b1;
                if (rd_busy) engine_state <= E_MCU_WAIT;
            end

            E_MCU_WAIT: if (!rd_busy) begin
                mcu_read_pending      <= 1'b0;
                mcu_read_ready_toggle <= ~mcu_read_ready_toggle;
                engine_state          <= E_IDLE;
            end

            E_CORE_START: begin
                rstart <= 1'b1;
                if (rd_busy) engine_state <= E_CORE_WAIT;
            end

            E_CORE_WAIT: if (!rd_busy) begin
                core_req_done_r <= 1'b1;
                engine_state    <= E_IDLE;
            end

            default: engine_state <= E_IDLE;
        endcase
    end
end

// Core sequencer: wait for card init and a file selection, then walk the
// file's logical sectors. Each is resolved to a physical sector (DIRECT if
// known, otherwise CORE_RW) and then read through the arbiter.
localparam S_INIT   = 3'd0;
localparam S_IDLE   = 3'd1;
localparam S_RW_REQ = 3'd2;
localparam S_REQ    = 3'd3;
localparam S_NEXT   = 3'd4;

reg [2:0]  state = S_INIT;
reg [15:0] sectors_total_r;
reg [15:0] sector_idx;
reg [22:0] sector_base_addr;
reg        load_done_r;
reg        hdr_r = 1'b0;

// The MCU can announce a file before the card has finished its power-up,
// so the selection is latched rather than acted on only in S_IDLE.
reg        req_pending = 1'b0;
reg [31:0] req_file_size;

always @(posedge clk) begin
    if (!rstn) begin
        req_pending <= 1'b0;
    end else if (inserted_pulse && (mcu_inserted_size != 32'd0)) begin
        req_pending   <= 1'b1;
        req_file_size <= mcu_inserted_size;
    end else if (state == S_IDLE && req_pending) begin
        req_pending <= 1'b0;
    end
end

// DIRECT arrives after INSERTED for the same file, possibly while a CORE_RW
// request is already out, so it is latched and checked every cycle in S_RW_REQ.
// If both land in one cycle, the set below is the later assignment and wins.
reg        direct_valid = 1'b0;
reg [31:0] direct_start_sector;
always @(posedge clk) begin
    if (!rstn) begin
        direct_valid <= 1'b0;
    end else begin
        if (inserted_pulse) direct_valid <= 1'b0;
        if (direct_pulse && (mcu_direct_start_sector != 32'd0)) begin
            direct_start_sector <= mcu_direct_start_sector;
            direct_valid        <= 1'b1;
        end
    end
end

always @(posedge clk) begin
    load_done_r <= 1'b0;

    if (!rstn) begin
        state            <= S_INIT;
        core_req_pending <= 1'b0;
        core_rw_want     <= 1'b0;
    end else begin
        case (state)
            S_INIT: if (!rd_busy) state <= S_IDLE;

            S_IDLE: if (req_pending) begin
                if (DIAGNOSTIC_MAX_SECTORS != 16'd0 &&
                    DIAGNOSTIC_MAX_SECTORS < ((req_file_size[31:9]) + (|req_file_size[8:0])))
                    sectors_total_r <= DIAGNOSTIC_MAX_SECTORS;
                else
                    sectors_total_r <= (req_file_size[31:9]) + (|req_file_size[8:0]);
                // A 512-byte copier header shows as file size bit 9, as MiSTer detects it.
                // The header is exactly one sector, so it is skipped by starting at sector 1.
                hdr_r            <= req_file_size[9];
                sector_idx       <= {15'd0, req_file_size[9]};
                sector_base_addr <= SDRAM_BASE;
                state            <= S_RW_REQ;
            end

            S_RW_REQ: begin
                if (direct_valid) begin
                    core_rw_want    <= 1'b0;
                    core_req_sector <= direct_start_sector + {16'd0, sector_idx};
                    state           <= S_REQ;
                end else begin
                    core_rw_want    <= 1'b1;
                    core_rw_lsector <= {16'd0, sector_idx};
                    if (core_rw_reply_pulse) begin
                        core_req_sector <= core_rw_reply_psector;
                        core_rw_want    <= 1'b0;
                        state           <= S_REQ;
                    end
                end
            end

            S_REQ: begin
                if (!core_req_pending) begin
                    core_req_pending <= 1'b1;
                end else if (core_req_done_r) begin
                    core_req_pending <= 1'b0;
                    state            <= S_NEXT;
                end
            end

            S_NEXT: begin
                if (sector_idx + 16'd1 >= sectors_total_r) begin
                    load_done_r <= 1'b1;
                    state       <= S_IDLE;
                end else begin
                    sector_idx       <= sector_idx + 16'd1;
                    sector_base_addr <= sector_base_addr + 23'd512;
                    state            <= S_RW_REQ;
                end
            end

            default: state <= S_INIT;
        endcase
    end
end

assign loading        = (state != S_INIT) && (state != S_IDLE);
assign load_done       = load_done_r;
assign sectors_total   = sectors_total_r;
assign sector_idx_out   = sector_idx;
assign rom_sectors      = sectors_total_r - {15'd0, hdr_r};
assign header_skipped   = hdr_r;
assign sd_card_ready   = (engine_state != E_INIT);

// Busy for the whole round trip, from the CORE_RW ask to the end of the local
// read. The MCU polls busy in the same SPI transaction that delivers the
// answer, so busy must already be set when the request goes out.
assign core_rw_local_busy = (state == S_RW_REQ) || (state == S_REQ);

// SDRAM write-catcher: one SDRAM write per byte from the SD engine while the
// core owns it. A byte takes 8 SD clocks, dozens of clk_sys cycles, which
// leaves time for the write handshake without a FIFO.
localparam W_IDLE = 1'd0;
localparam W_REQ  = 1'd1;

reg        w_state = W_IDLE;

wire core_owns_engine = (engine_state == E_CORE_START) || (engine_state == E_CORE_WAIT);

always @(posedge clk) begin
    if (!rstn) begin
        w_state        <= W_IDLE;
        sdc_want_write <= 1'b0;
    end else begin
        case (w_state)
            W_IDLE: if (outen && core_owns_engine) begin
                sdc_write_addr <= sector_base_addr + {14'd0, outaddr};
                sdc_write_din  <= outbyte;
                sdc_want_write <= 1'b1;
                w_state        <= W_REQ;
            end

            W_REQ: if (sdc_write_ack) begin
                sdc_want_write <= 1'b0;
                w_state        <= W_IDLE;
            end

            default: w_state <= W_IDLE;
        endcase
    end
end

endmodule
