// sdc_write_bridge.v -- PCEHeroTN
//
// Turns rom_sdc_loader's write request ("hold want until acked") into the
// req/busy handshake that pce_sdram_bank2_client speaks. It drives one
// dedicated SDRAM client port; it is not an arbiter. Keeping SD writes off
// the loader's own ROM bus is what stopped them colliding with ROM reads.
//
`default_nettype none

module sdc_write_bridge (
    input  wire        clk,      // clk_sys, same domain as rom_sdc_loader
    input  wire        rstn,

    // From rom_sdc_loader: held until acked.
    input  wire        sdc_want_write,
    input  wire [22:0] sdc_write_addr,
    input  wire [7:0]  sdc_write_din,
    output reg         sdc_write_ack,

    // To pce_sdram_bank2_client: byte address, req/busy.
    output reg  [22:0] ram_addr,
    output reg  [7:0]  ram_din,
    output reg         ram_req,
    input  wire        ram_busy
);

localparam S_IDLE  = 2'd0,
           S_WRITE  = 2'd1,   // ram_req asserted, waiting for ram_busy
           S_WRDONE = 2'd2;   // ram_req dropped, waiting for !ram_busy

reg [1:0] state;

always @(posedge clk or negedge rstn) begin
    if (!rstn) begin
        state         <= S_IDLE;
        ram_addr      <= 23'd0;
        ram_din       <= 8'd0;
        ram_req       <= 1'b0;
        sdc_write_ack <= 1'b0;
    end else begin
        sdc_write_ack <= 1'b0;

        case (state)
            S_IDLE: if (sdc_want_write) begin
                ram_addr <= sdc_write_addr;
                ram_din  <= sdc_write_din;
                ram_req  <= 1'b1;
                state    <= S_WRITE;
            end

            S_WRITE: if (ram_busy) state <= S_WRDONE;

            S_WRDONE: begin
                ram_req <= 1'b0;
                if (!ram_busy) begin
                    sdc_write_ack <= 1'b1;
                    state         <= S_IDLE;
                end
            end

            default: state <= S_IDLE;
        endcase
    end
end

endmodule
`default_nettype wire
