-- wram_bram.vhd -- PCEHeroTN
--
-- The CPU's 8 KB work RAM in block RAM, the same wrapper as vram_bram.vhd.
--
-- No wait states are needed: the CPU holds address and strobes for its whole
-- memory cycle (at least 6 clk_sys) and this RAM answers in 1. A simulation
-- of a real game boot with this module and no stall read back every byte as
-- last written.

library ieee;
use ieee.std_logic_1164.all;

library work;

entity wram_bram is
    port (
        clk  : in  std_logic;
        addr : in  std_logic_vector(12 downto 0);
        din  : in  std_logic_vector(7 downto 0);
        we   : in  std_logic;
        dout : out std_logic_vector(7 downto 0)
    );
end entity;

architecture rtl of wram_bram is
begin

    u_dpram : entity work.dpram
        generic map (
            addr_width    => 13,
            data_width    => 8,
            mem_init_file => " ",
            disable_value => '0'
        )
        port map (
            clock     => clk,

            address_a => addr,
            data_a    => din,
            enable_a  => '1',
            wren_a    => we,
            q_a       => dout,
            cs_a      => '1',

            address_b => (others => '0'),
            data_b    => (others => '0'),
            enable_b  => '1',
            wren_b    => '0',
            q_b       => open,
            cs_b      => '1'
        );

end architecture;
