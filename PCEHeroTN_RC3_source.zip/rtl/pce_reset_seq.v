// pce_reset_seq.v -- PCEHeroTN
//
// Releases the core after a ROM load. After `loading` drops, a counter steps
// 32768 times on `clear_tick`, and the core stays in reset until it finishes.
// With VRAM in block RAM this pass no longer initialises anything that is
// read back; what it still provides is a few milliseconds of delay before the
// CPU starts.
//
// clear_tick must never depend, even indirectly, on reset_n or
// vram_clearing. If it does, the counter waits for the core, the core waits
// for the counter, and the machine never boots.

`default_nettype none

module pce_reset_seq (
    input  wire        clk_sys,
    input  wire        sys_rst_n,
    input  wire        loading,       // holds the whole sequence at rest during the ROM copy
    input  wire        clear_tick,    // one pulse per counter step; see header
    output wire         vram_clearing,
    output wire         clear_done,    // vclr_cnt[15]: the pass finished
    output wire [15:0]  vclr_cnt_out,  // raw count, used as the VRAM address
                                        // during the pass
    output wire         reset_n
);

reg [15:0] vclr_cnt = 16'd0;   // bit 15 set = done
assign vclr_cnt_out = vclr_cnt;

always @(posedge clk_sys) begin
    if (!sys_rst_n || loading) begin
        vclr_cnt <= 16'd0;               // rerun the clear after any reload
    end else if (!vclr_cnt[15] && !loading && clear_tick) begin
        vclr_cnt <= vclr_cnt + 1'b1;
    end
end

assign clear_done    = vclr_cnt[15];
assign vram_clearing = ~vclr_cnt[15] & ~loading;
assign reset_n        = sys_rst_n & ~loading & ~vram_clearing;

endmodule
