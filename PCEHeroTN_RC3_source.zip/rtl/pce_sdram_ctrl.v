// pce_sdram_ctrl.v -- PCEHeroTN
//
// The first SDRAM controller of this port: NanoMig's sdram.sv (here
// sdram_ungated.sv) with two clients, the VDC's VRAM on the chipset port and
// the CPU/ROM on port 2.
//
// In the shipping build (SDRAM_BANK2=1) pce_sdram_bank2 drives the SDRAM
// chip and the top selects this module's pin outputs away. What this module
// still provides is sync_tick_27m, which paces pce_reset_seq.
//
// sync: NanoMig drives sdram.sv's sync from the Amiga chipset clock enable,
// so memory slots follow the chipset. The analogue here is the VDC's dot
// strobe, video_ce. While video_ce is quiet (the core held in reset) a
// failsafe counter keeps sync running, so nothing waiting on it can stall.
//
// Port 2 runs on clk_sys with its request held for the whole transaction;
// the ack toggle comes back through a 3-flop synchroniser and the data is
// sampled P2_SETTLE clk_sys later. clk_sys and clk_ram come from one PLL.

module pce_sdram_ctrl #(
    parameter SYNC_DELAY = 3,  // sdram.sv starts its cycle SYNC_DELAY-1 clk_ram after sync
    parameter FAILSAFE_CLKRAM = 20,  // free-run sync after this many quiet clk_ram cycles
    parameter UNGATE_CHIPSET = 0  // debug: let the chipset port start outside sync
) (
    input  wire        clk_27m,  // clk_sys (name kept from an older controller)
    input  wire        clk_108m,  // clk_ram
    input  wire        clk_sdram,  // clk_ram_sdram: the chip clock, 270 deg
    input  wire        bus_reset_n,

    input  wire [15:0] ram_din16,
    input  wire        ram_wword,

    input  wire        video_ce,  // VDC dot strobe: the sync source

    // Port 2: byte-addressed CPU/ROM client.
    input  wire [7:0]  ram_din,
    input  wire        ram_req,
    input  wire        ram_write,
    input  wire [22:0] ram_addr,
    output reg  [7:0]  ram_dout,
    output reg  [31:0] ram_dout_w,
    output reg         ram_busy,

    // Chipset port: VRAM.
    input  wire [15:0] vram_din,
    input  wire        vram_write,
    input  wire        vram_rd,
    input  wire [16:0] vram_addr,
    output reg  [15:0] vram_dout,

    input  wire        bus_rfsh_n,  // unused: the controller refreshes itself
    output wire        mem_ready,

    output wire        sync_tick_27m,  // one clk_sys pulse per sync

    // Debug.
    output wire [2:0]  cstate_out,
    output wire        dbg_sync,
    output wire [3:0]  dbg_sdst,
    output wire        dbg_p2ack,

    output wire        O_sdram_clk,
    output wire        O_sdram_cke,
    output wire        O_sdram_cs_n,
    output wire        O_sdram_cas_n,
    output wire        O_sdram_ras_n,
    output wire        O_sdram_wen_n,
    inout  wire [31:0] IO_sdram_dq,
    output wire [10:0] O_sdram_addr,
    output wire [1:0]  O_sdram_ba,
    output wire [3:0]  O_sdram_dqm
);

localparam [21:0] VRAM_BASE = 22'h300000;

reg video_ce_d = 1'b0;
always @(posedge clk_108m) video_ce_d <= video_ce;
wire video_ce_edge = video_ce & ~video_ce_d;

localparam FS_W = $clog2(FAILSAFE_CLKRAM + 1);
// sync = rising edge of video_ce, or the failsafe.
reg  [FS_W-1:0] fs_cnt = {FS_W{1'b0}};
wire fs_fire = (fs_cnt >= FAILSAFE_CLKRAM);
wire sync = video_ce_edge | fs_fire;
always @(posedge clk_108m) begin
    if (sync)          fs_cnt <= {FS_W{1'b0}};
    else if (!fs_fire) fs_cnt <= fs_cnt + 1'b1;
end

// sync as a toggle, synchronised and edge-detected into clk_sys
reg sync_tog = 1'b0;
always @(posedge clk_108m) if (sync) sync_tog <= ~sync_tog;
reg st_s1 = 1'b0, st_s2 = 1'b0, st_s3 = 1'b0;
always @(posedge clk_27m) begin
    st_s1 <= sync_tog;
    st_s2 <= st_s1;
    st_s3 <= st_s2;
end
assign sync_tick_27m = st_s2 ^ st_s3;

wire        sd_cke, sd_cs, sd_we, sd_ras, sd_cas;
wire [10:0] sd_addr;
wire [3:0]  sd_dqm;
wire [1:0]  sd_ba;

reg  [21:0] ch_addr;
reg  [15:0] ch_din;
reg         ch_cs, ch_we;
wire [15:0] ch_dout;
wire        ch_ack;

reg  [22:0] p2_addr;
reg  [15:0] p2_din;
reg  [1:0]  p2_ds;
reg         p2_cs, p2_we;
wire [15:0] p2_dout;
wire [47:0] p2_dout48;
wire        p2_ack;

sdram #(
    .DATA_WIDTH       (32),
    .RAS_WIDTH        (11),
    .CAS_WIDTH        (8),
    .RAM_CLOCK_SPEED  (86_400_000),
    .SYNC_CLOCK_SPEED (5_370_000),
    .CHIP48_BURST     (1),
    .SYNC_DELAY       (SYNC_DELAY),
    .UNGATE_CHIPSET   (UNGATE_CHIPSET)
) ram (
    .clk       (clk_108m),
    .reset_n   (bus_reset_n),
    .ready     (mem_ready),

    .sd_data   (IO_sdram_dq),
    .sd_addr   (sd_addr),
    .sd_dqm    (sd_dqm),
    .sd_ba     (sd_ba),
    .sd_cke    (sd_cke),
    .sd_cs     (sd_cs),
    .sd_we     (sd_we),
    .sd_ras    (sd_ras),
    .sd_cas    (sd_cas),

    .sync      (sync),
    .refresh   (1'b0),

    .din       (ch_din),
    .dout      (ch_dout),
    .dout48    (),
    .addr      (ch_addr),
    .ds        (2'b00),
    .cs        (ch_cs),
    .we        (ch_we),
    .ack       (ch_ack),

    .p2_din    (p2_din),
    .p2_dout   (p2_dout),
    .p2_dout48 (p2_dout48),
    .p2_addr   (p2_addr),
    .p2_ds     (p2_ds),
    .p2_cs     (p2_cs),
    .p2_we     (p2_we),
    .p2_ack    (p2_ack)
);

assign O_sdram_clk   = clk_sdram;
assign O_sdram_cke   = sd_cke;
assign O_sdram_cs_n  = sd_cs;
assign O_sdram_ras_n = sd_ras;
assign O_sdram_cas_n = sd_cas;
assign O_sdram_wen_n = sd_we;
assign O_sdram_addr  = sd_addr;
assign O_sdram_ba    = sd_ba;
assign O_sdram_dqm   = sd_dqm;

reg ch_ack_d = 0;
always @(posedge clk_108m) ch_ack_d <= ch_ack;
wire ch_done = (ch_ack != ch_ack_d);

// clk_sys cycles after the synchronised ack before data is sampled
localparam [1:0] P2_SETTLE = 2'd2;
reg [1:0] p2_wait = 2'd0;

reg p2_ack_s1 = 0, p2_ack_s2 = 0, p2_ack_s3 = 0;
always @(posedge clk_27m or negedge bus_reset_n) begin
    if (!bus_reset_n) begin
        p2_ack_s1 <= 1'b0;
        p2_ack_s2 <= 1'b0;
        p2_ack_s3 <= 1'b0;
    end else begin
        p2_ack_s1 <= p2_ack;
        p2_ack_s2 <= p2_ack_s1;
        p2_ack_s3 <= p2_ack_s2;
    end
end
wire p2_done_sys = (p2_ack_s2 != p2_ack_s3);

// After a VRAM access completes with a CPU request waiting, skip one slot
// so port 2 gets a turn.
reg yield_next = 1'b0;
localparam C_IDLE = 3'd0,
           C_WR   = 3'd1,
           C_RD0  = 3'd2,
           C_RD1  = 3'd3,
           C_DONE = 3'd4,
           C_RD1A = 3'd5,
           C_RDS  = 3'd6;
reg [2:0]  cstate = C_IDLE;
assign cstate_out = cstate;
assign dbg_sync   = sync;
assign dbg_sdst   = ram.state;
assign dbg_p2ack  = p2_ack;

wire cpu_pending = (cstate != C_IDLE) && (cstate != C_DONE);

// cpu_pending synchronised into clk_ram
reg cpu_pending_s1 = 1'b0, cpu_pending_ram = 1'b0;
always @(posedge clk_108m or negedge bus_reset_n) begin
    if (!bus_reset_n) begin
        cpu_pending_s1  <= 1'b0;
        cpu_pending_ram <= 1'b0;
    end else begin
        cpu_pending_s1  <= cpu_pending;
        cpu_pending_ram <= cpu_pending_s1;
    end
end

always @(posedge clk_108m or negedge bus_reset_n) begin
    if (!bus_reset_n) begin
        ch_cs       <= 1'b0;
        ch_we       <= 1'b0;
        ch_addr     <= 22'd0;
        ch_din      <= 16'd0;
        vram_dout   <= 16'd0;
        yield_next  <= 1'b0;
    end else begin
        if (sync || (UNGATE_CHIPSET && !yield_next && !ch_cs
                     && (vram_rd || vram_write))) begin
            if (yield_next) begin
                yield_next <= 1'b0;
            end else if (!ch_cs && (vram_rd || vram_write)) begin
                ch_addr <= VRAM_BASE + {6'd0, vram_addr[15:0]};
                ch_din  <= vram_din;
                ch_we   <= vram_write;
                ch_cs   <= 1'b1;
            end
        end

        if (ch_done) begin
            ch_cs <= 1'b0;
            if (!ch_we) vram_dout <= ch_dout;
            if (cpu_pending_ram) yield_next <= 1'b1;
        end
    end
end

reg [15:0] word0;

always @(posedge clk_27m or negedge bus_reset_n) begin
    if (!bus_reset_n) begin
        cstate     <= C_IDLE;
        p2_cs      <= 1'b0;
        p2_we      <= 1'b0;
        p2_ds      <= 2'b11;
        p2_addr    <= 23'd0;
        p2_din     <= 16'd0;
        ram_busy   <= 1'b0;
        ram_dout   <= 8'd0;
        ram_dout_w <= 32'd0;
        word0      <= 16'd0;
        p2_wait    <= 2'd0;
    end else begin
        case (cstate)

        C_IDLE:
            if (ram_req && mem_ready) begin
                ram_busy <= 1'b1;
                if (ram_write) begin
                    p2_addr <= {1'b0, ram_addr[22:1]};
                    p2_din  <= ram_wword ? ram_din16 : {ram_din, ram_din};
                    // p2_ds: 0 = write this byte. One lane from ram_addr[0], or both for a word.
                    p2_ds   <= ram_wword ? 2'b00
                                         : (ram_addr[0] ? 2'b01 : 2'b10);
                    p2_we   <= 1'b1;
                    p2_cs   <= 1'b1;
                    cstate  <= C_WR;
                end else begin
                    // Reads: one wide access (CHIP48_BURST) returns the whole 32-bit word.
                    p2_addr <= {1'b0, ram_addr[22:2], 1'b0};
                    p2_ds   <= 2'b00;
                    p2_we   <= 1'b0;
                    p2_cs   <= 1'b1;
                    cstate  <= C_RD1;
                end
            end

        C_WR:
            if (p2_done_sys) begin
                p2_cs  <= 1'b0;
                cstate <= C_DONE;
            end

        C_RD0:
            if (p2_done_sys) begin
                word0   <= p2_dout;
                p2_cs   <= 1'b0;
                p2_addr <= {1'b0, ram_addr[22:2], 1'b1};
                cstate  <= C_RD1A;
            end

        C_RD1A: begin
            p2_cs  <= 1'b1;
            cstate <= C_RD1;
        end

        C_RD1:
            if (p2_done_sys) begin
                p2_cs   <= 1'b0;
                p2_wait <= 2'd0;
                cstate  <= C_RDS;
            end

        C_RDS:
            if (p2_wait >= P2_SETTLE) begin
                ram_dout_w <= {p2_dout48[47:32], p2_dout};
                ram_dout   <= (ram_addr[1:0] == 2'd0) ? p2_dout[7:0]
                            : (ram_addr[1:0] == 2'd1) ? p2_dout[15:8]
                            : (ram_addr[1:0] == 2'd2) ? p2_dout48[39:32]
                            :                           p2_dout48[47:40];
                cstate     <= C_DONE;
            end else
                p2_wait <= p2_wait + 2'd1;

        C_DONE: begin
            ram_busy <= 1'b0;
            if (!ram_req) cstate <= C_IDLE;
        end

        default: cstate <= C_IDLE;

        endcase
    end
end

endmodule
