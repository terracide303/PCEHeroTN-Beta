// pce_hdmi_di.v -- PCEHeroTN
//
// HDMI data islands (audio and InfoFrames) on top of the console-timed
// scandoubler raster. clk_pixel only.
//
// It watches the scandoubler's de/hsync/vsync, rebuilds the pixel position,
// and drives the three tmds_channel encoders with the HDMI period sequence:
// control, video preamble and guard, video, data-island preamble and guard,
// data island. The packet path (packet_picker, packet_assembler and the
// packet builders) is hdl-util/hdmi, unchanged; only the timing block of
// hdmi.sv's true_hdmi_output is ported, rewritten for this geometry.
//
// Line layout in clk_pixel ticks (LINE = 910):
//   cx [0, 64)          hsync pulse          control
//   cx [85, 93)         video preamble
//   cx [93, 95)         video guard
//   cx [95, 815)        active video (de)
//   cx [815, 823)       data-island preamble
//   cx [823, 825)       data-island guard
//   cx [825, +32*N)     data island, N packets
//   then 2 ticks guard, then control to the end of the line
//
// hdl-util puts the video guard at the end of the line because its active
// area starts at cx=0. Ours has a 95-tick back porch, so the video preamble
// and guard sit right before the active area, as the spec requires.
//
// Packet budget (hdl-util's formula) gives 1 packet per line. At 48 kHz that
// is ~1.52 samples per line, and an audio packet carries up to 4, so one
// packet per line keeps up.
//
// Three details that each cost HDMI lock or audio when they were wrong:
//   - cx and cy free-run over constant LINE / V_TOTAL and the sync edges only
//     re-align them. Counters advanced only by external edges cannot be shown
//     to ever change, and synthesis then removed the audio and InfoFrame
//     builders as unreachable.
//   - rgb is registered once on entry so video data lands in the same cycle as
//     tmds_mode. One cycle apart, the first pixel of each line goes out as a
//     control symbol.
//   - packet_enable is anchored to the start of the data island. hdl-util's
//     form only lands on the slot boundary when the active area ends on a
//     multiple of 16 (its active area starts at 0); ours ends at 815.

module pce_hdmi_di #(
    parameter integer LINE        = 910,  // pce_scandoubler OLINE
    parameter integer H_ACT_LO    = 95,  // first active cx
    parameter integer H_ACT_HI    = 815,  // one past the last active cx
    parameter integer V_ACT_START = 38,
    parameter integer V_ACT_LINES = 480,
    // Output lines per frame. A constant so cy provably wraps; frame_start still
    // re-aligns it, so it only needs to be >= V_ACT_START + V_ACT_LINES.
    parameter integer V_TOTAL     = 525,
    parameter integer DI_PACKETS  = 1,  // packets per line
    // 0 = bare DVI: no guards, preambles or islands (debug).
    parameter integer DI_ENABLE   = 1,

    // For packet_picker and the audio clock maths: the real clk_pixel frequency.
    parameter real    VIDEO_RATE  = 28_125_000.0,
    parameter integer AUDIO_RATE  = 48_000,
    parameter integer AUDIO_BIT_WIDTH = 16,
    parameter integer VIDEO_ID_CODE  = 2,  // 720x480 4:3, a hint in the AVI InfoFrame
    parameter [8*8-1:0]  VENDOR_NAME  = { "PCEHero", 8'd0 },
    parameter [8*16-1:0] PRODUCT_DESCRIPTION = { "Tang Nano 20K", 24'd0 }
) (
    input  wire        clk_pixel,
    input  wire        clk_audio,  // AUDIO_RATE square wave (48 kHz)
    input  wire        reset,  // sync, active high, power-on only

    // From pce_scandoubler, clk_pixel, mutually aligned.
    input  wire [23:0] rgb,
    input  wire        de,
    input  wire        hsync,  // high in active, low during the pulse
    input  wire        vsync,  // high in active, low during the pulse

    // 16-bit two's complement, as IEC 60958 linear PCM expects.
    input  wire [AUDIO_BIT_WIDTH-1:0] audio_word_l,
    input  wire [AUDIO_BIT_WIDTH-1:0] audio_word_r,
    input  wire        aspect_16_9,  // 0 = 4:3

    // To the three tmds_channel encoders.
    output reg  [2:0]  tmds_mode,
    output reg  [23:0] tmds_video_data,
    output reg  [5:0]  tmds_control_data,
    output reg  [11:0] tmds_island_data,

    // Debug: sticky flags, an audio clock (0x01) / audio sample (0x02) packet header was sent.
    output wire          dbg_hb0_acr_seen,
    output wire          dbg_hb0_audio_seen
);

    // The scandoubler delays de by two clocks but the syncs by one. Register the
    // syncs once so cx, the guards and the video period all share de's phase; a
    // one-tick gap between guard and video loses HDMI lock.
    reg        hs_q  = 1'b1, vs_q  = 1'b1;
    reg        hs_qd = 1'b1, vs_qd = 1'b1;
    reg [11:0] cx = 12'd0;
    reg [11:0] cy = 12'd0;
    reg [23:0] rgb_q = 24'd0;

    wire line_start  = hs_qd & ~hs_q;  // hsync 1->0 = start of line
    wire frame_start = vs_qd & ~vs_q;  // vsync 1->0 = start of frame

    always @(posedge clk_pixel) begin
        hs_q <= hsync;  hs_qd <= hs_q;
        vs_q <= vsync;  vs_qd <= vs_q;
        rgb_q <= rgb;

        if (reset) begin
            cx <= 12'd0;
            cy <= 12'd0;
        end else begin
            // cx is 0 in the cycle the edge is seen, so re-align to 1.
            cx <= line_start     ? 12'd1 :
                  (cx == LINE-1) ? 12'd0 : (cx + 12'd1);
            // cy steps on the cx wrap; frame_start re-aligns it in vblank.
            if (frame_start)
                cy <= 12'd0;
            else if (cx == LINE-1)
                cy <= (cy == V_TOTAL-1) ? 12'd0 : (cy + 12'd1);
        end
    end

    wire this_line_active = (cy >= V_ACT_START) && (cy < V_ACT_START + V_ACT_LINES);

    // Video preamble and guard: the 8 and 2 ticks before H_ACT_LO.
    localparam integer VG_LO = H_ACT_LO - 2;
    localparam integer VP_LO = H_ACT_LO - 10;

    reg video_guard   = 1'b0;
    reg video_preamble = 1'b0;
    always @(posedge clk_pixel) begin
        if (reset) begin
            video_guard    <= 1'b0;
            video_preamble <= 1'b0;
        end else begin
            video_guard    <= (DI_ENABLE != 0) && this_line_active && (cx >= VG_LO) && (cx < H_ACT_LO);
            video_preamble <= (DI_ENABLE != 0) && this_line_active && (cx >= VP_LO) && (cx < VG_LO);
        end
    end

    // Ticks after the active area, minus video guard (2), video preamble (8),
    // control (12), island guards (2 + 2) and island preamble (8), in 32-tick packets.
    localparam integer MAX_PKT =
        ((LINE - H_ACT_HI) - 2  - 8  - 12
         - 2  - 2  - 8 ) / 32;
    localparam integer N_PKT = (DI_PACKETS < MAX_PKT) ? DI_PACKETS
                             : (MAX_PKT < 0) ? 0 : MAX_PKT;

    localparam integer DI_PRE_LO  = H_ACT_HI;
    localparam integer DI_GRD_LO  = H_ACT_HI + 8;
    localparam integer DI_PER_LO  = H_ACT_HI + 10;
    localparam integer DI_PER_HI  = H_ACT_HI + 10 + N_PKT*32;
    localparam integer DI_GRD2_HI = DI_PER_HI + 2;

    wire di_inst = (DI_ENABLE != 0) && (N_PKT > 0) && (cx >= DI_PER_LO) && (cx < DI_PER_HI);
    // One pulse at the head of each 32-tick packet slot.
    wire packet_enable = di_inst && (((cx - DI_PER_LO) & 12'h01f) == 12'd0);

    reg data_island_guard    = 1'b0;
    reg data_island_preamble = 1'b0;
    reg data_island_period   = 1'b0;
    always @(posedge clk_pixel) begin
        if (reset) begin
            data_island_guard    <= 1'b0;
            data_island_preamble <= 1'b0;
            data_island_period   <= 1'b0;
        end else begin
            data_island_guard    <= (DI_ENABLE != 0) && (N_PKT > 0) &&
                (( (cx >= DI_GRD_LO)  && (cx < DI_PER_LO) ) ||
                 ( (cx >= DI_PER_HI)  && (cx < DI_GRD2_HI) ));
            data_island_preamble <= (DI_ENABLE != 0) && (N_PKT > 0) && (cx >= DI_PRE_LO) && (cx < DI_GRD_LO);
            data_island_period   <= di_inst;
        end
    end

    reg video_data_period = 1'b0;
    always @(posedge clk_pixel)
        video_data_period <= reset ? 1'b0 : de;

    wire video_field_end = (cx == H_ACT_HI - 1) &&
                           (cy == V_ACT_START + V_ACT_LINES - 1);

    // packet_picker needs a real per-frame reset pulse; a constant lets synthesis
    // fold its sent-flags and remove the InfoFrame builders.
    wire pp_reset = reset | frame_start;

    wire [AUDIO_BIT_WIDTH-1:0] audio_sample_word [1:0];
    assign audio_sample_word[0] = audio_word_l;
    assign audio_sample_word[1] = audio_word_r;

    wire [23:0] header;
    wire [55:0] sub [3:0];
    wire [4:0]  packet_pixel_counter;
    wire [8:0]  packet_data;

    packet_picker #(
        .VIDEO_ID_CODE   (VIDEO_ID_CODE),
        .VIDEO_RATE      (VIDEO_RATE),
        .IT_CONTENT      (1'b1),
        .AUDIO_RATE      (AUDIO_RATE),
        .AUDIO_BIT_WIDTH (AUDIO_BIT_WIDTH),
        .VENDOR_NAME     (VENDOR_NAME),
        .PRODUCT_DESCRIPTION (PRODUCT_DESCRIPTION),
        .SOURCE_DEVICE_INFORMATION (8'h00)
    ) packet_picker (
        .clk_pixel           (clk_pixel),
        .clk_audio           (clk_audio),
        .reset               (pp_reset),
        .video_field_end     (video_field_end),
        .packet_enable       (packet_enable),
        .packet_pixel_counter(packet_pixel_counter),
        .audio_sample_word   (audio_sample_word),
        .aspect_16_9         (aspect_16_9),
        .header              (header),
        .sub                 (sub)
    );

    // Header byte 0 is the packet type.
    reg dbg_hb0_acr_seen_r   = 1'b0;
    reg dbg_hb0_audio_seen_r = 1'b0;
    always @(posedge clk_pixel) begin
        if (header[7:0] == 8'h01) dbg_hb0_acr_seen_r   <= 1'b1;
        if (header[7:0] == 8'h02) dbg_hb0_audio_seen_r <= 1'b1;
    end
    assign dbg_hb0_acr_seen   = dbg_hb0_acr_seen_r;
    assign dbg_hb0_audio_seen = dbg_hb0_audio_seen_r;

    packet_assembler packet_assembler (
        .clk_pixel         (clk_pixel),
        .reset             (reset),
        .data_island_period(data_island_period),
        .header            (header),
        .sub               (sub),
        .packet_data       (packet_data),
        .counter           (packet_pixel_counter)
    );

    always @(posedge clk_pixel) begin
        if (reset) begin
            tmds_mode         <= 3'd2;
            tmds_video_data   <= 24'd0;
            tmds_control_data <= 6'd0;
            tmds_island_data  <= 12'd0;
        end else begin
            tmds_mode <= data_island_guard    ? 3'd4 :
                         data_island_period   ? 3'd3 :
                         video_guard          ? 3'd2 :
                         video_data_period    ? 3'd1 : 3'd0;
            tmds_video_data <= rgb_q;  // lands with tmds_mode
            tmds_control_data <= { {1'b0, data_island_preamble},
                                   {1'b0, video_preamble || data_island_preamble},
                                   {vs_q, hs_q} };  // ctrl3, ctrl2, ctrl1, ctrl0, vsync, hsync
            tmds_island_data[11:4] <= packet_data[8:1];
            tmds_island_data[3]    <= (cx != 0);
            tmds_island_data[2]    <= packet_data[0];
            tmds_island_data[1:0]  <= {vs_q, hs_q};
        end
    end

endmodule
