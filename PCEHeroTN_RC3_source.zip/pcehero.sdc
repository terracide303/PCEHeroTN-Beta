# pcehero.sdc -- PCEHeroTN timing constraints
#
# One statement per line: Gowin's SDC reader does not join lines ending in
# a backslash.

create_clock -name ex_clk_27m -period 37.037 -waveform {0 18.518} [get_ports {ex_clk_27m}]

# clk_ram = 27 * 16/5 = 86.4 MHz, and clk_sys = clk_ram / 2 = 43.2 MHz from a
# CLKDIV. They are phase-locked, so paths between them are timed normally.
create_generated_clock -name clk_ram -source [get_ports {ex_clk_27m}] -master_clock ex_clk_27m -multiply_by 16 -divide_by 5 [get_pins {clocks_inst/rpll_inst/CLKOUT}]

create_generated_clock -name clk_sys -source [get_pins {clocks_inst/rpll_inst/CLKOUT}] -master_clock clk_ram -divide_by 2 [get_pins {clocks_inst/clkdiv_inst/CLKOUT}]

# HDMI: rpll_hdmi runs from clk_sys, clk_pixel_x5 = clk_sys * 10/3 = 144 MHz,
# clk_pixel = clk_pixel_x5 / 5 = 28.8 MHz.
create_generated_clock -name clk_pixel_x5 -source [get_pins {clocks_inst/clkdiv_inst/CLKOUT}] -master_clock clk_sys -multiply_by 10 -divide_by 3 [get_pins {clocks_inst/rpll_hdmi/CLKOUT}]
create_generated_clock -name clk_pixel -source [get_pins {clocks_inst/rpll_hdmi/CLKOUT}] -master_clock clk_pixel_x5 -divide_by 5 [get_pins {clocks_inst/clkdiv_pixel/CLKOUT}]

# Asynchronous groups. Crossings between them are handled in the RTL (toggle
# synchronisers, or a line buffer the two sides never share), with two
# exceptions: the audio samples (at worst one noisy sample) and
# mcu_read_ready_toggle into sdc_mcu_read, which has no synchroniser.
#   core + SDRAM:  clk_sys, clk_ram, clk_ram_sdram
#   video:         clk_pixel, clk_pixel_x5 (1:5, synchronous for the serialiser)
#   the crystal:   only the PLL reference
#   audio:         clk_audio
set_clock_groups -asynchronous -group [get_clocks {clk_sys clk_ram clk_ram_sdram}] -group [get_clocks {clk_pixel clk_pixel_x5}] -group [get_clocks {ex_clk_27m}] -group [get_clocks {clk_audio}]

# SDRAM read capture. clk_ram_sdram is clk_ram shifted 270 degrees (rPLL
# CLKOUTP) and clocks the SDRAM chip. Input delays are the chip's tAC (max)
# and tOH (min) from the EM638325 datasheet, Table 16.
create_generated_clock -name clk_ram_sdram -source [get_pins {clocks_inst/rpll_inst/CLKOUT}] -master_clock clk_ram -phase 270 [get_pins {clocks_inst/rpll_inst/CLKOUTP}]
set_input_delay -clock clk_ram_sdram -max 5.4 [get_ports {IO_sdram_dq[*]}]
set_input_delay -clock clk_ram_sdram -min 2.5 [get_ports {IO_sdram_dq[*]}]

# clk_audio: a phase-accumulator MSB in clk_pixel averaging 48 kHz (not a
# fixed ratio, so not a generated clock). packet_picker.sv clocks registers
# from it. Left undeclared, Gowin assumes 100 MHz and reports false
# violations on its synchronised crossing.
create_clock -name clk_audio -period 20833.333 [get_nets {clk_audio}]

# Companion SPI (mcu_spi_new.v): these registers cross from the SPI clock,
# which is not a declared clock, and are handshaked in the RTL. The same
# exceptions as MSXnano-MiSTle's Z80_goauld.sdc for this module.
set_false_path -from [get_pins {fpga_companion_inst/mcu/spi_data_in?*?/?*}] -to [get_pins {fpga_companion_inst/mcu/spi_target?*?/?*}]
set_false_path -from [get_pins {fpga_companion_inst/mcu/spi_data_in?*?/?*}] -to [get_pins {fpga_companion_inst/mcu/spi_in_data?*?/?*}]
set_false_path -from [get_pins {fpga_companion_inst/mcu/spi_data_in_ready?*?/?*}] -to [get_pins {fpga_companion_inst/mcu/spi_data_in_readyD?*?/?*}]
set_false_path -from [get_clocks {clk_pixel}] -to [get_pins {fpga_companion_inst/mcu/spi_data_in?*?/?*}]
set_false_path -from [get_pins {fpga_companion_inst/spi_ext?*?/?*}] -to [get_pins {fpga_companion_inst/mcu/spi_data_in?*?/?*}]
set_false_path -from [get_pins {fpga_companion_inst/spi_ext?*?/?*}] -to [get_pins {fpga_companion_inst/mcu/spi_sr_in?*?/?*}]
set_false_path -from [get_clocks {clk_pixel}] -to [get_pins {fpga_companion_inst/mcu/spi_io_dout?*?/?*}]
# spi_ext (quasi-static) selects spi_io_ss, which is spi_cnt's asynchronous
# clear.
set_false_path -from [get_pins {fpga_companion_inst/spi_ext?*?/?*}] -to [get_pins {fpga_companion_inst/mcu/spi_cnt?*?/?*}]
